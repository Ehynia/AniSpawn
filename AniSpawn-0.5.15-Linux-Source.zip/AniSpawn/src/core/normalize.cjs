'use strict';
function str(v){return typeof v==='string'?v.trim():''}
function list(value){
 if(Array.isArray(value))return value;
 if(!value||typeof value!=='object')return [];
 for(const k of ['data','releases','results','list','content','items','animes']){
   if(Array.isArray(value[k]))return value[k];
   if(value[k]&&value[k]!==value){const result=list(value[k]);if(result.length)return result;}
 }
 return [];
}
function absolute(value,base){
 if(!value||typeof value!=='string')return '';
 try {const u=new URL(value,base);return ['https:','http:'].includes(u.protocol)?u.href:'';}catch{return ''}
}
function normLib(r,base='https://anilibria.top'){
 const id=r?.id??r?.release?.id; if(id===null||id===undefined)return null;
 const poster=r?.poster?.optimized?.preview||r?.poster?.src||r?.poster?.preview||r?.poster?.optimized?.thumbnail||r?.poster?.thumbnail||r?.poster||r?.image?.preview||r?.image;
 return {id:`libria:${id}`,source:'libria',remoteId:String(id),name:str(r?.name?.main)||str(r?.names?.ru)||str(r?.name)||str(r?.title)||`Релиз ${id}`,
   original:str(r?.name?.english)||str(r?.title_original),image:absolute(poster,base),description:str(r?.description),year:r?.year||r?.season?.year||'',rating:r?.rating?.average??r?.shikimori?.rating??null,
   episodesTotal:r?.episodes_total??r?.episodes_count??null,category:r?.type?.description||r?.type?.value||'Аниме',
   playable:true,blocked:!!(r?.is_blocked_by_geo||r?.is_blocked_by_copyrights||r?.blocked?.blocked),url:`https://anilibria.top/anime/releases/${encodeURIComponent(id)}`};
}
function episodesLib(r,base='https://anilibria.top'){
 const a=Array.isArray(r?.episodes)?r.episodes:Array.isArray(r?.playlist)?r.playlist:Array.isArray(r?.player?.list)?r.player.list:
    r?.player?.list&&typeof r.player.list==='object'?Object.values(r.player.list):[];
 return a.map((e,i)=>{
  const quality={};
  const q={1080:e?.hls_1080||e?.hls?.fhd||e?.hls?.fullhd||e?.fullhd||e?.hls?.['1080'],720:e?.hls_720||e?.hls?.hd||e?.hd||e?.hls?.['720'],480:e?.hls_480||e?.hls?.sd||e?.sd||e?.hls?.['480']};
  for(const [k,v] of Object.entries(q)){
    const value=typeof v==='object'?(v.url||v.src):v;
    const stream=absolute(value,base);
    if(stream)quality[k]=stream;
  }
  const position=Number(e?.ordinal??e?.episode??e?.position??i+1);
  return {id:String(e?.id||position),ordinal:Number.isFinite(position)?position:i+1,name:str(e?.name)||str(e?.title)||`Эпизод ${i+1}`,quality};
 }).filter(x=>Object.keys(x.quality).length>0).sort((a,b)=>a.ordinal-b.ordinal);
}
function normAniList(r){const id=r?.id;if(id==null)return null;
 return {id:`anilist:${id}`,source:'anilist',remoteId:String(id),name:str(r?.title?.english)||str(r?.title?.romaji)||str(r?.title?.native)||`Anime ${id}`,original:str(r?.title?.romaji),image:absolute(r?.coverImage?.extraLarge||r?.coverImage?.large,'https://anilist.co'),description:str(r?.description)?.replace(/<[^>]*>/g,''),year:r?.seasonYear||'',rating:r?.averageScore?Number(r.averageScore)/10:null,episodesTotal:r?.episodes??null,category:r?.format||'Аниме',playable:false,blocked:false,url: absolute(r?.siteUrl,'https://anilist.co')};
}
function normShiki(r){const id=r?.id;if(id==null)return null;
 return {id:`shiki:${id}`,source:'shiki',remoteId:String(id),name:str(r?.russian)||str(r?.name)||`Anime ${id}`,original:str(r?.name),image:absolute(r?.image?.original||r?.image?.preview,'https://shikimori.one'),description:str(r?.description)?.replace(/<[^>]*>/g,''),year:r?.aired_on?.slice(0,4)||'',rating:r?.score?Number(r.score):null,episodesTotal:r?.episodes||null,category:r?.kind||'Аниме',playable:false,blocked:false,url:`https://shikimori.one/animes/${id}`};
}
function normJikan(r){const id=r?.mal_id;if(id==null)return null;
 return {id:`jikan:${id}`,source:'jikan',remoteId:String(id),name:str(r?.title_english)||str(r?.title)||str(r?.title_japanese)||`Anime ${id}`,
 original:str(r?.title),image:absolute(r?.images?.webp?.large_image_url||r?.images?.jpg?.large_image_url,'https://myanimelist.net'),
 description:str(r?.synopsis),year:r?.year||r?.aired?.from?.slice(0,4)||'',rating:r?.score??null,
 episodesTotal:r?.episodes??null,category:r?.type||'Аниме',playable:false,blocked:false,
 url:absolute(r?.url,'https://myanimelist.net')};
}
function kodikLink(value){
 if(typeof value!=='string')return '';
 try {const u=new URL(value.startsWith('//')?'https:'+value:value,'https://kodik.info');
  return u.protocol==='https:'&&['kodik.info','kodikplayer.com'].some(host=>u.hostname===host||u.hostname.endsWith('.'+host))?u.href:'';
 }catch{return ''}
}
function normKodik(r){const id=r?.id;if(typeof id!=='string'||!/^[\w-]{1,100}$/.test(id))return null;
 const embed=kodikLink(r?.link);
 return {id:`kodik:${id}`,source:'kodik',remoteId:id,
 name:str(r?.title)||str(r?.title_orig)||`Видео ${id}`,original:str(r?.title_orig),
 image:absolute(r?.screenshots?.[0]||r?.poster||r?.image,'https://kodik.info'),description:'Видеозапись в каталоге Kodik. Доступность и условия просмотра определяет платформа.',
 year:r?.year||'',rating:null,episodesTotal:null,category:r?.type||'Видео',playable:!!embed,blocked:false,embed,url:embed};
}
function normAnixart(r){const id=r?.id;if(id==null)return null;
 return {id:`anixart:${id}`,source:'anixart',remoteId:String(id),name:str(r?.title_ru)||str(r?.title)||`Аниме ${id}`,original:str(r?.title_original),image:absolute(r?.image,'https://anixart.app'),description:str(r?.description),year:r?.year||'',rating:r?.grade??null,episodesTotal:r?.episodes_released??null,category:r?.category?.name||'Аниме',playable:false,blocked:!!r?.is_view_blocked,url:`https://anixart.app/release/${id}`};
}
module.exports={list,absolute,normLib,episodesLib,normAniList,normShiki,normJikan,normKodik,kodikLink,normAnixart};
