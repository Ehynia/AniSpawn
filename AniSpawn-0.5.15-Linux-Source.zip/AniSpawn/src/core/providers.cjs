'use strict';
const N=require('./normalize.cjs');
const LIBRIA_BASES=['https://anilibria.top/api/v1','https://api.anilibria.app/api/v1','https://aniliberty.top/api/v1'];
const sources=[
 {id:'libria',name:'AniLiberty / AniLibria',kind:'video',description:'Каталог и HLS-видео. Отдельные релизы могут иметь гео- или правовые ограничения.'},
 {id:'anixart',name:'Anixart',kind:'catalog',description:'Каталог через неофициальную библиотеку anixartjs. Видео через сторонних провайдеров не извлекается.'},
 {id:'anilist',name:'AniList',kind:'catalog',description:'Метаданные по GraphQL, видео не выдаёт.'},
 {id:'shiki',name:'Shikimori',kind:'catalog',description:'Русскоязычный каталог и оценки, видео не выдаёт.'},
 {id:'jikan',name:'Jikan (MyAnimeList)',kind:'catalog',description:'Открытые метаданные MyAnimeList; видеопотоков нет.'},
 {id:'kodik',name:'Kodik (по токену)',kind:'embedded',description:'Экспериментально: каталог и встроенный плеер по собственному API-токену. Сервис контролирует доступ к видео.'}
];
async function jsonFetch(fetchImpl,url,options={}){
 const timeout=options.timeout||13000;
 const controller=new AbortController();
 const timer=setTimeout(()=>controller.abort(),timeout);
 try {
  const response=await fetchImpl(url,{method:options.method||'GET',headers:{Accept:'application/json','User-Agent':'AniSpawn/0.2.0 (desktop anime client)',...(options.body?{'Content-Type':'application/json'}:{})},body:options.body?JSON.stringify(options.body):undefined,signal:controller.signal});
  if(!response.ok)throw new Error(`HTTP ${response.status}`);
  const data=await response.json();
  if(data?.errors?.length)throw new Error(data.errors[0].message||'API error');
  return data;
 } finally {clearTimeout(timer)}
}
function createProviders(fetchImpl=globalThis.fetch){
 let libriaBase=LIBRIA_BASES[0];
 let anixClient=null;
 let kodikToken='';
 const kodikPages=new Map();
 const kodikCache=new Map();
 function configureKodik(value){
  if(typeof value!=='string'||value.length>512||!/^[-\w]*$/.test(value))throw new Error('Недопустимый формат Kodik-токена');
  kodikToken=value;kodikPages.clear();kodikCache.clear();
  return {configured:!!kodikToken};
 }
 function requireKodik(){if(!kodikToken)throw new Error('Введите свой Kodik API-токен в Настройках');}
 async function kodikRequest(path,query={}){
  requireKodik();
  const u=new URL('https://kodik-api.com/'+path);
  u.searchParams.set('token',kodikToken);
  for(const [key,value] of Object.entries(query))u.searchParams.set(key,String(value));
  return jsonFetch(fetchImpl,u.toString());
 }
 function kodikItems(response){
  const a=N.list(response).map(r=>{const item=N.normKodik(r);if(item)kodikCache.set(item.remoteId,item);return item}).filter(Boolean);
  if(kodikCache.size>1500)kodikCache.clear();return a;
 }

 function anix(){
  if(anixClient)return anixClient;
  const {Anixart}=require('anixartjs');
  anixClient=new Anixart({baseUrl:'https://api-s.anixsekai.com'}).endpoints;
  return anixClient;
 }
 async function libria(route){
  let error;
  for(const base of [libriaBase,...LIBRIA_BASES.filter(x=>x!==libriaBase)]){
   try {const result=await jsonFetch(fetchImpl,base+route);libriaBase=base;return {result,base}}catch(e){error=e}
  }
  throw new Error(`AniLibria недоступна: ${error?.message||'ошибка сети'}`);
 }
 async function catalog(source='libria',page=1){
  page=Math.max(1,Math.min(100,Number(page)||1));
  switch(source){
   case 'libria':{const route=page===1?'/anime/releases/latest?limit=30':`/anime/catalog/releases?limit=30&page=${page}`;const {result,base}=await libria(route);return N.list(result).map(x=>N.normLib(x,base)).filter(Boolean)}
   case 'anixart':{const result=await anix().release.filter(page-1,{sort:0,status_id:null,category_id:null},true);return N.list(result).map(N.normAnixart).filter(Boolean)}
   case 'anilist':{
    const data=await jsonFetch(fetchImpl,'https://graphql.anilist.co',{method:'POST',body:{query:'query($page:Int){Page(page:$page,perPage:24){media(type:ANIME,sort:TRENDING_DESC){id title{romaji english native} coverImage{large extraLarge} description(asHtml:false) seasonYear episodes averageScore format siteUrl}}}',variables:{page}}});
    return N.list(data?.data?.Page?.media).map(N.normAniList).filter(Boolean);
   }
   case 'shiki':{const data=await jsonFetch(fetchImpl,`https://shikimori.one/api/animes?order=ranked&limit=24&page=${page}`);return N.list(data).map(N.normShiki).filter(Boolean)}
   case 'jikan':{const data=await jsonFetch(fetchImpl,`https://api.jikan.moe/v4/top/anime?page=${page}&limit=24`);return N.list(data).map(N.normJikan).filter(Boolean)}
   case 'kodik':{
    if(page>1&&!kodikPages.has(page))return [];
    let response;
    if(page===1)response=await kodikRequest('list',{limit:30});
    else {const next=new URL(kodikPages.get(page));if(next.origin!=='https://kodik-api.com'||next.pathname!=='/list'||next.searchParams.get('token')!==kodikToken)throw new Error('Недопустимый курсор Kodik');response=await jsonFetch(fetchImpl,next.href)}
    if(typeof response?.next_page==='string'){try{const next=new URL(response.next_page);if(next.origin==='https://kodik-api.com'&&next.pathname==='/list'&&next.searchParams.get('token')===kodikToken)kodikPages.set(page+1,next.href)}catch{}}
    return kodikItems(response);
   }
   default:throw new Error('Неизвестный источник');
  }
 }
 async function search(source,query){
  query=String(query||'').trim().slice(0,120);
  if(!query)return catalog(source);
  switch(source){
   case 'libria':{const {result,base}=await libria(`/app/search/releases?query=${encodeURIComponent(query)}`);return N.list(result).map(x=>N.normLib(x,base)).filter(Boolean)}
   case 'anixart':{const result=await anix().search.releases({query,searchBy:0,page:0});return N.list(result?.releases||result).map(N.normAnixart).filter(Boolean)}
   case 'anilist':{
    const data=await jsonFetch(fetchImpl,'https://graphql.anilist.co',{method:'POST',body:{query:'query($s:String){Page(page:1,perPage:24){media(type:ANIME,search:$s){id title{romaji english native} coverImage{large extraLarge} description(asHtml:false) seasonYear episodes averageScore format siteUrl}}}',variables:{s:query}}});
    return N.list(data?.data?.Page?.media).map(N.normAniList).filter(Boolean);
   }
   case 'shiki':{const data=await jsonFetch(fetchImpl,`https://shikimori.one/api/animes?limit=24&search=${encodeURIComponent(query)}`);return N.list(data).map(N.normShiki).filter(Boolean)}
   case 'jikan':{const data=await jsonFetch(fetchImpl,`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(query)}&limit=24`);return N.list(data).map(N.normJikan).filter(Boolean)}
   case 'kodik':{const data=await kodikRequest('search',{title:query,limit:24});return kodikItems(data)}
   default:throw new Error('Неизвестный источник');
  }
 }
 async function details(id){
  const [source,remoteId]=String(id||'').split(':');
  if(!/^[\w-]{1,100}$/.test(remoteId||''))throw new Error('Неверный идентификатор');
  if(source==='libria'){
   const {result,base}=await libria(`/anime/releases/${encodeURIComponent(remoteId)}`);
   const release=result?.release||result?.data||result;
   const normalized=N.normLib(release,base);if(!normalized)throw new Error('Релиз не найден');
   return {...normalized,episodes:normalized.blocked?[]:N.episodesLib(release,base)};
  }
  if(source==='kodik'){
   requireKodik();let item=kodikCache.get(remoteId);
   if(!item){const result=await kodikRequest('search',{id:remoteId,limit:1});item=kodikItems(result).find(x=>x.remoteId===remoteId)}
   if(!item)throw new Error('Запись Kodik не найдена (выполните поиск заново)');
   return {...item,episodes:[]};
  }
  if(source==='jikan'){
   const data=await jsonFetch(fetchImpl,`https://api.jikan.moe/v4/anime/${encodeURIComponent(remoteId)}/full`);
   const anime=N.normJikan(data?.data);if(!anime)throw new Error('Тайтл не найден');return {...anime,episodes:[]};
  }
  if(source==='anixart'){
   const result=await anix().release.info(Number(remoteId),true);
   return {...N.normAnixart(result?.release||result),episodes:[]};
  }
  if(source==='shiki'){
   const data=await jsonFetch(fetchImpl,`https://shikimori.one/api/animes/${encodeURIComponent(remoteId)}`);
   return {...N.normShiki(data),episodes:[]};
  }
  if(source==='anilist'){
   const data=await jsonFetch(fetchImpl,'https://graphql.anilist.co',{method:'POST',body:{query:'query($id:Int){Media(id:$id,type:ANIME){id title{romaji english native} coverImage{large extraLarge} description(asHtml:false) seasonYear episodes averageScore format siteUrl}}',variables:{id:Number(remoteId)}}});
   return {...N.normAniList(data?.data?.Media),episodes:[]};
  }
  throw new Error('Неизвестный источник');
 }
 async function health(source){
  const start=Date.now();
  try{let result;
   if(source==='libria')result=await libria('/anime/releases/latest?limit=1');
   else if(source==='anixart')result=await anix().release.filter(0,{sort:0,status_id:null,category_id:null},true);
   else if(source==='anilist')result=await catalog('anilist');
   else if(source==='shiki')result=await jsonFetch(fetchImpl,'https://shikimori.one/api/animes?limit=1');
   else if(source==='jikan')result=await jsonFetch(fetchImpl,'https://api.jikan.moe/v4/top/anime?limit=1');
   else if(source==='kodik')result=await kodikRequest('list',{limit:1});
   else throw new Error('Источник неизвестен');
   return {ok:true,ms:Date.now()-start,count:N.list(result?.result||result?.data?.Page?.media||result).length};
  }catch(e){return {ok:false,ms:Date.now()-start,error:e.message}}
 }
 return {sources,catalog,search,details,health,configureKodik};
}
module.exports={createProviders,LIBRIA_BASES,jsonFetch};
