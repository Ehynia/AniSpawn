'use strict';
const fs=require('node:fs');const path=require('node:path');
const {normalizeUpscale}=require('../../renderer/upscale.js');
const defaults={theme:'dark',source:'libria',bookmarks:[],history:[],volume:0.8,quality:'1080',upscale:normalizeUpscale()};
function clean(s){
 const t=s&&typeof s==='object'?s:{};
 return {
  theme:t.theme==='light'?'light':'dark',
  source:['libria','anilist','shiki','anixart','jikan','kodik'].includes(t.source)?t.source:'libria',
  bookmarks:Array.isArray(t.bookmarks)?t.bookmarks.filter(x=>x&&typeof x.id==='string'&&/^(libria|anixart|anilist|shiki|jikan|kodik):[\w-]{1,100}$/.test(x.id)).slice(-500):[],
  history:Array.isArray(t.history)?t.history.filter(x=>x&&typeof x.id==='string'&&typeof x.episode==='string').slice(-250):[],
  volume:Number.isFinite(t.volume)?Math.min(1,Math.max(0,t.volume)):0.8,
  quality:['1080','720','480'].includes(t.quality)?t.quality:'1080',
  upscale:normalizeUpscale(t.upscale)
 };
}
function createStore(filename){let data={...defaults};
 try{data=clean(JSON.parse(fs.readFileSync(filename,'utf8')))}catch{}
 function save(){fs.mkdirSync(path.dirname(filename),{recursive:true});const tmp=filename+'.tmp';fs.writeFileSync(tmp,JSON.stringify(data,null,2),'utf8');fs.renameSync(tmp,filename)}
 return {
  get:()=>structuredClone(data),
  patch(delta){if(!delta||typeof delta!=='object')throw new Error('Неверные настройки');data=clean({...data,...delta});save();return structuredClone(data)},
  bookmark(item){if(!item||typeof item.id!=='string')throw new Error('Неверная карточка');
    const exists=data.bookmarks.some(x=>x.id===item.id);
    data.bookmarks=exists?data.bookmarks.filter(x=>x.id!==item.id):[...data.bookmarks,{id:item.id,name:String(item.name||'').slice(0,200),image:String(item.image||'').slice(0,2000),source:String(item.source||''),year:item.year||''}].slice(-500);
    data=clean(data);save();return {added:!exists,bookmarks:data.bookmarks};
  },
  watched(entry){if(!entry||typeof entry.id!=='string'||typeof entry.episode!=='string')throw new Error('Неверная серия');
    data.history=[{id:entry.id,episode:entry.episode,name:String(entry.name||'').slice(0,180),date:new Date().toISOString()},...data.history.filter(x=>!(x.id===entry.id&&x.episode===entry.episode))].slice(0,250);
    data=clean(data);save();return data.history;
  }
 }
}
module.exports={createStore,clean,defaults};
