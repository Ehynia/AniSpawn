'use strict';
/* Read-only, time-limited access to files explicitly selected by the user.
   Native HTML video can seek using byte Range requests; no localhost server. */
const fs=require('node:fs');
const path=require('node:path');
const {randomUUID}=require('node:crypto');
const {Readable}=require('node:stream');
const TYPES=Object.freeze({'.mp4':'video/mp4','.m4v':'video/mp4','.webm':'video/webm','.mov':'video/quicktime','.ogg':'video/ogg'});
const ORIGIN='anispawn-local://media/';
function rangeFor(header,length){
 if(typeof header!=='string'||!/^(bytes=\d*-\d*)$/.test(header.trim()))return null;
 const [startPart,endPart]=header.trim().slice(6).split('-');
 if(!startPart&&!endPart)return null;
 let start,end;
 if(!startPart){const size=Number(endPart);if(!Number.isSafeInteger(size)||size<=0)return null;start=Math.max(0,length-size);end=length-1;}
 else {start=Number(startPart);end=endPart?Number(endPart):length-1;}
 if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<0||start>=length||end<start)return null;
 return {start,end:Math.min(length-1,end)};
}
function createLocalMedia(){
 const files=new Map();
 function register(filename){
  const extension=path.extname(filename).toLowerCase();if(!TYPES[extension])throw new Error('Неподдерживаемый формат локального видео');
  const stat=fs.statSync(filename);if(!stat.isFile()||stat.size<=0)throw new Error('Файл видео пуст или недоступен');
  if(files.size>=20)files.delete(files.keys().next().value);
  const token=randomUUID();files.set(token,{filename,mime:TYPES[extension],added:Date.now()});
  return ORIGIN+token;
 }
 async function handle(request){
  let u;try{u=new URL(request.url)}catch{return new Response('Bad media URL',{status:400})}
  const token=u.pathname.slice(1);const entry=u.hostname==='media'&&files.get(token);
  if(!entry||Date.now()-entry.added>8*60*60*1000)return new Response('Media file expired',{status:404});
  if(!['GET','HEAD'].includes(request.method))return new Response('Method not allowed',{status:405});
  let stat;try{stat=await fs.promises.stat(entry.filename)}catch{return new Response('Media file unavailable',{status:404})}
  if(!stat.isFile()||stat.size<=0)return new Response('Media file unavailable',{status:404});
  const incomingRange=request.headers.get('range');const range=incomingRange?rangeFor(incomingRange,stat.size):{start:0,end:stat.size-1};
  if(!range)return new Response(null,{status:416,headers:{'Content-Range':`bytes */${stat.size}`,'Access-Control-Allow-Origin':'*'}});
  const headers={'Content-Type':entry.mime,'Content-Length':String(range.end-range.start+1),'Accept-Ranges':'bytes','Access-Control-Allow-Origin':'*','Access-Control-Expose-Headers':'content-length,content-range,accept-ranges','Cache-Control':'no-store'};
  if(incomingRange)headers['Content-Range']=`bytes ${range.start}-${range.end}/${stat.size}`;
  const status=incomingRange?206:200;
  if(request.method==='HEAD')return new Response(null,{status,headers});
  return new Response(Readable.toWeb(fs.createReadStream(entry.filename,{start:range.start,end:range.end})),{status,headers});
 }
 return {register,handle};
}
module.exports={createLocalMedia,rangeFor};
