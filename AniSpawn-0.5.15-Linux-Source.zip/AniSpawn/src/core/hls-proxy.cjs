'use strict';
const {randomUUID}=require('node:crypto');
const URL_ROOT='anispawn-stream://media/';
function createHlsProxy(fetchImpl){
 const items=new Map();
 function register(remote){
  const url=new URL(remote);
  if(url.protocol!=='https:')throw new Error('Only HTTPS video streams are supported');
  if(items.size>20000)items.clear();
  const token=randomUUID();items.set(token,{url:url.href,time:Date.now()});
  return `${URL_ROOT}${token}`;
 }
 function rewritePlaylist(content,base){
  const put=s=>{
   try {return register(new URL(s,base).href)} catch {return s}
  };
  return content.split(/\r?\n/).map(line=>{
   if(!line.trim())return line;
   if(line.startsWith('#'))return line.replace(/URI="([^"]+)"/g,(_m,value)=>`URI="${put(value)}"`);
   return put(line.trim());
  }).join('\n');
 }
 async function handle(request){
  const u=new URL(request.url);const token=u.pathname.split('/').filter(Boolean)[0];
  const entry=items.get(token);
  if(!entry||Date.now()-entry.time>2*60*60*1000)return new Response('Media URL expired',{status:404});
  const headers={Accept:'*/*'};
  if(request.headers.get('range'))headers.Range=request.headers.get('range');
  let response;
  try {response=await fetchImpl(entry.url,{headers,redirect:'follow',signal:AbortSignal.timeout(30000)});}catch{return new Response('Media source unavailable',{status:502});}
  if(!response.ok&&response.status!==206)return new Response('Upstream video error',{status:response.status>=400&&response.status<=599?response.status:502});
  const finalUrl=response.url||entry.url;
  if(new URL(finalUrl).protocol!=='https:')return new Response('Insecure media redirect',{status:502});
  const mime=response.headers.get('content-type')||'';
  const playlist=/\.m3u8(?:$|\?)/i.test(finalUrl)||/mpegurl/i.test(mime);
  const cors={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'range,content-type','Access-Control-Expose-Headers':'content-range,accept-ranges,content-length'};
  if(playlist){
    const content=await response.text();
    if(content.length>3_000_000)return new Response('Playlist too large',{status:502});
    return new Response(rewritePlaylist(content,finalUrl),{status:200,headers:{...cors,'Content-Type':'application/vnd.apple.mpegurl'}});
  }
  const safe={'Content-Type':mime||'application/octet-stream',...cors};
  for(const key of ['content-range','accept-ranges','content-length','cache-control']){
   if(response.headers.has(key))safe[key]=response.headers.get(key);
  }
  return new Response(response.body,{status:response.status,headers:safe});
 }
 return {register,handle,rewritePlaylist};
}
module.exports={createHlsProxy};
