/* AniSpawn UI controller. No frontend build step: edit index.html / styles.css / app.js directly. */
'use strict';
const api=window.anispawn;
const upscaleAPI=window.AniSpawnUpscale;
const releaseRouter=window.AniSpawnReleaseRouter;
const $=(selector)=>document.querySelector(selector);
const state={source:'all',theme:'dark',quality:'1080',bookmarks:[],history:[],volume:0.8,items:[],itemMap:new Map(),search:'',page:1,current:null,playerOptions:{},hls:null,upscale:upscaleAPI?upscaleAPI.normalizeUpscale():{enabled:false,mode:'balanced',scale:1.5,strength:0.45},requestId:0,loading:false};
const sources={all:'Все источники',both:'Anixart + AniLiberty',libria:'AniLiberty',anixart:'Anixart',anilist:'AniList',shiki:'Shikimori',jikan:'Jikan',kodik:'Kodik',yani:'Yani / YummyAnime',mikai:'Mikai',sites:'Сайты · SovetRomantica / AnimeVost / SHIZA-Project'};
const help={all:'Объединённые результаты из всех подключённых API и импортированных страниц. Недоступные сервисы не блокируют каталог.',both:'Общий поиск, библиотека и плееры обеих платформ. Выбирайте источник серии внутри карточки.',libria:'Каталог, озвучка и HLS-видеопотоки. Возможны ограничения по региону.',anixart:'Каталог, озвучки, источники и эпизоды через Anixart API; видео зависит от поставщика.',anilist:'Мировой каталог и рейтинги. Без просмотра.',shiki:'Русскоязычная база аниме. Без видеопотоков.',jikan:'Метаданные MyAnimeList через Jikan v4; видео не выдаёт.',kodik:'Видео через Kodik по собственному API-токену. Встроенный плеер сервиса; возможны ограничения.',yani:'Аниме и озвучки через API Yani; нужен собственный X-Application токен разработчика.',mikai:'Украинские озвучки и субтитры: каталог и плееры по командам. Ключ не требуется; источник mikai.me.',sites:'Публичные страницы SovetRomantica, AnimeVost и SHIZA-Project: импорт по ссылке без API-ключа.'};
let toastTimer;
let upscaler=null;
let isSeekDragging=false;
let streamGeneration=0;
let playContext=null;
let lastProgressWrite=0;
let cachePolling=null;
let previousView="home";
let releaseLoadId=0;
function playerPosition(){const v=$('#video');return (playContext?.remote?playContext.offset:0)+(Number.isFinite(v.currentTime)?v.currentTime:0)}
function playerDuration(){const v=$('#video');return playContext?.remote&&playContext.duration>0?playContext.duration:(Number.isFinite(v.duration)?v.duration:0)}
async function resumeFrom(seconds){
 if(!playContext?.remote||!playContext.url||!Number.isFinite(seconds))return;
 const current=playContext;
 const next=Math.max(0,Math.min(Math.max(0,current.duration-2),seconds));
 if(Math.abs(next-playerPosition())<.4)return;
 await startStream(current.url,false,next,current);
}
async function saveProgress(force=false){
 if(!playContext?.record||!api.recordProgress)return;
 if(!force&&Date.now()-lastProgressWrite<7500)return;
 lastProgressWrite=Date.now();
 const duration=playerDuration();const position=Math.max(0,playerPosition());
 if(!Number.isFinite(position)||!Number.isFinite(duration)||duration<0)return;
 try{await api.recordProgress({...playContext.record,position,duration});}catch(e){console.warn('History save:',e.message)}
}
function beginCachePolling(url){
 clearInterval(cachePolling);cachePolling=null;
 const target=$('#player-cache-status');target.textContent='Проверка кэша…';
 async function poll(){
  try{const result=await api.cacheStatus(url);
   target.textContent=result.status==='cached'?`✓ В кэше (${Math.round(result.size/1048576)} МБ)`:result.status==='downloading'?'↓ Видео сохраняется в кэш':result.status==='error'?'Кэш: '+(result.error||'ошибка'):'Не закэшировано';
   if(result.status==='cached'||result.status==='error'){clearInterval(cachePolling);cachePolling=null}
  }catch(e){target.textContent='Кэш недоступен';clearInterval(cachePolling);cachePolling=null}
 }
 poll();cachePolling=setInterval(poll,4000);
}
function notify(message){const t=$('#toast');t.textContent=message;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),3400)}
function safeText(v){return String(v??'').trim()}
function setStatus(message,good){$('#status-text').textContent=message;$('#status-dot').className='online-dot'+(good===true?' online':good===false?' error':'')}
function isSaved(id){return state.bookmarks.some(x=>x.id===id)}
function setView(view){if(view!=='release'&&document.querySelector('#view-'+view)){previousView=view;if(location.hash.startsWith('#/release/'))history.replaceState(null,'',location.pathname+location.search+'#/'+view)}
 for(const page of document.querySelectorAll('.page'))page.classList.toggle('active',page.id===`view-${view}`);
 for(const nav of document.querySelectorAll('.nav-btn'))nav.classList.toggle('active',nav.dataset.view===view);
 const names={home:'Главная',bookmarks:'Моя библиотека',history:'История',accounts:'Мои аккаунты',sources:'Источники',settings:'Настройки',release:'Релиз'};
 $('#section-label').textContent=names[view]||view;$('#main-scroll').scrollTop=0;document.querySelector('#view-'+view)?.classList.remove('page-enter');requestAnimationFrame(()=>document.querySelector('#view-'+view)?.classList.add('page-enter'));
 if(view==='bookmarks')renderBookmarks();if(view==='history'){renderHistory();api.historyInfo?.().then(data=>{$('#history-path').textContent='TXT: '+data.historyTxt+' · Журнал: '+data.eventsTxt}).catch(()=>{});addCachedButtons().catch(e=>console.warn('cached history',e.message))}if(view==='sources')renderSources().catch(e=>notify('Источники: '+e.message));else stopSourcesPolling();if(view==='settings'){fillSettings();loadNetworkSettings();}if(view==='accounts')window.AniSpawnAccounts?.render();}
function el(tag,cls,text){const e=document.createElement(tag);if(cls)e.className=cls;if(text!=null)e.textContent=safeText(text);return e}
function empty(container,title,detail){container.replaceChildren();const div=el('div','empty-state');div.append(el('strong','',title),el('div','',detail));container.append(div)}
function makePoster(item){const poster=el('div','poster');
 if(item.image&&/^https:\/\//.test(item.image)){
  const img=el('img');img.src=item.image;img.alt='Обложка: '+item.name;img.loading='lazy';img.referrerPolicy='no-referrer';img.onerror=()=>img.replaceWith(el('div','poster-fallback',item.name));poster.append(img);
 }else poster.append(el('div','poster-fallback',item.name));
 const badge=el('span','poster-badge',(item.availableSources?.includes('libria')&&item.availableSources?.includes('anixart'))?'Anixart + AniLiberty':(sources[item.source]||'Anime'));poster.append(badge);
 const overlay=el('div','poster-overlay');overlay.append(el('button','round-play','▶'));poster.append(overlay);
 return poster;
}
function makeCard(item){const card=el('article','anime-card');card.tabIndex=0;card.setAttribute('role','button');card.setAttribute('aria-label',`Открыть ${item.name}`);card.dataset.id=item.id;
 const poster=makePoster(item);const bookmark=el('button','poster-bookmark'+(isSaved(item.id)?' saved':''),isSaved(item.id)?'◆':'◇');bookmark.type='button';bookmark.title='Переключить закладку';
 bookmark.addEventListener('click',async e=>{e.stopPropagation();await toggleBookmark(item);bookmark.classList.toggle('saved',isSaved(item.id));bookmark.textContent=isSaved(item.id)?'◆':'◇'});poster.append(bookmark);card.append(poster);
 card.append(el('div','card-title',item.name));const sub=el('div','card-subtitle');sub.append(el('span','',`${item.category||'Аниме'}${item.year?' · '+item.year:''}`));if(item.rating){sub.append(el('span','star',`★ ${Number(item.rating).toFixed(1)}`))}card.append(sub);
 if(item.blocked){const label=el('span','content-limit','Доступ к видео ограничен');label.title='Тайтл виден в каталоге, но воспроизведение ограничено сервисом';card.append(label)}
 card.addEventListener('click',()=>showDetails(item));card.addEventListener('keydown',e=>{if(e.target===card&&(e.key==='Enter'||e.key===' ')){e.preventDefault();showDetails(item)}});
 return card;
}
function renderCards(container,items,emptyTitle='Пока ничего нет'){container.replaceChildren();if(!items.length){empty(container,emptyTitle,'Попробуйте другой источник или поисковый запрос.');return}const fragment=document.createDocumentFragment();for(const item of items)fragment.append(makeCard(item));container.append(fragment)}
function renderBookmarks(){
 const root=$('#bookmark-grid');root.replaceChildren();
 if(!state.bookmarks.length){empty(root,'В библиотеке пока пусто','Добавьте аниме или войдите в Anixart / Yani — списки появятся здесь автоматически.');return}
 const statuses=['Смотрю','В планах','Просмотрено','Отложено','Брошено'];
 const groups=[...new Set([...statuses,...state.bookmarks.map(item=>item.status||'Локальные'),'Локальные'])];
 const shell=document.createElement('div');shell.className='library-groups';
 for(const group of groups){
  const found=state.bookmarks.filter(item=>(item.status||'Локальные')===group);
  if(!found.length)continue;
  const section=el('section','library-group');section.append(el('h2','library-group-title',group+' · '+found.length));
  const grid=el('div','card-grid');
  for(const item of found){const wrapper=el('div','library-entry');wrapper.append(makeCard(item));
   if(item.remoteAccount==='anixart'||item.remoteAccount==='yani'){
    const provider=item.remoteAccount;const options=provider==='anixart'?[[1,'Смотрю'],[2,'В планах'],[3,'Просмотрено'],[4,'Отложено'],[5,'Брошено']]:[[0,'Смотрю'],[1,'В планах'],[2,'Просмотрено'],[3,'Брошено'],[5,'Отложено']];
    const line=el('div','library-link');line.append(el('span','',provider==='anixart'?'Anixart':'Yani'));
    const select=el('select','library-status');select.setAttribute('aria-label','Изменить статус в '+provider);
    for(const [number,title] of options){const op=new Option(title,String(number));select.append(op)}
    const current=String(item.statusId??'');if([...select.options].some(o=>o.value===current))select.value=current;
    else{const custom=new Option(item.status||'Список',current);select.prepend(custom);select.value=current;}
    select.addEventListener('change',async()=>{select.disabled=true;try{const result=await api.setListStatus(item,Number(select.value));state.bookmarks=result.bookmarks;$('#bookmark-count').textContent=String(state.bookmarks.length);renderBookmarks();notify('Статус сохранён · синхронизация запущена');syncAll().catch(()=>{})}catch(e){notify(e.message);select.disabled=false}});
    line.append(select);wrapper.append(line);
   }grid.append(wrapper)}
  section.append(grid);shell.append(section)
 }root.append(shell);
}
async function syncAll(){if(!api.syncAll)return;const elStatus=$('#unified-sync-status');if(elStatus)elStatus.textContent='Синхронизация…';try{
 const data=await api.syncAll();const current=await api.getState();state.bookmarks=current.bookmarks;state.history=current.history;
 $('#bookmark-count').textContent=String(state.bookmarks.length);if($('#view-bookmarks').classList.contains('active'))renderBookmarks();if($('#view-history').classList.contains('active'))renderHistory();
 const connected=Object.entries(data.providers||{}).filter(([,v])=>v.connected);
 const errors=connected.filter(([,v])=>v.warning||v.status.startsWith('Офлайн'));
 const label=(connected.length?'Подключено: '+connected.map(([k])=>k).join(', '):'Нет подключённых аккаунтов')+(data.pending?' · ожидают отправки: '+data.pending:'')+(errors.length?' · ошибка сети/истории':' · синхронизировано');
 if(elStatus)elStatus.textContent=label;return data;
 }catch(e){if(elStatus)elStatus.textContent='Ошибка синхронизации: '+e.message;throw e}}
window.AniSpawnSync=syncAll;

function renderHistory(){const parent=$('#history-list');parent.replaceChildren();if(!state.history.length){empty(parent,'Нет истории просмотров','Откройте и запустите любой доступный эпизод.');return}
 for(const entry of state.history){const row=el('div','history-item');const info=el('div');info.append(el('strong','',entry.name||entry.id),el('div','',`Эпизод ${entry.episode} · ${entry.position?Math.floor(entry.position/60)+' мин просмотра · ':''}${new Date(entry.date).toLocaleString('ru-RU')}`));row.append(info);
 const button=el('button','soft-btn','Открыть →');button.addEventListener('click',()=>showDetails(state.itemMap.get(entry.id)||state.bookmarks.find(x=>x.id===entry.id)||{id:entry.id,name:entry.name}));row.append(button);parent.append(row);}}
async function addCachedButtons(){
 if(!api.cachedVideos)return;
 const clips=await api.cachedVideos();const rows=Array.from(document.querySelectorAll('#history-list .history-item'));
 for(let i=0;i<state.history.length;i++){
  const event=state.history[i],match=clips.filter(x=>x.id===event.id&&String(x.episode)===String(event.episode)).sort((a,b)=>b.date.localeCompare(a.date))[0];
  if(!match||!rows[i])continue;
  const button=el('button','soft-btn','▶ Из кэша');button.title=`${Math.round(match.size/1048576)} МБ · ${match.quality}`;
  button.addEventListener('click',async()=>{
   $('#player-title').textContent=event.name;$('#player-episode').textContent=`Оффлайн · эпизод ${event.episode}`;
   state.playerOptions={};$('#player-quality').replaceChildren();$('#player-quality').disabled=true;
   $('#player-cache-status').textContent='✓ MP4 из локального кэша';$('#player-modal').showModal();
   try{await startStream(await api.openCached(match.key),true);$('#player-cache-status').textContent='✓ MP4 из локального кэша'}catch(e){playerMessage(e.message)}
  });rows[i].append(button)
 }
}
async function toggleBookmark(item){try{const result=await api.toggleBookmark(item);state.bookmarks=result.bookmarks;$('#bookmark-count').textContent=String(state.bookmarks.length);notify(result.added?'Добавлено в закладки':'Удалено из закладок');if($('#view-bookmarks').classList.contains('active'))renderBookmarks();if(state.current?.id===item.id)updateDetailBookmark();if(item.id.startsWith('anixart:')||item.id.startsWith('yani:'))syncAll().catch(()=>{});}
 catch(e){notify(`Не удалось сохранить: ${e.message}`)}}
function updateDetailBookmark(){$('#detail-bookmark').textContent=isSaved(state.current?.id)?'◆ Убрать из закладок':'◇ В закладки'}
async function loadCatalog(query='',append=false){if(state.loading&&append)return;
 const requestId=++state.requestId;state.loading=true;state.search=append?state.search:query.trim();if(!append)state.page=1;
 setStatus('Загрузка каталога…');if(!append)empty($('#catalog-grid'),'Загружаем релизы','Подключаемся к выбранному API.');
 $('#load-more').hidden=true;
 try{const result=state.search?await api.search(state.source,state.search,state.page):await api.list(state.source,state.page);
  if(requestId!==state.requestId)return;
  const incoming=result.items||[];const newItems=append?incoming.filter(x=>!state.items.some(y=>y.id===x.id)):incoming;state.items=append?[...state.items,...newItems]:incoming;
  for(const item of state.items)state.itemMap.set(item.id,item);
  $('#results-title').textContent=state.search?'Результаты поиска':'Новые релизы';
  $('#results-counter').textContent=String(state.items.length)+' тайтлов';
  $('#anixart-search-note').hidden=!['anixart','both','all'].includes(state.source);
  $('#catalog-note').textContent=`Источник: ${sources[state.source]} · ${help[state.source]}${result.warning?' · '+result.warning:result.stale?' · Есть данные из кэша':''}`;
  renderCards($('#catalog-grid'),state.items,state.search?'Ничего не найдено':'В каталоге нет релизов');
  setStatus(result.stale?(result.items?.length?'Частично доступно':'Офлайн-кэш'):'Подключено',!result.stale);
  const paged=['all','both','libria','anixart','shiki','anilist','jikan','kodik','mikai','sites'].includes(state.source),directId=state.source==='anixart'&&/^(?:anixart:)?[0-9]{1,12}$/i.test(state.search);$('#load-more').hidden=directId||(!!state.search&&!['anixart'].includes(state.source))||!paged||incoming.length===0||newItems.length===0||result.stale;
 }catch(e){if(requestId!==state.requestId)return;empty($('#catalog-grid'),'Не удалось загрузить каталог',e.message);$('#catalog-note').textContent='Проверьте соединение и выберите другой источник. Локальные закладки остаются доступны.';setStatus('API недоступен',false)}
 finally{if(requestId===state.requestId)state.loading=false}
}
async function changeSource(source){if(!sources[source])return;state.source=source;$('#source-select').value=source;$('#source-help').textContent=help[source];$('#setting-source').value=source;
 try{await api.updateState({source})}catch(e){notify(e.message)}state.search='';$('#search-input').value='';state.page=1;setView('home');await loadCatalog();}
function releaseUrlFor(item){if(item?.source==='anixart'||String(item?.id||'').startsWith('anixart:'))return releaseRouter?.parse(String(item.id))?.href||'';return typeof item?.url==='string'?item.url:''}
function releasePreview(info){return {id:info.id,remoteId:info.remoteId,source:'anixart',name:'Релиз Anixart №'+info.remoteId,image:'',blocked:false,url:info.href}}
async function openReleaseLink(url,{navigate=true}={}){
 const info=releaseRouter?.parse(url);
 if(!info){notify('Неподдерживаемая ссылка релиза');return false}
 const item=state.itemMap.get(info.id)||state.bookmarks.find(x=>x.id===info.id)||releasePreview(info);
 await showDetails(item,{navigate});return true;
}
window.AniSpawnOpenReleaseLink=openReleaseLink;
function leaveRelease(){setView(previousView==='release'?'home':previousView);if(location.hash.startsWith('#/release/'))history.replaceState(null,'',location.pathname+location.search+'#/'+previousView)}
async function showDetails(item,{navigate=true}={}){
 if(!item?.id)return notify('Неизвестный ID релиза');
 item={...item,source:item.source||String(item.id).split(':')[0],name:item.name||'Релиз '+item.id};
 const serial=++releaseLoadId;
 state.current=item;
 if(navigate&&item.source==='anixart'){
  const route=releaseRouter?.parse(item.id);if(route&&location.hash!==route.hash)history.pushState({release:item.id},'',route.hash);
 }
 setView('release');
 $('#detail-source').textContent=sources[item.source]||'Аниме';$('#detail-title').textContent=item.name;
 $('#detail-embed').hidden=true;$('#detail-kinobox-results').replaceChildren();$('#detail-kinobox').disabled=false;$('#detail-meta').textContent='Загрузка подробностей…';$('#detail-desc').textContent='';$('#episode-list').replaceChildren();$('#detail-integrated-results').replaceChildren();$('#detail-integrated').hidden=true;setPoster(item);updateDetailBookmark();
 try{let detail=await api.details(item.id);if(detail?.stale&&detail?.placeholder&&item?.name&&!item.name.startsWith('Релиз Anixart №'))detail={...detail,name:item.name,image:item.image||detail.image,description:item.description||detail.description};if(serial!==releaseLoadId||state.current?.id!==item.id||!$('#view-release').classList.contains('active'))return;state.current=detail;state.itemMap.set(detail.id,detail);
  if((detail.source==='libria'||detail.source==='anixart')&&detail.name)loadRelatedSources(detail,serial,item.alternatives||[]).catch(e=>console.warn('related sources',e.message));$('#detail-title').textContent=detail.name;setPoster(detail);
  if(detail.blocked){$('#detail-kinobox').disabled=true;$('#detail-kinobox').title='Недоступно для заблокированного релиза'}
  $('#detail-meta').textContent=[detail.category,detail.year,detail.rating?`★ ${Number(detail.rating).toFixed(1)}`:'',detail.episodesTotal?`${detail.episodesTotal} эп.`:''].filter(Boolean).join(' · ');
  $('#detail-desc').textContent=(detail.description||'Описание отсутствует.')+(detail.credits?' · Источник: '+detail.credits:'');
  const list=$('#episode-list');list.replaceChildren();
  if(detail.source==='mikai'||detail.source==='yani'||detail.source==='sites'){
   if(detail.blocked){list.append(el('p','error-text',detail.licenseNotice||'Просмотр ограничен правообладателем. Откройте страницу источника для легального просмотра.'));return}
   if(!detail.players?.length)list.append(el('p','',detail.source==='sites'?'На публичной странице нет доступного встроенного плеера. Содержимое может требовать авторизации на сайте.':'Провайдер не вернул доступных видеоплееров. Проверьте доступность источника.'));
   else renderPlayerRows(detail.players,detail,list);
   return;
  }
  if(detail.source==='sites'){const remove=el('button','soft-btn','Удалить импорт');remove.addEventListener('click',async()=>{try{await api.removeSite(detail.id);notify('Импорт страницы удалён');setView('sources');await renderImportedSites();if(state.source==='sites')loadCatalog();}catch(e){notify(e.message)}});list.append(remove);return;}
  if(detail.source==='anixart'){
   if(detail.blocked){list.append(el('p','error-text',detail.accessNote||'Этот тайтл доступен в каталоге, но воспроизведение ограничено Anixart.'));return}
   if(detail.playersError)list.append(el('p','error-text',detail.playersError));
   if(!detail.dubs?.length)list.append(el('p','','Озвучки не найдены или API недоступен.'));
   else renderAnixartDubs(detail,list);
   return;
  }
  const embed=$('#detail-embed');embed.hidden=!(detail.source==='kodik'&&detail.embed);if(!embed.hidden)embed.onclick=()=>playKodik(detail);
  if(detail.blocked){list.append(el('p','error-text','Этот релиз ограничен поставщиком в вашем регионе или по запросу правообладателя.'));return}
  if(!detail.episodes?.length){list.append(el('p','',detail.source==='libria'?'Для этого релиза нет доступных HLS-эпизодов.':detail.source==='kodik'?(detail.embed?'Для воспроизведения откройте встроенный плеер.':'У записи Kodik отсутствует доступная ссылка плеера.'):'Этот API предоставляет информацию о тайтле, но не прямые ссылки на видео.'));return}
  for(const ep of detail.episodes){const row=el('div','episode-row');row.append(el('span','',`${ep.ordinal}. ${ep.name}`));const qualities=el('div','episode-quality');for(const quality of Object.keys(ep.quality).sort((a,b)=>Number(b)-Number(a))){const b=el('button','',quality+'p');b.addEventListener('click',()=>playEpisode(detail,ep,quality));qualities.append(b)}row.append(qualities);list.append(row)}
 }catch(e){$('#detail-meta').textContent='Ошибка загрузки';$('#episode-list').append(el('p','error-text',e.message));}
}
async function loadRelatedSources(detail,requestId,known=[]){
 // The primary release is rendered first; second provider is optional and slow
 // connectivity must not hold up the main player, login or bookmarks.
 const panel=$('#detail-integrated'),root=$('#detail-integrated-results');
 if(!panel||!root)return;
 panel.hidden=false;root.replaceChildren();root.append(el('p','source-fusion-status','Ищем серии второго источника…'));
 const matches=new Map();
 for(const match of known)if(match?.id&&match.id!==detail.id)matches.set(match.id,{...match,match:'exact'});
 let warning='';
 try{
  if(typeof api.relatedSources==='function'){
   const found=await api.relatedSources(detail.id,detail.name,detail.original||'',detail.year||'');
   for(const match of found.items||[])if(match?.id&&match.id!==detail.id)matches.set(match.id,match);
   warning=found.warning||'';
  }
 }catch(e){warning=e.message}
 if(requestId!==releaseLoadId||state.current?.id!==detail.id)return;
 root.replaceChildren();
 if(warning)root.append(el('p','source-fusion-status',`Дополнительный API: ${warning}`));
 if(matches.size===0){root.append(el('p','source-fusion-status','Совпадений пока нет. Используйте общий поиск, чтобы выбрать другой релиз вручную.'));return}
 for(const match of [...matches.values()].sort((a,b)=>(a.match==='exact'?0:1)-(b.match==='exact'?0:1))){
  const row=el('div','episode-row source-fusion-row');
  const label=match.match==='exact'?'Совпадает название':'Похожее название · проверьте сезон';
  const caption=el('span','',`${sources[match.source]||match.source} · ${match.name}${match.year?' · '+match.year:''} · ${label}`);
  const button=el('button','soft-btn art-action',match.source==='libria'?'Показать HLS-серии':'Показать озвучки');
  const area=el('div','source-fusion-episodes');
  button.addEventListener('click',async()=>{
   button.disabled=true;empty(area,'Подключаем второй источник','Загружаем данные выбранного релиза');
   try{
    const linked=await api.details(match.id);
    if(requestId!==releaseLoadId||state.current?.id!==detail.id)return;
    area.replaceChildren();
    if(linked.blocked){area.append(el('p','error-text','Видео этого источника ограничено поставщиком. Данные не используются для обхода блокировки.'));return}
    if(match.source==='libria'){
     if(!linked.episodes?.length){area.append(el('p','','Нет доступных серий AniLiberty.'));return}
     for(const ep of linked.episodes){const line=el('div','episode-row');line.append(el('span','',`${ep.ordinal}. ${ep.name}`));const qualities=el('div','episode-quality');
      for(const quality of Object.keys(ep.quality||{}).sort((a,b)=>Number(b)-Number(a))){const b=el('button','',quality+'p');b.addEventListener('click',()=>playEpisode(linked,ep,quality));qualities.append(b)}line.append(qualities);area.append(line)}
    }else if(linked.dubs?.length){renderAnixartDubs(linked,area,detail.id)}
    else area.append(el('p','',linked.playersError||'У Anixart пока нет доступных озвучек.'));
   }catch(e){empty(area,'Источник недоступен',e.message)}finally{button.disabled=false}
  });
  row.append(caption,button);root.append(row,area);
 }
}

function renderPlayerRows(players,detail,container){
 for(const player of players){const row=el('div','episode-row');const caption=el('span','',`Эп. ${player.episode||'?'} · ${player.name||player.provider||'Источник'}`);row.append(caption);
  const button=el('button','soft-btn art-action',player.embed?'Смотреть':'Открыть плеер');const art=el('img','art-icon');art.src='./assets/ui-buttons/'+(player.embed?'play':'back')+'.png';art.alt='';button.prepend(art);
  button.addEventListener('click',()=>player.embed?playEmbed(detail,player):openExternalPlayer(detail,player));row.append(button);
  if(player.embed&&player.linkToken){const external=el('button','soft-btn','↗ В браузере');external.title='Если встроенный плеер не загружается';external.addEventListener('click',()=>openExternalPlayer(detail,player));row.append(external)}container.append(row)}
}
async function openExternalPlayer(detail,player){
 if(!player.linkToken)return notify('Ссылка плеера недоступна');
 try{await api.openPlayer(player.linkToken);notify('Открыт плеер поставщика · локальный апскейл для него недоступен')}catch(e){notify('Не удалось открыть: '+e.message)}
}
function renderAnixartDubs(detail,container,rootId=detail.id){
 const controls=el('div','provider-controls');const voice=el('select');voice.setAttribute('aria-label','Выберите озвучку');
 for(const dub of detail.dubs){const option=el('option','',(dub.sub?'Субтитры · ':'')+dub.name);option.value=String(dub.id);voice.append(option)}
 const source=el('select');source.setAttribute('aria-label','Выберите источник');source.disabled=true;
 const load=el('button','soft-btn','Показать серии');source.hidden=true;controls.append(voice,source,load);container.append(controls);
 const rows=el('div','provider-episodes');container.append(rows);
 let request=0;
 async function loadSources(){const req=++request;source.disabled=true;source.hidden=true;source.replaceChildren();empty(rows,'Подключаемся…','Загружаем источники выбранной озвучки');
  try{const items=await api.anixartSources(detail.id,Number(voice.value));if(req!==request||state.current?.id!==rootId)return;
   rows.replaceChildren();if(!items.length){rows.append(el('p','','У этой озвучки нет доступных источников.'));return}
   for(const item of items){const op=el('option','',`${item.name} · ${item.count||'?'} эп.`);op.value=String(item.id);source.append(op)}
   source.disabled=false;source.hidden=false;await loadEpisodes();
  }catch(e){if(req===request){empty(rows,'Не удалось получить источники',e.message)}}
 }
 async function loadEpisodes(){const req=++request;empty(rows,'Загружаем серии','Запрос к Anixart');
  try{const players=await api.anixartEpisodes(detail.id,Number(voice.value),Number(source.value));if(req!==request||state.current?.id!==rootId)return;
   rows.replaceChildren();if(players.length)renderPlayerRows(players,detail,rows);else rows.append(el('p','','Источник не вернул доступных видеоссылок.'));
  }catch(e){if(req===request)empty(rows,'Ошибка источника',e.message)}
 }
 voice.addEventListener('change',loadSources);source.addEventListener('change',loadEpisodes);load.addEventListener('click',()=>source.disabled?loadSources():loadEpisodes());
 loadSources();
}
async function findKinoboxForCurrent(){
 const detail=state.current;if(!detail)return;if(detail.blocked)return notify('Просмотр релиза ограничен поставщиком');const root=$('#detail-kinobox-results');root.replaceChildren();const button=$('#detail-kinobox');button.disabled=true;
 root.append(el('p','','Ищем дополнительные плееры по названию. Доступность и права зависят от хостинга.'));
 try{const players=await api.findPlayers(detail.name);if(state.current?.id!==detail.id)return;
  root.replaceChildren();if(players.length)renderPlayerRows(players,detail,root);else root.append(el('p','','Kinobox не вернул плееры с разрешёнными HTTPS-ссылками.'));
 }catch(e){empty(root,'Kinobox недоступен',e.message)}finally{button.disabled=false}
}
function setPoster(item){const container=$('#detail-poster');container.replaceChildren();if(item.image?.startsWith('https://')){const img=el('img');img.src=item.image;img.alt=item.name;img.onerror=()=>img.replaceWith(el('span','','✦'));container.append(img)}else container.append(el('span','','✦'))}
function playerMessage(msg){const e=$('#player-message');e.textContent=msg;e.hidden=!msg}
function updateUpscaleMessage(message,level='info'){
 const text=$('#upscale-state');text.textContent=message;text.dataset.level=level;
}
function updateUpscaleUI(){
 const config=state.upscale=upscaleAPI.normalizeUpscale(state.upscale);
 $('#player-upscale-enabled').checked=config.enabled;$('#player-upscale-mode').value=config.mode;$('#player-upscale-scale').value=String(config.scale);
 $('#setting-upscale-enabled').checked=config.enabled;$('#setting-upscale-mode').value=config.mode;$('#setting-upscale-scale').value=String(config.scale);
 $('#setting-upscale-strength').value=Math.round(config.strength*100);
 $('#setting-upscale-strength-value').textContent=Math.round(config.strength*100)+'%';
}
function allowUpscale(enabled){
 for(const id of ['#player-upscale-enabled','#player-upscale-mode','#player-upscale-scale'])$(id).disabled=!enabled;
 if(!enabled){$('#player-compare').disabled=true;$('#player-compare').title='Для Kodik используется закрытый сторонний плеер, кадры недоступны';}
 else $('#player-compare').title='Удерживайте кнопку, чтобы увидеть кадр без апскейла';
}
function ensureUpscaler(){
 if(!upscaleAPI)throw new Error('Модуль GPU-апскейла не загружен');
 if(!upscaler)upscaler=upscaleAPI.createUpscaler($('#video'),$('#upscale-canvas'),{
  stage:$('#video-box'),settings:state.upscale,onStatus:(message,level)=>{
   updateUpscaleMessage(message,level);$('#player-compare').disabled=level!=='ok';
  }
 });
 return upscaler;
}
function applyUpscale(){
 updateUpscaleUI();
 if(!$('#embed-player').hidden){allowUpscale(false);updateUpscaleMessage('Апскейл недоступен для iframe Kodik');return;}
 allowUpscale(true);
 if(!state.upscale.enabled){upscaler?.stop();$('#player-compare').disabled=true;updateUpscaleMessage('Апскейл выключен');return;}
 try{const engine=ensureUpscaler();engine.configure(state.upscale);engine.start();}
 catch(error){upscaler?.stop();$('#player-compare').disabled=true;updateUpscaleMessage('Обычное видео: '+error.message,'error');}
}
function updatePlayback(){
 const video=$('#video');$('#playback-toggle').textContent=video.paused?'▶':'❚❚';
 $('#playback-mute').textContent=video.muted||video.volume===0?'🔇':'🔊';
 $('#playback-volume').value=Math.round(video.volume*100);
 const duration=playerDuration();
 if(!isSeekDragging)$('#playback-seek').value=duration?Math.round(playerPosition()/duration*1000):0;
 $('#playback-seek').disabled=!duration;
 const t=seconds=>{if(!Number.isFinite(seconds))return '00:00';const s=Math.max(0,Math.floor(seconds));const x=n=>String(n).padStart(2,'0');return s>=3600?`${x(Math.floor(s/3600))}:${x(Math.floor(s/60)%60)}:${x(s%60)}`:`${x(Math.floor(s/60))}:${x(s%60)}`};
 $('#playback-time').textContent=t(playerPosition())+' / '+t(duration);
}
function destroyVideo(keepContext=false){clearInterval(cachePolling);cachePolling=null;if(!keepContext)playContext=null;streamGeneration++;upscaler?.stop();$('#player-compare').disabled=true;updateUpscaleMessage('Апскейл выключен');if(state.hls){state.hls.destroy();state.hls=null}const frame=$('#embed-player');frame.removeAttribute('src');frame.hidden=true;const v=$('#video');v.pause();v.removeAttribute('src');v.load();v.hidden=false;playerMessage('')}
async function startStream(url,local=false,startAt=0,existing=null){const previous=existing||((!local&&playContext?.url===url)?playContext:null);destroyVideo(!!previous);if(previous)playContext={...previous,offset:startAt};const streamId=streamGeneration;const video=$('#video');video.crossOrigin='anonymous';$('#playback-controls').hidden=false;$('#player-quality').disabled=local;playerMessage('');$('#player-status').textContent='Подключение…';allowUpscale(true);
 try{
  const src=local?url:(await api.prepareStream(url))+(startAt?'?start='+encodeURIComponent(startAt):'');
  if(streamId!==streamGeneration)return;
  if(/\.m3u8/i.test(url) && !/\/media\/[a-f0-9]+\.mp4(?:\?|$)/.test(src)){
   if(window.Hls&&window.Hls.isSupported()){
    const hls=new window.Hls({enableWorker:false,maxBufferLength:45});state.hls=hls;
    hls.on(window.Hls.Events.ERROR,(_event,data)=>{if(data.fatal){playerMessage(`Ошибка HLS (${data.type}). Этот поток может быть недоступен в регионе или требовать разрешения правообладателя.`);$('#player-status').textContent='Ошибка воспроизведения';hls.destroy();state.hls=null;}});
    hls.loadSource(src);hls.attachMedia(video);
   }else if(video.canPlayType('application/vnd.apple.mpegurl'))video.src=src;
   else throw new Error('HLS не поддерживается данным движком');
  }else video.src=src;
  video.volume=state.volume;applyUpscale();updatePlayback();$('#player-status').textContent=startAt?'Перемотка…':'Воспроизведение';
  video.play().catch(()=>{$('#player-status').textContent='Нажмите Play для запуска'});
 }catch(e){playerMessage(e.message);$('#player-status').textContent='Ошибка источника';upscaler?.stop()}
}
async function playEpisode(detail,ep,quality){state.playerOptions=ep.quality;playContext={remote:true,url:ep.quality[quality],offset:0,duration:ep.duration||0,record:{id:detail.id,episode:String(ep.ordinal),name:detail.name}};
 const select=$('#player-quality');select.replaceChildren();for(const q of Object.keys(ep.quality).sort((a,b)=>Number(b)-Number(a))){const o=el('option','',q+'p');o.value=q;select.append(o)}select.disabled=false;select.value=quality;
 $('#player-title').textContent=detail.name;$('#player-episode').textContent=`${ep.name} · AniLiberty`;$('#player-modal').showModal();await startStream(ep.quality[quality]);
 beginCachePolling(ep.quality[quality]);
 if(state.cacheVideo!==false)api.cacheVideo(ep.quality[quality],{id:detail.id,episode:String(ep.ordinal),name:detail.name,quality}).catch(e=>{$('#player-cache-status').textContent='Ошибка кэша: '+e.message});
 try{state.history=await api.recordWatch({id:detail.id,episode:String(ep.ordinal),name:detail.name})}catch(e){notify('История не сохранена: '+e.message)}
}
function playEmbed(detail,player){
 if(!/^https:\/\/[a-z0-9.-]+(?:\/[\s\S]*)?$/i.test(player.embed||''))return notify('Источник iframe не разрешён');
 destroyVideo();$('#video').hidden=true;$('#playback-controls').hidden=true;allowUpscale(false);updateUpscaleMessage('Сторонний iframe: GPU-апскейл и локальная перемотка недоступны');
 const frame=$('#embed-player');frame.hidden=false;frame.src=player.embed;$('#player-cache-status').textContent='Кэш видео недоступен для iframe';
 $('#player-title').textContent=detail.name;$('#player-episode').textContent=(sources[detail.source]||detail.source)+' · '+player.name+' · Эп. '+player.episode;$('#player-quality').disabled=true;$('#player-status').textContent='Внешний плеер '+(sources[detail.source]||'');$('#player-modal').showModal();
 api.recordWatch({id:detail.id,episode:player.episode,name:detail.name}).then(history=>state.history=history).catch(()=>{});
}
function playKodik(detail){
 if(!/^https:\/\/(?:[\w-]+\.)*(?:kodik\.info|kodikplayer\.com)\//i.test(detail.embed||'')){notify('Некорректная ссылка Kodik');return}
 destroyVideo();$('#video').hidden=true;$('#playback-controls').hidden=true;allowUpscale(false);updateUpscaleMessage('Апскейл недоступен для Kodik');const frame=$('#embed-player');frame.hidden=false;frame.src=detail.embed;
 $('#player-title').textContent=detail.name;$('#player-episode').textContent='Kodik · внешний плеер внутри AniSpawn';$('#player-quality').replaceChildren();$('#player-quality').disabled=true;
 $('#player-cache-status').textContent='Для Kodik недоступен кэш потоков';$('#player-status').textContent='Воспроизведение через Kodik';$('#player-modal').showModal();
 api.recordWatch({id:detail.id,episode:'Kodik',name:detail.name}).then(history=>state.history=history).catch(()=>{});
}
async function playLocal(){const url=await api.chooseVideo();if(!url)return;$('#player-cache-status').textContent='Локальный файл · скачивание не требуется';state.playerOptions={};const select=$('#player-quality');select.replaceChildren();select.disabled=true;
 $('#player-title').textContent='Локальный видеофайл';$('#player-episode').textContent='Воспроизведение с компьютера';$('#player-modal').showModal();await startStream(url,true)}
function closePlayer(){saveProgress(true);destroyVideo();if($('#player-modal').open)$('#player-modal').close();}
async function renderImportedSites(){const root=$('#site-import-list');if(!root||!api.list)return;try{const response=await api.list('sites',1);const items=response.items||[];for(const item of items)state.itemMap.set(item.id,item);renderCards(root,items,'Пока нет импортированных страниц');}catch(e){empty(root,'Импортированные страницы недоступны',e.message)}}
async function importSitePage(url){const status=$('#site-import-status');status.textContent='Читаем публичную страницу…';try{const item=await api.importSite(url);state.itemMap.set(item.id,item);status.textContent='Добавлено: '+item.name+(item.playable?' · Есть встроенный плеер':' · Без доступного встроенного плеера');await renderImportedSites();if(['sites','all','both'].includes(state.source))await loadCatalog();return item}catch(e){status.textContent='Импорт не выполнен: '+e.message;throw e}}
const sourceStateLabels={online:'Доступен',cached:'Из кэша',offline:'Недоступен',checking:'Проверяем…',auth_required:'Требуется ключ',saved:'Сохранено локально',not_imported:'Не импортировано',unknown:'Не проверен'};
const sourceSiteEntries=[{id:'site-sovetromantica',name:'SovetRomantica · сайт',description:'Публичная страница ранее импортированного релиза. Состояние сайта не означает доступность видео.',kind:'embedded'},
{id:'site-animevost',name:'AnimeVost · сайт',description:'Проверяется только ранее импортированная пользователем страница.',kind:'embedded'},
{id:'site-shiza',name:'SHIZA-Project · сайт',description:'Без массового обхода: проверяется только сохранённая публичная ссылка.',kind:'embedded'}];
let statusPollTimer=null;
let sourcesOpened=false;
function updateSourceStatuses(snapshot){
 if(!snapshot)return;
 const data=snapshot.sources||{};
 for(const [id,result] of Object.entries(data)){
  const badge=document.querySelector(`.source-indicator[data-source="${id}"]`);
  if(!badge)continue;
  const status=result.state||'unknown';badge.className='source-indicator state-'+status;
  const count=result.count&&['online','cached','saved'].includes(status)?` · ${result.count}`:'';
  const delay=Number.isFinite(result.ms)?` · ${result.ms} мс`:'';
  badge.textContent=(sourceStateLabels[status]||status)+count+delay;
  badge.title=result.message||badge.textContent;
  const detail=document.querySelector(`.source-detail[data-source="${id}"]`);
  if(detail)detail.textContent=result.message||'';
 }
 const summary=snapshot.summary||{};
 const summaryNode=$('#sources-summary');
 if(summaryNode)summaryNode.textContent=(snapshot.testing?'Проверка идёт · ':'')+
  `${summary.online||0} API доступны · ${summary.cached||0} из кэша · ${summary.authRequired||0} требуют ключ`;
}
function stopSourcesPolling(){clearTimeout(statusPollTimer);statusPollTimer=null;}
async function pollSourcesStatus(){
 stopSourcesPolling();if(!$('#view-sources').classList.contains('active'))return;
 try{const info=await api.sourceStatus();updateSourceStatuses(info);
  if(info.testing){statusPollTimer=setTimeout(pollSourcesStatus,1400);}}
 catch(e){const node=$('#sources-summary');if(node)node.textContent='Ошибка проверки: '+e.message;}
}
async function renderSources(){
 await renderImportedSites();const root=$('#sources-list');root.replaceChildren();
 const providers=[...await api.sources(),...sourceSiteEntries];
 for(const source of providers){
  const row=el('div','source-row');const body=el('div','source-info');
  body.append(el('div','source-title',source.name),el('p','',source.description));
  const info=el('small','source-detail','');info.dataset.source=source.id;body.append(info);row.append(body);
  const indicator=el('span','source-indicator state-unknown','Не проверен');indicator.dataset.source=source.id;
  indicator.title=source.kind==='catalog'?'Только метаданные':source.kind==='video'?'Прямое видео или объединение':'Внешний плеер / HTML';
  row.append(indicator);root.append(row)
 }
 try{const info=await api.sourceStatus();updateSourceStatuses(info);
  if(!sourcesOpened){sourcesOpened=true;await api.refreshSourceStatus();}
  await pollSourcesStatus();
 }catch(e){$('#sources-summary').textContent='Диагностика недоступна: '+e.message;}
}
async function checkAll(){
 if(!$('#view-sources').classList.contains('active'))setView('sources');
 const btn=$('#check-all');btn.disabled=true;
 try{await api.refreshSourceStatus();await pollSourcesStatus();}
 catch(e){notify('Проверка источников: '+e.message)}finally{btn.disabled=false}
}
let networkStatusTimer=null;
function showNetworkStatus(net){
 const status=$('#network-status'), table=$('#network-results');
 if(!status||!table)return;
 const name={system:'Системный DNS',cloudflare:'Cloudflare',google:'Google',adguard:'AdGuard',proxy:'Прокси'};
 status.textContent=net.testing?'Проверка DNS идёт в фоне…':net.tested?`Выбран: ${name[net.effectiveDns]||net.effectiveDns}. ${net.proxy?'Прокси активен для API; окно нужно перезапустить.':'Для DNS встроенного плеера после смены настроек перезапустите AniSpawn.'}`:'Тест DNS будет выполнен при первом запуске приложения.';
 table.replaceChildren();
 for(const item of net.results||[]){
  const row=document.createElement('div');row.className='network-test-row';
  const indicator=item.ok?'✓':'×';
  row.textContent=`${indicator} ${item.name} · HTTPS ${item.httpsOk}/${item.checks||3} · ${item.ms} мс${item.error?' · '+item.error:''}`;
  if(item.id===net.selected)row.classList.add('selected');
  table.append(row);
 }
}
async function loadNetworkSettings(){
 if(!api.networkStatus)return;
 try{const net=await api.networkStatus();$('#network-dns').value=net.mode;$('#network-proxy').value=net.proxy;showNetworkStatus(net);
  if(net.testing||!net.tested){clearTimeout(networkStatusTimer);networkStatusTimer=setTimeout(loadNetworkSettings,1600);}
 }catch(e){$('#network-status').textContent='Сеть: '+e.message}
}
async function applyNetworkSettings(){
 try{const net=await api.networkConfigure({mode:$('#network-dns').value,proxy:$('#network-proxy').value.trim()});showNetworkStatus(net);notify('Сеть сохранена. Перезапустите AniSpawn для применения к встроенным плеерам.');}
 catch(e){notify('Ошибка сети: '+e.message)}
}
async function benchmarkNetwork(){
 $('#network-test').disabled=true;$('#network-status').textContent='Проверяем DNS и HTTPS подключение к двум API. Это может занять несколько секунд…';
 try{const net=await api.networkBenchmark();showNetworkStatus(net);notify('Проверка DNS завершена.');}
 catch(e){notify('Проверка DNS: '+e.message)}
 finally{$('#network-test').disabled=false}
}
async function diagnoseAnixart(){
 const button=$('#anixart-diagnose'),target=$('#anixart-diagnostics');
 if(!api.anixartDiagnose)return;
 button.disabled=true;target.replaceChildren();target.append(el('p','', 'Проверяем российский и резервный Anixart API. Пароли и токены не отправляются…'));
 try{
  const result=await api.anixartDiagnose();target.replaceChildren();target.append(el('p','', result.summary));
  for(const entry of result.hosts||[]){
   const row=el('div','network-test-row'+(entry.api?' selected':''));
   row.textContent=`${entry.api?'✓':'×'} ${entry.host} · TLS ${entry.tls?'да':'нет'} · HTTP ${entry.http??'—'} · ${entry.ms} мс${entry.error?' · '+entry.error:''}`;
   target.append(row);
  }
 }catch(e){target.textContent='Ошибка диагностики: '+e.message}
 finally{button.disabled=false}
}
function fillSettings(){$('#setting-cache-video').checked=state.cacheVideo!==false;$('#setting-source').value=state.source;$('#setting-theme').value=state.theme;$('#setting-quality').value=state.quality;updateUpscaleUI()}
async function saveSettings(){const source=$('#setting-source').value;state.theme=$('#setting-theme').value;state.cacheVideo=$('#setting-cache-video').checked;state.quality=$('#setting-quality').value;state.upscale=upscaleAPI.normalizeUpscale({enabled:$('#setting-upscale-enabled').checked,mode:$('#setting-upscale-mode').value,scale:Number($('#setting-upscale-scale').value),strength:Number($('#setting-upscale-strength').value)/100});document.body.className='theme-'+state.theme;
 try{if($('#kodik-token').value){await api.configureKodik($('#kodik-token').value);$('#kodik-token').value='';notify('Kodik-токен принят на текущий сеанс')}await api.updateState({theme:state.theme,quality:state.quality,upscale:state.upscale,cacheVideo:state.cacheVideo});if(source!==state.source)await changeSource(source);else notify('Настройки сохранены')}catch(e){notify(e.message)}}
async function init(){if(!api){setStatus('Запустите AniSpawn Desktop',false);empty($('#catalog-grid'),'Не настольная версия','Запустите команду npm start.');return}
 try{Object.assign(state,await api.getState());state.upscale=upscaleAPI.normalizeUpscale(state.upscale)}catch(e){notify('Не удалось загрузить настройки: '+e.message)}
 document.body.className='theme-'+state.theme;$('#source-select').value=state.source;$('#bookmark-count').textContent=String(state.bookmarks.length);$('#source-help').textContent=help[state.source];fillSettings();loadNetworkSettings();
 window.setAniSpawnView=setView;window.AniSpawnAccounts?.init();
 for(const b of document.querySelectorAll('[data-view]'))b.addEventListener('click',()=>{if(location.hash.startsWith('#/release/'))history.pushState(null,'','#/'+b.dataset.view);setView(b.dataset.view)});
 $('#detail-back').addEventListener('click',leaveRelease);
 window.addEventListener('popstate',()=>{const linked=releaseRouter?.fromHash(location.hash);if(linked)openReleaseLink(linked.href,{navigate:false});else if($('#view-release').classList.contains('active')){const view=location.hash.slice(2);setView(document.querySelector('#view-'+view)?view:previousView)}});
 document.addEventListener('click',e=>{const anchor=e.target.closest?.('a[href]');if(!anchor)return;const release=releaseRouter?.parse(anchor.href);if(release){e.preventDefault();openReleaseLink(anchor.href)}});
 $('#hero-explore').addEventListener('click',()=>$('#catalog-grid').scrollIntoView({behavior:'smooth'}));
 $('#search-form').addEventListener('submit',e=>{e.preventDefault();const query=$('#search-input').value.trim();if(/^https:\/\/(?:www\.)?(?:sovetromantica\.com|animevost\.org|shiza-project\.com)\//i.test(query)){importSitePage(query).then(item=>showDetails(item)).catch(()=>setView('sources'));return}const release=releaseRouter?.parse(query);if(release){openReleaseLink(query);return}state.page=1;loadCatalog(query)});
 $('#site-import-form').addEventListener('submit',async e=>{e.preventDefault();const btn=e.currentTarget.querySelector('button[type=submit]');btn.disabled=true;try{await importSitePage($('#site-import-url').value.trim())}catch(e){}finally{btn.disabled=false}});
 $('#reload-catalog').addEventListener('click',()=>loadCatalog(state.search));$('#rail-refresh').addEventListener('click',()=>loadCatalog(state.search));
 $('#load-more').addEventListener('click',async()=>{state.page++;await loadCatalog('',true)});
 $('#source-select').addEventListener('change',e=>changeSource(e.target.value));
 // Settings is a single navigation button in the sidebar.
 $('#rail-notifications').addEventListener('click',()=>checkAll());$('#check-all').addEventListener('click',()=>checkAll());
 for(const id of ['#rail-local','#hero-local','#side-local'])$(id).addEventListener('click',playLocal);
 $('#save-settings').addEventListener('click',saveSettings);
 $('#network-apply').addEventListener('click',applyNetworkSettings);
 $('#network-test').addEventListener('click',benchmarkNetwork);
 $('#anixart-diagnose').addEventListener('click',diagnoseAnixart);
 $('#unified-sync').addEventListener('click',()=>syncAll().catch(e=>notify(e.message)));
 setInterval(()=>{if(document.visibilityState==='visible')syncAll().catch(()=>{})},5*60*1000);
 $('#detail-kinobox').addEventListener('click',findKinoboxForCurrent);
 $('#detail-bookmark').addEventListener('click',()=>state.current&&toggleBookmark(state.current));
 $('#detail-external').addEventListener('click',async()=>{const url=releaseUrlFor(state.current);if(!url)return notify('Нет ссылки на страницу релиза');try{await navigator.clipboard.writeText(url);notify('Ссылка на релиз скопирована')}catch(e){notify('Ссылка: '+url)}});
 for(const btn of document.querySelectorAll('[data-close]'))btn.addEventListener('click',()=>$('#'+btn.dataset.close).close());
 $('#player-close').addEventListener('click',closePlayer);
 $('#player-fullscreen').addEventListener('click',()=>($('#embed-player').hidden?$('#video-box'):$('#embed-player')).requestFullscreen().catch(e=>notify(e.message)));
 $('#player-quality').addEventListener('change',async e=>{
  const paused=$('#video').paused,seconds=playerPosition(),nextUrl=state.playerOptions[e.target.value];
  if(!nextUrl)return;
  if(playContext?.remote){const ctx={...playContext,url:nextUrl};await startStream(nextUrl,false,seconds,ctx);beginCachePolling(nextUrl);if(state.cacheVideo!==false)api.cacheVideo(nextUrl,{...(playContext?.record||{}),quality:e.target.value}).catch(()=>{});}
  else{await startStream(nextUrl);$('#video').addEventListener('loadedmetadata',()=>{if(paused)$('#video').pause()},{once:true})}
 });
 $('#setting-upscale-strength').addEventListener('input',e=>$('#setting-upscale-strength-value').textContent=e.target.value+'%');
 $('#player-upscale-enabled').addEventListener('change',e=>{state.upscale.enabled=e.target.checked;applyUpscale();api.updateState({upscale:state.upscale}).catch(()=>{})});
 for(const [id,key,parse] of [['#player-upscale-mode','mode',String],['#player-upscale-scale','scale',Number]])$(id).addEventListener('change',e=>{state.upscale[key]=parse(e.target.value);applyUpscale();api.updateState({upscale:state.upscale}).catch(()=>{})});
 $('#player-compare').disabled=true;
 $('#player-compare').addEventListener('pointerdown',e=>{if(upscaler?.ready){e.preventDefault();upscaler.compare(true)}});
 for(const event of ['pointerup','pointercancel','pointerleave'])$('#player-compare').addEventListener(event,()=>upscaler?.compare(false));
 $('#player-compare').addEventListener('blur',()=>upscaler?.compare(false));
 $('#playback-toggle').addEventListener('click',()=>{$('#video').paused?$('#video').play().catch(e=>notify(e.message)):$('#video').pause()});
 $('#playback-mute').addEventListener('click',()=>{$('#video').muted=!$('#video').muted;updatePlayback()});
 $('#playback-volume').addEventListener('input',e=>{const v=$('#video');v.volume=Number(e.target.value)/100;if(v.volume>0)v.muted=false;updatePlayback()});
 $('#playback-seek').addEventListener('pointerdown',()=>isSeekDragging=true);
 $('#playback-seek').addEventListener('input',e=>{
  const target=Number(e.target.value)/1000*playerDuration();
  if(playContext?.remote){$('#playback-time').textContent=Math.floor(target/60)+':'+String(Math.floor(target%60)).padStart(2,'0')+' / '+Math.floor(playerDuration()/60)+':'+String(Math.floor(playerDuration()%60)).padStart(2,'0')}
  else{const v=$('#video');if(Number.isFinite(v.duration))v.currentTime=target;updatePlayback()}
 });
 $('#playback-seek').addEventListener('change',e=>{if(playContext?.remote)resumeFrom(Number(e.target.value)/1000*playerDuration()).catch(err=>playerMessage(err.message))});
 for(const event of ['pointerup','pointercancel','change'])$('#playback-seek').addEventListener(event,()=>{isSeekDragging=false;updatePlayback()});
 for(const event of ['play','pause','timeupdate','durationchange','loadedmetadata','seeking','seeked','volumechange','ended'])$('#video').addEventListener(event,updatePlayback);
 $('#video-box').addEventListener('click',event=>{if(event.target===$('#video')||event.target===$('#upscale-canvas')){$('#video').paused?$('#video').play().catch(()=>{}):$('#video').pause()}});
 document.addEventListener('keydown',e=>{
  if(!$('#player-modal').open||!$('#embed-player').hidden||e.altKey||e.ctrlKey||e.metaKey)return;
  if(e.target instanceof Element&&e.target.closest('input,select,button,textarea,[contenteditable=true]'))return;
  const v=$('#video');
  if(e.code==='Space'||e.code==='KeyK'){e.preventDefault();v.paused?v.play().catch(()=>{}):v.pause()}
  if(e.code==='ArrowRight'&&playerDuration()){e.preventDefault();playContext?.remote?resumeFrom(playerPosition()+10):v.currentTime=Math.min(v.duration,v.currentTime+10)}
  if(e.code==='ArrowLeft'&&playerDuration()){e.preventDefault();playContext?.remote?resumeFrom(playerPosition()-10):v.currentTime=Math.max(0,v.currentTime-10)}
  if(e.code==='KeyM'){e.preventDefault();v.muted=!v.muted;updatePlayback()}
  if(e.code==='KeyU'){e.preventDefault();state.upscale.enabled=!state.upscale.enabled;applyUpscale();api.updateState({upscale:state.upscale}).catch(()=>{})}
  if(e.code==='KeyF'){e.preventDefault();$('#video-box').requestFullscreen().catch(()=>{})}
 });
 $('#video').addEventListener('timeupdate',()=>saveProgress());$('#video').addEventListener('ended',()=>saveProgress(true));
 $('#video').addEventListener('volumechange',()=>{state.volume=$('#video').volume;api.updateState({volume:state.volume}).catch(()=>{})});
 $('#video').addEventListener('error',()=>{if($('#video').error){playerMessage('Не удалось декодировать видео. Проверьте формат, сеть и доступность трансляции.');$('#player-status').textContent='Ошибка видео'}});
 $('#player-modal').addEventListener('close',()=>{saveProgress(true);destroyVideo()});

 $('#player-modal').addEventListener('click',e=>{if(e.target===$('#player-modal'))closePlayer()});
 await loadCatalog();
 const linked=releaseRouter?.fromHash(location.hash);if(linked)openReleaseLink(linked.href,{navigate:false});
}
init();
