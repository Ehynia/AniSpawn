/* AniSpawn desktop bridge. All privileged operations remain in localhost-only Python. */
(function () {
  'use strict';
  if(window.anispawn) return; // Preserve native Electron IPC when Electron is available.
  async function call(method, ...args) {
    const response = await fetch('./rpc', {
      method: 'POST', mode: 'same-origin', cache: 'no-store',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({method, args})
    });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || 'Backend error');
    return payload.result;
  }
  let previousFileUrl = null;
  function chooseVideo(){
    return new Promise(resolve => {
      const input=document.createElement('input');
      input.type='file';input.accept='video/mp4,video/webm,video/ogg,video/quicktime,.m4v';
      input.style.display='none';document.body.appendChild(input);
      let settled=false;
      function settle(url){if(settled)return;settled=true;input.remove();resolve(url);}
      input.addEventListener('change',()=>{
        const f=input.files && input.files[0];
        if(!f)return settle(null);
        if(previousFileUrl)URL.revokeObjectURL(previousFileUrl);
        previousFileUrl=URL.createObjectURL(f);settle(previousFileUrl);
      },{once:true});
      window.addEventListener('focus',()=>setTimeout(()=>{if(!input.files?.length)settle(null)},700),{once:true});
      input.click();
    });
  }
  window.anispawn=Object.freeze({
    sources:()=>call('sources'),sourceStatus:()=>call('sourceStatus'),refreshSourceStatus:()=>call('refreshSourceStatus'),
    importSite:(url)=>call('importSite',url),removeSite:(id)=>call('removeSite',id),
    networkStatus:()=>call('networkStatus'),networkConfigure:(data)=>call('networkConfigure',data),networkBenchmark:()=>call('networkBenchmark'),anixartDiagnose:()=>call('anixartDiagnose'),
    anixartSources:(id,dubber)=>call('anixartSources',id,dubber),anixartEpisodes:(id,dubber,source)=>call('anixartEpisodes',id,dubber,source),
    relatedSources:(id,name,original,year)=>call('relatedSources',id,name,original,year),
    findPlayers:(title)=>call('findPlayers',title),openPlayer:(token)=>call('openPlayer',token),
    accountProviders:()=>call('accountProviders'),
    accountLogin:(provider,login,password)=>call('accountLogin',provider,login,password),
    accountLogout:(provider)=>call('accountLogout',provider),
    accountLibrary:(provider)=>call('accountLibrary',provider),
    accountLibraryPath:()=>call('accountLibraryPath'),
    syncAll:()=>call('syncAll'),syncStatus:()=>call('syncStatus'),setListStatus:(item,status)=>call('setListStatus',item,status),
    configureKodik:(x)=>call('configureKodik',x), configureYani:(x)=>call('configureYani',x),
    list:(s,p=1)=>call('list',s,p), search:(s,q,page=1)=>call('search',s,q,page),
    details:(id)=>call('details',id),health:(s)=>call('health',s),
    getState:()=>call('getState'),updateState:(x)=>call('updateState',x),
    toggleBookmark:(x)=>call('toggleBookmark',x),recordWatch:(x)=>call('recordWatch',x),
    prepareStream:(url)=>call('prepareStream',url),recordProgress:(x)=>call('recordProgress',x),historyInfo:()=>call('historyInfo'),cacheVideo:(url,details)=>call('cacheVideo',url,details),cacheStatus:(url)=>call('cacheStatus',url),cachedVideos:()=>call('cachedVideos'),openCached:(key)=>call('openCached',key),chooseVideo,
    openExternal:(url)=>call('openExternal',url)
  });
})();
