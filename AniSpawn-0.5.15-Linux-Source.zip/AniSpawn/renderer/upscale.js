/* AniSpawn GPU video upscaler: local WebGL2 Lanczos/bicubic, no CDN or remote rendering.
 * This is a spatial, edge-aware GPU filter, NOT Anime4K's neural model.
 * Edited separately from the HTML/CSS renderer for easier experimentation. */
(function(root){
'use strict';
const MODES=['fast','balanced','anime','soft'];
const DEFAULTS=Object.freeze({enabled:false,mode:'balanced',scale:1.5,strength:0.45});
function normalizeUpscale(settings){
 const s=settings&&typeof settings==='object'?settings:{};
 return {enabled:s.enabled===true,mode:MODES.includes(s.mode)?s.mode:DEFAULTS.mode,
  scale:[1,1.5,2].includes(Number(s.scale))?Number(s.scale):DEFAULTS.scale,
  strength:Number.isFinite(s.strength)?Math.min(1,Math.max(0,s.strength)):DEFAULTS.strength};
}
/* Backing pixels are based on source frame, not just CSS pixels. Preserve aspect ratio. */
function targetSize(width,height,cssWidth,cssHeight,dpr,scale,maxTextureSize=8192){
 const sourceWidth=Number(width), sourceHeight=Number(height);
 if(!Number.isFinite(sourceWidth)||!Number.isFinite(sourceHeight)||sourceWidth<1||sourceHeight<1)return {width:0,height:0};
 const s=[1,1.5,2].includes(Number(scale))?Number(scale):1.5;
 const deviceScale=Math.min(2.5,Math.max(1,Number(dpr)||1));
 const cssFactor=Math.min(4,Math.max((Number(cssWidth)||0)/sourceWidth,(Number(cssHeight)||0)/sourceHeight));
 let factor=Math.max(s,cssFactor*deviceScale);
 const maxSize=Math.max(64,Number(maxTextureSize)||4096);
 factor=Math.min(factor,maxSize/sourceWidth,maxSize/sourceHeight,3840/sourceWidth,2160/sourceHeight,Math.sqrt((3840*2160)/(sourceWidth*sourceHeight)));
 return {width:Math.max(1,Math.round(sourceWidth*factor)),height:Math.max(1,Math.round(sourceHeight*factor))};
}
const VERT=`#version 300 es
layout(location=0) in vec2 aPosition;
out vec2 vUv;
void main(){vUv=(aPosition+1.0)*0.5;gl_Position=vec4(aPosition,0.0,1.0);}`;
const FRAG=`#version 300 es
precision highp float;
precision highp int;
in vec2 vUv;
out vec4 fragColor;
uniform sampler2D uFrame;
uniform vec2 uSourceSize;
uniform int uFilter;
uniform float uStrength;
const float PI=3.141592653589793;
float cubic(float x){x=abs(x);if(x<1.0)return (1.5*x-2.5)*x*x+1.0;if(x<2.0)return ((-0.5*x+2.5)*x-4.0)*x+2.0;return 0.0;}
float sinc(float x){if(abs(x)<0.0001)return 1.0;x*=PI;return sin(x)/x;}
float lanczos(float x){x=abs(x);return x>=2.0?0.0:sinc(x)*sinc(x*0.5);}
vec3 resample(vec2 uv){
 if(uFilter==0)return texture(uFrame,uv).rgb;
 vec2 texel=1.0/uSourceSize;
 vec2 pos=uv*uSourceSize-0.5;
 vec2 b=floor(pos),f=fract(pos);
 vec3 acc=vec3(0.0);float total=0.0;
 for(int j=-1;j<=2;j++)for(int i=-1;i<=2;i++){
  float wx=uFilter==2?lanczos(float(i)-f.x):cubic(float(i)-f.x);
  float wy=uFilter==2?lanczos(float(j)-f.y):cubic(float(j)-f.y);
  float w=wx*wy;
  acc+=texture(uFrame,(b+vec2(float(i),float(j))+0.5)*texel).rgb*w;
  total+=w;
 }
 return acc/max(0.001,total);
}
float lum(vec3 c){return dot(c,vec3(0.2126,0.7152,0.0722));}
void main(){
 vec2 texel=1.0/uSourceSize;
 vec3 center=resample(vUv);
 if(uStrength<=0.0001){fragColor=vec4(clamp(center,0.0,1.0),1.0);return;}
 vec3 l=texture(uFrame,vUv-vec2(texel.x,0.0)).rgb;
 vec3 r=texture(uFrame,vUv+vec2(texel.x,0.0)).rgb;
 vec3 t=texture(uFrame,vUv+vec2(0.0,texel.y)).rgb;
 vec3 b=texture(uFrame,vUv-vec2(0.0,texel.y)).rgb;
 vec3 avg=(l+r+t+b)*0.25;
 float edge=max(max(abs(lum(center)-lum(l)),abs(lum(center)-lum(r))),max(abs(lum(center)-lum(t)),abs(lum(center)-lum(b))));
 float edgeFactor=0.35+0.65*smoothstep(0.025,0.22,edge);
 if(uFilter==3){fragColor=vec4(clamp(mix(center,avg,uStrength*0.10),0.0,1.0),1.0);return;}
 float amount=uStrength*(uFilter==2?0.9:0.55)*edgeFactor;
 vec3 sharp=center+(center-avg)*amount;
 vec3 lo=min(min(l,r),min(t,b));vec3 hi=max(max(l,r),max(t,b));
 fragColor=vec4(clamp(clamp(sharp,lo-vec3(0.06),hi+vec3(0.06)),0.0,1.0),1.0);
}`;
function compile(gl,type,source){const shader=gl.createShader(type);gl.shaderSource(shader,source);gl.compileShader(shader);
 if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS)){const error=gl.getShaderInfoLog(shader)||'unknown';gl.deleteShader(shader);throw new Error('Ошибка GPU-шейдера: '+error)}return shader;}
function createProgram(gl){const vertex=compile(gl,gl.VERTEX_SHADER,VERT),fragment=compile(gl,gl.FRAGMENT_SHADER,FRAG);const program=gl.createProgram();gl.attachShader(program,vertex);gl.attachShader(program,fragment);gl.linkProgram(program);
 gl.deleteShader(vertex);gl.deleteShader(fragment);if(!gl.getProgramParameter(program,gl.LINK_STATUS)){const error=gl.getProgramInfoLog(program)||'unknown';gl.deleteProgram(program);throw new Error('Не удалось создать GPU-программу: '+error)}return program;}
function createUpscaler(video,canvas,options={}){
 let gl=null,program=null,texture=null,buffer=null,vao=null,active=false,ready=false,frameToken=null,rafToken=null,rendered=0,failed=false;
 let settings=normalizeUpscale(options.settings),observer=null;
 let dims={width:0,height:0};
 const stage=options.stage||canvas.parentElement;
 const status=(message,type='info')=>{if(typeof options.onStatus==='function')options.onStatus(message,type)};
 function cancelFrames(){if(frameToken!==null&&video.cancelVideoFrameCallback)video.cancelVideoFrameCallback(frameToken);if(rafToken!==null)cancelAnimationFrame(rafToken);frameToken=null;rafToken=null;}
 function resize(){if(!gl||!video.videoWidth||!video.videoHeight)return;
  const rect=stage.getBoundingClientRect();const ratio=video.videoWidth/video.videoHeight;
  const fitW=Math.min(rect.width,rect.height*ratio),fitH=fitW/ratio;
  canvas.style.width=Math.max(1,fitW)+'px';canvas.style.height=Math.max(1,fitH)+'px';
  const d=targetSize(video.videoWidth,video.videoHeight,fitW,fitH,root.devicePixelRatio,settings.scale,Math.min(gl.getParameter(gl.MAX_TEXTURE_SIZE),gl.getParameter(gl.MAX_RENDERBUFFER_SIZE)));
  if(d.width!==dims.width||d.height!==dims.height){canvas.width=d.width;canvas.height=d.height;dims=d;gl.viewport(0,0,d.width,d.height);if(rendered)status(`${video.videoWidth}×${video.videoHeight} → ${d.width}×${d.height} · GPU`,'ok');}
 }
 function initialize(){if(gl)return;
  gl=canvas.getContext('webgl2',{alpha:false,antialias:false,desynchronized:true,preserveDrawingBuffer:false,powerPreference:'high-performance'});
  if(!gl)throw new Error('WebGL2 недоступен. Проверьте драйвер видеокарты или отключите апскейл.');
  program=createProgram(gl);vao=gl.createVertexArray();gl.bindVertexArray(vao);buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);
  gl.enableVertexAttribArray(0);gl.vertexAttribPointer(0,2,gl.FLOAT,false,0,0);
  texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);gl.useProgram(program);gl.uniform1i(gl.getUniformLocation(program,'uFrame'),0);
  resize();
 }
 function draw(){if(!active||failed||video.readyState<2||video.videoWidth===0)return;
  try{initialize();if(!dims.width||!dims.height)resize();
   gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);
   gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,video);
   const textureError=gl.getError();if(textureError!==gl.NO_ERROR)throw new Error('Видеокадр нельзя передать в GPU (WebGL '+textureError+').');
   gl.useProgram(program);gl.uniform2f(gl.getUniformLocation(program,'uSourceSize'),video.videoWidth,video.videoHeight);
   gl.uniform1i(gl.getUniformLocation(program,'uFilter'),settings.mode==='fast'?0:settings.mode==='anime'?2:settings.mode==='soft'?3:1);
   gl.uniform1f(gl.getUniformLocation(program,'uStrength'),settings.strength);
   gl.bindVertexArray(vao);gl.drawArrays(gl.TRIANGLE_STRIP,0,4);
   if(!ready&&gl.getError()!==gl.NO_ERROR)throw new Error('Ошибка отрисовки кадра через GPU.');
   if(!ready){ready=true;canvas.classList.add('upscale-visible');stage.classList.add('upscale-active');status(`${video.videoWidth}×${video.videoHeight} → ${dims.width}×${dims.height} · GPU`,'ok');}
   rendered++;
  }catch(error){failed=true;stop();status(`Апскейл отключён: ${error.message}`,'error');}
 }
 function loop(){if(!active)return;
  if(typeof video.requestVideoFrameCallback==='function')frameToken=video.requestVideoFrameCallback(()=>{frameToken=null;draw();loop()});
  else rafToken=requestAnimationFrame(()=>{rafToken=null;if(!video.paused)draw();loop()});
 }
 function onFrameChange(){resize();draw()}
 function onContextLost(event){event.preventDefault();failed=true;stop();status('GPU-контекст потерян. Включите апскейл повторно после восстановления.','error')}
 function onContextRestored(){gl=null;program=null;texture=null;buffer=null;vao=null;failed=false;status('GPU восстановлен. Апскейл можно включить снова.')}
 function start(){if(active)return;
  active=true;failed=false;ready=false;rendered=0;canvas.classList.remove('upscale-visible');stage.classList.remove('upscale-active','upscale-compare');
  canvas.addEventListener('webglcontextlost',onContextLost);canvas.addEventListener('webglcontextrestored',onContextRestored);
  video.addEventListener('loadeddata',onFrameChange);video.addEventListener('seeked',onFrameChange);video.addEventListener('resize',onFrameChange);
  if(typeof ResizeObserver!=='undefined'){observer=new ResizeObserver(resize);observer.observe(stage)}
  status('Подготовка GPU…');draw();loop();
 }
 function configure(value){settings=normalizeUpscale(value);if(active){resize();draw()}return settings;}
 function compare(enabled){stage.classList.toggle('upscale-compare',!!enabled&&active&&ready)}
 function stop(){cancelFrames();active=false;ready=false;stage.classList.remove('upscale-active','upscale-compare');canvas.classList.remove('upscale-visible');
  video.removeEventListener('loadeddata',onFrameChange);video.removeEventListener('seeked',onFrameChange);video.removeEventListener('resize',onFrameChange);
  canvas.removeEventListener('webglcontextlost',onContextLost);canvas.removeEventListener('webglcontextrestored',onContextRestored);
  if(observer){observer.disconnect();observer=null}
  if(gl){try{if(texture)gl.deleteTexture(texture);if(buffer)gl.deleteBuffer(buffer);if(vao)gl.deleteVertexArray(vao);if(program)gl.deleteProgram(program)}catch{}}
  gl=null;texture=null;buffer=null;vao=null;program=null;dims={width:0,height:0};rendered=0;
 }
 return {start,stop,configure,compare,get settings(){return {...settings}},get active(){return active},get ready(){return ready},get dimensions(){return {...dims}}};
}
const exposed={createUpscaler,normalizeUpscale,targetSize,DEFAULTS,MODES};
if(typeof module==='object'&&module.exports)module.exports=exposed;
if(root&&typeof root==='object')root.AniSpawnUpscale=exposed;
})(typeof window!=='undefined'?window:null);
