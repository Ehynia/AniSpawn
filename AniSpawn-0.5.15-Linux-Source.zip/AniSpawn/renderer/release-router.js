/* AniSpawn release link resolver. A URL identifies a provider title; never embeds a third-party site. */
(function(root, factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.AniSpawnReleaseRouter=Object.freeze(api);
})(typeof window!=='undefined'?window:null,function(){
 'use strict';
 const hosts=new Set(['anixart-app.com','www.anixart-app.com','mirror.anixart-app.com','anixart.app','www.anixart.app','anixart.tv','www.anixart.tv']);
 function parse(input){
  if(typeof input!=='string'||input.length>2048)return null;
  const value=input.trim();let id;
  let match=/^(?:anixart:)?([1-9]\d{0,11})$/i.exec(value);
  if(match)id=match[1];
  else {
   try{
    const url=new URL(value);
    if(url.protocol!=='https:'||url.username||url.password||url.port||!hosts.has(url.hostname.toLowerCase()))return null;
    match=/^\/release\/([1-9]\d{0,11})\/?$/i.exec(url.pathname);
    if(!match)return null;
    id=match[1];
   }catch{return null}
  }
  return {source:'anixart',id:'anixart:'+id,remoteId:id,href:'https://anixart-app.com/release/'+id,hash:'#/release/anixart/'+id};
 }
 function fromHash(hash){
  const m=/^#\/release\/anixart\/([1-9]\d{0,11})$/.exec(hash||'');
  return m?parse('anixart:'+m[1]):null;
 }
 return {parse,fromHash};
});
