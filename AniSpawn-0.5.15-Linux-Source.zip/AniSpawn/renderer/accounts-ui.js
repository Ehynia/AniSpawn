/* AniSpawn account UI: no passwords or session tokens in localStorage. */
(function(){'use strict';
  const $ = id => document.getElementById(id);
  const a = window.anispawn;
  let selected = 'anixart';
  let busy = false;
  const txt=(tag,cls,text)=>{const e=document.createElement(tag);e.className=cls;e.textContent=text;return e};
  async function providers(){
    const root=$('account-providers');root.replaceChildren();
    try{
      const list=await a.accountProviders();
      for(const entry of list){
        const row=txt('article','account-provider','');
        const info=txt('div','account-provider-info','');
        info.append(txt('strong','',entry.name));
        info.append(txt('p','',entry.user?'Подключён: '+entry.user.name:entry.description));
        row.append(info);
        const action=txt('button',entry.user?'soft-btn':'primary-btn',entry.user?'Выйти':entry.available?'Войти':'Недоступно');
        if(!entry.user&&!entry.available){action.disabled=true;action.title=entry.description;}
        if(entry.user){action.onclick=async()=>{
          if(busy)return;busy=true;
          try{await a.accountLogout(entry.id);await providers();await showLibrary()}
          catch(e){showStatus(e.message)}finally{busy=false}
        }}else if(entry.available){action.onclick=()=>openLogin(entry.id,entry.name)}
        row.append(action);root.append(row);
      }
    }catch(err){root.append(txt('p','error-text','Не удалось загрузить аккаунты: '+err.message))}
  }
  function openLogin(id,name){
    selected=id;$('account-login-title').textContent='Войти в '+name;
    $('account-login-error').textContent='';$('account-login-password').value='';
    $('account-login-info').textContent=id==='anixart'?'Логин и пароль от Anixart.':'Логин или почта и пароль от Yani.';
    const dlg=$('account-login-modal');dlg.showModal();$('account-login-name').focus();
  }
  function showStatus(s){$('account-library-status').textContent=s}
  async function showLibrary(){
    const root=$('account-library-grid');root.replaceChildren();
    const status=await a.syncStatus();
    showStatus('Единая библиотека: '+status.bookmarks+' тайтлов · история: '+status.history+' записей'+(status.pending?' · ожидают отправки: '+status.pending:''));
    root.append(txt('p','settings-hint','Все данные доступны в обычных вкладках «Моя библиотека» и «История». Здесь нет отдельной копии для каждого аккаунта.'));
  }
  async function synchronize(){
    showStatus('Синхронизация списков и истории…');
    try{const report=await window.AniSpawnSync();await providers();await showLibrary();
      const failures=Object.values(report.providers||{}).filter(x=>x.connected&&x.warning);
      if(failures.length)showStatus('Библиотека обновлена с ограничениями: '+failures.map(x=>x.warning).join('; ').slice(0,220));
    }catch(e){showStatus('Синхронизация не удалась: '+e.message)}
  }
  async function render(){
    await providers();
    try{$('account-cache-path').textContent='TXT-кэш: '+await a.accountLibraryPath()}
    catch{$('account-cache-path').textContent='TXT-кэш библиотеки недоступен'}
    await showLibrary();
  }
  function init(){
    if(!a?.accountProviders)return;
    $('open-accounts')?.addEventListener('click',()=>window.setAniSpawnView?.('accounts'));
    $('account-refresh').addEventListener('click',synchronize);
    $('account-open-library').addEventListener('click',()=>window.setAniSpawnView?.('bookmarks'));
    $('account-login-close').addEventListener('click',()=>{$('account-login-password').value='';$('account-login-modal').close()});
    $('account-login-modal').addEventListener('close',()=>{$('account-login-password').value=''});
    $('account-login-form').addEventListener('submit',async e=>{
      e.preventDefault();if(busy)return;
      const provider=selected,login=$('account-login-name').value.trim(),password=$('account-login-password').value;
      $('account-login-password').value='';
      if(!login||!password)return;
      const submit=$('account-login-submit');submit.disabled=true;busy=true;
      $('account-login-error').textContent='';
      try{
        await a.accountLogin(provider,login,password);
        $('account-login-modal').close();
        await providers();await synchronize();
      }catch(err){$('account-login-error').textContent=err.message}
      finally{submit.disabled=false;busy=false}
    });
  }
  window.AniSpawnAccounts=Object.freeze({init,render});
})();
