module.exports = {
  packagerConfig: {
    name: 'AniSpawn', executableName: 'anispawn', asar: true,
    appBundleId: 'org.anispawn.desktop',
    ignore: [/^\/out($|\/)/, /^\/tests($|\/)/, /^\/design-reference($|\/)/, /^\/\.github($|\/)/]
  },
  makers: [
    {name:'@electron-forge/maker-zip',platforms:['win32','linux']},
    {name:'@electron-forge/maker-deb',config:{options:{name:'anispawn',productName:'AniSpawn',maintainer:'AniSpawn contributors',homepage:'https://github.com/theDesConnet/AniDesk',categories:['Video','AudioVideo']}}},
    {name:'@electron-forge/maker-squirrel',config:{name:'AniSpawn'}}
  ]
};
