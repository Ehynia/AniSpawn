'use strict';
const {contextBridge,ipcRenderer}=require('electron');
const call=(channel,...args)=>ipcRenderer.invoke(channel,...args);
contextBridge.exposeInMainWorld('anispawn',Object.freeze({
 sources:()=>call('api:sources'),
 configureKodik:token=>call('api:kodik-configure',token),
 list:(source,page=1)=>call('api:list',source,page),
 search:(source,q)=>call('api:search',source,q),
 details:id=>call('api:details',id),
 health:source=>call('api:health',source),
 getState:()=>call('state:get'),
 updateState:patch=>call('state:update',patch),
 toggleBookmark:item=>call('state:bookmark',item),
 recordWatch:entry=>call('state:watched',entry),
 prepareStream:url=>call('player:prepare',url),
 chooseVideo:()=>call('player:open-local'),
 openExternal:url=>call('links:open',url)
}));
