'use strict';
const {app,BrowserWindow,ipcMain,protocol,net,dialog,shell}=require('electron');
const path=require('node:path');const fs=require('node:fs');
const {createProviders}=require('../src/core/providers.cjs');
const {createStore}=require('../src/core/store.cjs');
const {createHlsProxy}=require('../src/core/hls-proxy.cjs');
const {createLocalMedia}=require('../src/core/local-media.cjs');
protocol.registerSchemesAsPrivileged(['anispawn-stream','anispawn-local'].map(scheme=>({scheme,privileges:{standard:true,secure:true,supportFetchAPI:true,stream:true,corsEnabled:true}})));
let mainWindow,store,api,media,localMedia;
const verifiedStreams=new Set();
const CACHE_TIME=14*24*60*60*1000;
function cacheFile(){return path.join(app.getPath('userData'),'catalog-cache.json')}
let cache={};
function initCache(){try{cache=JSON.parse(fs.readFileSync(cacheFile(),'utf8'))||{}}catch{cache={}}}
function cached(key,items){cache[key]={time:Date.now(),items};const keys=Object.keys(cache);
 if(keys.length>100)for(const k of keys.slice(0,keys.length-80))delete cache[k];
 try{fs.writeFileSync(cacheFile(),JSON.stringify(cache),'utf8')}catch{};
}
async function fetchList(key,fn){try{const items=await fn();cached(key,items);return {items,stale:false}}catch(e){const entry=cache[key];
 if(entry&&Date.now()-entry.time<CACHE_TIME)return {items:entry.items,stale:true,warning:e.message};
 throw e;
}}
function validSource(s){return ['libria','anilist','shiki','anixart','jikan','kodik'].includes(s)?s:'libria'}
function validId(id){if(typeof id!=='string'||!/^(libria|anixart|anilist|shiki|jikan|kodik):[\w-]{1,100}$/.test(id))throw new Error('Недопустимый ID');return id}
function collectStreams(details){for(const ep of details.episodes||[])for(const url of Object.values(ep.quality||{}))if(typeof url==='string'&&url.startsWith('https://'))verifiedStreams.add(url);
 if(verifiedStreams.size>10000)verifiedStreams.clear();}
function secureHandle(channel,handler){
 ipcMain.handle(channel,(event,...args)=>{
  if(!mainWindow||event.sender!==mainWindow.webContents||event.senderFrame!==mainWindow.webContents.mainFrame)throw new Error('Вызов IPC не из основного окна');
  return handler(event,...args);
 });
}
function addIpc(){
 secureHandle('api:sources',()=>api.sources);
 secureHandle('api:kodik-configure',(_e,token)=>api.configureKodik(token));
 secureHandle('api:list',(_e,source,page=1)=>{const s=validSource(source);const p=Math.max(1,Math.min(100,Number(page)||1));return fetchList(`list:${s}:${p}`,()=>api.catalog(s,p))});
 secureHandle('api:search',(_e,source,q)=>{const s=validSource(source);const query=String(q||'').trim().slice(0,120);
   return fetchList(`search:${s}:${query.toLowerCase()}`,()=>api.search(s,query))});
 secureHandle('api:details',async(_e,id)=>{validId(id);try{const d=await api.details(id);collectStreams(d);cached(`detail:${id}`,d);return {...d,stale:false}}catch(e){const c=cache[`detail:${id}`];if(c&&Date.now()-c.time<CACHE_TIME){collectStreams(c.items);return {...c.items,stale:true}}throw e}});
 secureHandle('api:health',(_e,s)=>api.health(validSource(s)));
 secureHandle('state:get',()=>store.get());
 secureHandle('state:update',(_e,patch)=>store.patch(patch));
 secureHandle('state:bookmark',(_e,item)=>store.bookmark(item));
 secureHandle('state:watched',(_e,entry)=>store.watched(entry));
 secureHandle('player:prepare',(_e,url)=>{
  if(typeof url!=='string'||!verifiedStreams.has(url))throw new Error('Поток не подтверждён источником');
  return media.register(url);
 });
 secureHandle('player:open-local',async()=>{
  const res=await dialog.showOpenDialog(mainWindow,{title:'Выберите локальный видеофайл',properties:['openFile'],filters:[{name:'Видео',extensions:['mp4','webm','m4v','mov','ogg']}]});
  return res.canceled?null:localMedia.register(res.filePaths[0]);
 });
 secureHandle('links:open',async(_e,link)=>{
  let u;try{u=new URL(link)}catch{throw new Error('Недопустимый адрес')}
  const allowed=['anilibria.top','aniliberty.top','anilibria.app','anixart.app','anilist.co','shikimori.one','myanimelist.net','kodik.info','kodikplayer.com'];
  if(u.protocol!=='https:'||!allowed.some(x=>u.hostname===x||u.hostname.endsWith('.'+x)))throw new Error('Внешняя ссылка недоступна');
  return shell.openExternal(u.href);
 });
}
function createWindow(){
 mainWindow=new BrowserWindow({width:1440,height:900,minWidth:930,minHeight:620,backgroundColor:'#0a0a0f',title:'AniSpawn',autoHideMenuBar:true,show:false,
  webPreferences:{preload:path.join(__dirname,'preload.cjs'),nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,allowRunningInsecureContent:false}});
 mainWindow.loadFile(path.join(__dirname,'..','renderer','index.html'));
 mainWindow.once('ready-to-show',()=>mainWindow?.show());
 mainWindow.webContents.setWindowOpenHandler(()=>({action:'deny'}));
 mainWindow.webContents.on('will-navigate',(event,url)=>{if(!url.startsWith('file://'))event.preventDefault()});
 mainWindow.webContents.on('will-attach-webview',event=>event.preventDefault());
 mainWindow.webContents.session.setPermissionRequestHandler((_contents,_permission,callback)=>callback(false));
 mainWindow.on('closed',()=>{mainWindow=null});
}
app.whenReady().then(()=>{
 store=createStore(path.join(app.getPath('userData'),'state.json'));
 api=createProviders((url,options)=>net.fetch(url,options));
 media=createHlsProxy((url,options)=>net.fetch(url,options));
 localMedia=createLocalMedia();
 protocol.handle('anispawn-stream',request=>media.handle(request));
 protocol.handle('anispawn-local',request=>localMedia.handle(request));
 initCache();addIpc();createWindow();
 app.on('activate',()=>{if(!BrowserWindow.getAllWindows().length)createWindow()});
});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit()});
