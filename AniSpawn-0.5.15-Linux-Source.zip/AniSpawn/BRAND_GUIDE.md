# AniSpawn Mascot & Brand (0.5.6)

- Mascot: white-haired chibi demon-human, pastel purple/pink eyes, small horns and bat wings, white cloak. **Arms and hands are not visible.**
- Original art files: `renderer/assets/mascot-original.png` and `renderer/assets/logo-original.png`.
- Optimized renderer files: `mascot-full.webp` (hero), `logo-full.webp` (logotype/marketing).
- Square app icons: `icon-16.png` … `icon-512.png`, plus `anispawn.ico` for Windows packaging.
- All icons were cropped and rendered from the original AI-generated vector-*style* illustration. They are **raster PNG/WebP**, not editable vector SVG artwork.
- Color palette: soft lavender, pink, ivory and charcoal; purple accent in interface.
- Linux .deb installs desktop icon under `/usr/share/icons/hicolor/*/apps/anispawn.png` and uses `Icon=anispawn`.
- Source pictures are bundled locally; no CDN or network access required for the brand.
- SVG/vector export, if needed in future, would need separate vector tracing/drawing; enlarging PNG does not make it vector.
