"""AniSpawn authenticated providers. Passwords and bearer tokens never reach disk.

This module uses only Python stdlib and deliberately does not try to derive
publisher API credentials from user passwords.
"""
from __future__ import annotations
import datetime
import json
import os
from pathlib import Path
import re
import threading
import urllib.error
import urllib.parse
import urllib.request
import anixart_network
import network_settings

ANIXART_BASE = 'https://api.anixsekai.com'
YANI_BASE = 'https://api.yani.tv'
STATUS_ANIXART = {1: 'Смотрю', 2: 'В планах', 3: 'Просмотрено', 4: 'Отложено', 5: 'Брошено'}
STATUS_YANI = {0: 'Смотрю', 1: 'В планах', 2: 'Просмотрено', 3: 'Брошено', 5: 'Отложено'}


def safe_text(x, limit=160):
    return re.sub(r'[\x00-\x1f\x7f]+', ' ', str(x or '')).strip()[:limit]


def service_json(base, endpoint, *, method='GET', data=None, headers=None, form=False):
    """Fixed HTTPS endpoints only; never include secrets in exceptions returned to UI."""
    if base not in (ANIXART_BASE, YANI_BASE) or not endpoint.startswith('/'):
        raise ValueError('Endpoint rejected')
    if base == ANIXART_BASE:
        return anixart_network.request_json(base+endpoint,method=method,data=data,headers=headers,form=form,timeout=5)
    body = (urllib.parse.urlencode(data).encode('utf8') if form else json.dumps(data).encode('utf8')) if data is not None else None
    request = urllib.request.Request(base+endpoint, data=body, method=method,
        headers={'User-Agent': 'AniSpawn/0.5.4', 'Accept': 'application/json',
                 **({'Content-Type': 'application/x-www-form-urlencoded' if form else 'application/json'} if body else {}),
                 **(headers or {})})
    try:
        with network_settings.open_url(request, timeout=12) as resp:
            result = json.loads(resp.read(3_000_000))
        if not isinstance(result, (dict, list)):
            raise ValueError('Invalid API response')
        return result
    except urllib.error.HTTPError as err:
        raise RuntimeError('Сервис ответил HTTP '+str(err.code)) from None
    except (urllib.error.URLError, TimeoutError):
        raise RuntimeError('Нет соединения с сервисом авторизации') from None


class Accounts:
    def __init__(self, directory, app_token=None):
        self.directory = Path(directory)
        self.lock = threading.RLock()
        self.sessions = {}  # provider -> {token, user_id, name}; NEVER serialised.
        # The X-Application value belongs to the distributor, NOT the end user.
        self.yani_app_token = (app_token if app_token is not None else os.environ.get('ANISPAWN_YANI_APPLICATION_TOKEN', '')).strip()
        self.cache_file = self.directory / 'account-libraries.json'
        self.txt_file = self.directory / 'account-libraries.txt'
        self.cached = {}
        try:
            obj = json.loads(self.cache_file.read_text(encoding='utf8'))
            if isinstance(obj, dict): self.cached = obj
        except (OSError, ValueError, TypeError):
            pass

    def providers(self):
        with self.lock:
            out = [
                {'id': 'anixart', 'name': 'Anixart', 'auth': 'password', 'available': True,
                 'description': 'Вход по логину и паролю, списки и история', 'user': self.public('anixart')},
                {'id': 'yani', 'name': 'Yani / YummyAnime', 'auth': 'password' if self.yani_app_token else 'publisher',
                 'available': bool(self.yani_app_token), 'user': self.public('yani'),
                 'description': 'Требуется регистрация AniSpawn у Yani; пользовательский ключ не нужен' if not self.yani_app_token else 'Вход по данным сайта, списки и история'},
                {'id': 'shiki', 'name': 'Shikimori', 'auth': 'oauth', 'available': False,
                 'description': 'Только OAuth через зарегистрированное приложение — пароль в AniSpawn не принимается', 'user': None},
                {'id': 'kodik', 'name': 'Kodik', 'auth': 'publisher', 'available': False,
                 'description': 'Kodik API-ключ — ключ разработчика, не пароль зрителя; личная библиотека через публичный API не подтверждена', 'user': None},
            ]
            return out

    def public(self, provider):
        item = self.sessions.get(provider)
        return {'id': item['user_id'], 'name': item['name']} if item else None

    def login(self, provider, login, password):
        if provider not in ('anixart', 'yani'): raise ValueError('Для сервиса нет прямого входа')
        if not isinstance(login, str) or not isinstance(password, str) or not 1 <= len(login.strip()) <= 160 or not 1 <= len(password) <= 1024:
            raise ValueError('Введите логин и пароль')
        if provider == 'anixart':
            payload = service_json(ANIXART_BASE, '/auth/signIn', method='POST', data={'login': login, 'password': password}, form=True)
            if payload.get('code') != 0: raise ValueError('Anixart отклонил вход (код '+str(payload.get('code', '?'))+')')
            profile = payload.get('profile') or {}
            tok = payload.get('profileToken') or {}
            token = tok.get('token')
            user_id = profile.get('id')
            name = safe_text(profile.get('login') or login)
        else:
            if not self.yani_app_token:
                raise ValueError('AniSpawn пока не зарегистрирован как приложение Yani. Пароль не отправлен.')
            payload = service_json(YANI_BASE, '/profile/login', method='POST',
                                   data={'login': login, 'password': password, 'need_json': True},
                                   headers={'X-Application': self.yani_app_token})
            payload = payload.get('response', payload)
            token = payload.get('token') or payload.get('access_token') if isinstance(payload, dict) else payload if isinstance(payload, str) else None
            if not isinstance(token, str) or not token.strip(): raise ValueError('Yani не вернул токен аккаунта')
            # The profile endpoint is used to validate session and discover account id.
            profile = service_json(YANI_BASE, '/profile', headers={'X-Application': self.yani_app_token, 'Authorization': 'Bearer '+token})
            profile = profile.get('response', profile) if isinstance(profile, dict) else profile
            if not isinstance(profile, dict): raise ValueError('Yani не вернул профиль')
            user_id = profile.get('id') or profile.get('user_id')
            name = safe_text(profile.get('nickname') or profile.get('login') or login)
        if not isinstance(token, str) or not token or len(token) > 8192 or user_id is None:
            raise ValueError('Сервис не вернул подтверждённую сессию')
        with self.lock:
            self.sessions[provider] = {'token': token, 'user_id': user_id, 'name': name}
            return self.public(provider)

    def logout(self, provider):
        if provider not in ('anixart', 'yani'): raise ValueError('Неизвестный сервис')
        with self.lock:
            self.sessions.pop(provider, None)
        return True

    def _anixart_get(self, path, token):
        # AnixartJS v1 authentication sends token in the query string.
        delim = '&' if '?' in path else '?'
        result = service_json(ANIXART_BASE, path+delim+urllib.parse.urlencode({'token': token}))
        if isinstance(result, dict) and result.get('code', 0) != 0:
            raise ValueError('Anixart: список недоступен (код '+str(result['code'])+')')
        return result

    @staticmethod
    def normalized(provider, item, status):
        if not isinstance(item, dict): return None
        if provider == 'yani' and isinstance(item.get('anime'), dict): item = item['anime']
        key = item.get('id') if provider == 'anixart' else item.get('anime_id')
        if key is None: return None
        title = item.get('title_ru') or item.get('title') or item.get('name') or str(key)
        if isinstance(title, dict): title = title.get('main') or title.get('russian') or str(key)
        poster = item.get('poster') or {}
        if isinstance(poster, dict): poster = poster.get('big') or poster.get('huge') or poster.get('medium') or ''
        image = item.get('image') if provider == 'anixart' else poster
        # Only whitelisted HTTPS poster URLs may be rendered.
        parsed = urllib.parse.urlparse(str(image or ''))
        image = image if parsed.scheme == 'https' else ''
        return {'id': provider+':'+safe_text(key, 90), 'name': safe_text(title), 'status': status,
                'statusId': next((n for n,label in (STATUS_ANIXART if provider=='anixart' else STATUS_YANI).items() if label==status), None),
                'source': provider, 'image': image, 'year': item.get('year') or ''}

    def _remote_lists(self, provider, session):
        results = []
        if provider == 'anixart':
            # 5 lists, bounded pagination to avoid excessive unofficial API requests.
            for status_id, title in STATUS_ANIXART.items():
                for page in range(20):
                    data = self._anixart_get(f'/profile/list/all/{status_id}/{page}', session['token'])
                    items = data.get('content', []) if isinstance(data, dict) else []
                    if not isinstance(items, list): break
                    results.extend(x for a in items if (x := self.normalized(provider, a, title)))
                    total_pages = data.get('total_page_count') if isinstance(data, dict) else None
                    if not items or (isinstance(total_pages, int) and page+1 >= total_pages): break
        elif provider == 'yani':
            headers = {'X-Application': self.yani_app_token, 'Authorization': 'Bearer '+session['token']}
            user_id = urllib.parse.quote(str(session['user_id']), safe='')
            listings = service_json(YANI_BASE, f'/users/{user_id}/lists', headers=headers)
            listings = listings.get('response', listings) if isinstance(listings, dict) else listings
            for lst in (listings if isinstance(listings, list) else [])[:20]:
                if not isinstance(lst, dict) or 'id' not in lst: continue
                lst_id = urllib.parse.quote(str(lst['id']), safe='')
                label = safe_text(lst.get('title') or STATUS_YANI.get(lst.get('id'), 'Список'))
                records = service_json(YANI_BASE, f'/users/{user_id}/lists/{lst_id}', headers=headers)
                records = records.get('response', records) if isinstance(records, dict) else records
                if isinstance(records, dict): records = records.get('content', records.get('items', []))
                results.extend(x for a in (records if isinstance(records, list) else [])[:500] if (x := self.normalized(provider, a, label)))
        return results[:5000]

    def library(self, provider, refresh=True):
        if provider not in ('anixart','yani'): raise ValueError('Этот сервис не поддерживается')
        with self.lock: session = self.sessions.get(provider)
        if not session:
            # Local library cache is non-secret, usable offline even after logout.
            cache = self.cached.get(provider)
            return {'items': cache.get('items', []) if isinstance(cache,dict) else [], 'stale': True,
                    'name': cache.get('name','') if isinstance(cache,dict) else '', 'authenticated':False}
        try:
            items = self._remote_lists(provider, session)
        except Exception as exc:
            cache = self.cached.get(provider)
            if isinstance(cache,dict): return {'items': cache.get('items', []), 'name':cache.get('name',''), 'stale':True,
                                               'authenticated':True,'warning':safe_text(exc,160)}
            raise
        with self.lock:
            self.cached[provider] = {'name': session['name'], 'userId': session['user_id'], 'items': items,
                                     'updated': datetime.datetime.now(datetime.timezone.utc).isoformat()}
            self.write_cache()
        return {'items': items,'name':session['name'],'userId':session['user_id'],'stale':False,'authenticated':True}

    def remote_history(self, provider):
        """Read playback history from a signed-in account; never invent episode progress."""
        with self.lock:
            session = self.sessions.get(provider)
        if not session:
            return []
        if provider == 'anixart':
            result = self._anixart_get('/history/0', session['token'])
            rows = result.get('content', []) if isinstance(result, dict) else []
            output = []
            for item in rows[:1000] if isinstance(rows, list) else []:
                if not isinstance(item, dict) or not isinstance(item.get('id'), int):
                    continue
                ep = item.get('last_view_episode') or {}
                if not isinstance(ep, dict): ep = {}
                entry = self.normalized('anixart', item, '')
                stamp = item.get('last_view_timestamp')
                date = datetime.datetime.fromtimestamp(stamp, datetime.timezone.utc).isoformat() if isinstance(stamp,(int,float)) and 0 < stamp < 4102444800 else datetime.datetime.now(datetime.timezone.utc).isoformat()
                output.append({'id': entry['id'], 'name': entry['name'], 'episode': str(ep.get('position', ''))[:32],
                               'date': date, 'position': max(0, float(ep.get('playback_position') or 0)),
                               'duration': 0, 'completed': bool(ep.get('is_watched')), 'remoteAccount': 'anixart'})
            return output
        if provider == 'yani':
            headers = {'X-Application': self.yani_app_token, 'Authorization': 'Bearer '+session['token']}
            result = service_json(YANI_BASE, '/video/watch-history', headers=headers)
            rows = result.get('response', result) if isinstance(result, dict) else result
            if isinstance(rows, dict): rows = rows.get('content',rows.get('items',[]))
            output = []
            for item in (rows if isinstance(rows,list) else [])[:1000]:
                if not isinstance(item,dict): continue
                key = item.get('anime_id',item.get('animeId'))
                if not isinstance(key,int): continue
                seconds = item.get('end_time',item.get('time',0))
                duration = item.get('duration',0)
                if not isinstance(seconds,(int,float)): seconds=0
                if not isinstance(duration,(int,float)): duration=0
                stamp = item.get('date',item.get('updated_at'))
                date = datetime.datetime.fromtimestamp(stamp,datetime.timezone.utc).isoformat() if isinstance(stamp,(int,float)) and 0 < stamp < 4102444800 else datetime.datetime.now(datetime.timezone.utc).isoformat()
                output.append({'id':'yani:'+str(key),'name':safe_text(item.get('title') or item.get('anime_title') or key),
                               'episode':str(item.get('episode') or item.get('number') or '')[:32], 'date':date,
                               'position':max(0,min(172800,float(seconds))), 'duration':max(0,min(172800,float(duration))),
                               'completed': bool(duration and seconds>=duration-15), 'remoteAccount':'yani'})
            return output
        return []

    def change_remote_status(self, provider, item_id, new_status, old_status=None):
        """Write only the user's explicit list change. No replay of cached lists to a remote service."""
        if provider not in ('anixart','yani') or not isinstance(item_id,str) or not re.fullmatch(provider+r':[0-9]{1,12}',item_id):
            raise ValueError('Неверный ID сетевой записи')
        allowed = STATUS_ANIXART if provider=='anixart' else STATUS_YANI
        if new_status is not None and new_status not in allowed: raise ValueError('Неизвестный статус')
        if old_status is not None and old_status not in allowed: old_status=None
        with self.lock: session=self.sessions.get(provider)
        if not session: raise RuntimeError('Войдите в '+provider+' для синхронизации')
        rid=item_id.split(':',1)[1]
        if provider=='anixart':
            if new_status is not None:
                self._anixart_get(f'/profile/list/add/{new_status}/{rid}',session['token'])
            if old_status is not None and old_status!=new_status:
                self._anixart_get(f'/profile/list/delete/{old_status}/{rid}',session['token'])
        else:
            headers={'X-Application':self.yani_app_token,'Authorization':'Bearer '+session['token']}
            method='PUT' if new_status is not None else 'DELETE'
            service_json(YANI_BASE, '/anime/'+rid+'/list',method=method,
                         data={'list':new_status} if new_status is not None else None,headers=headers)
        return True

    def write_cache(self):
        # Cache is metadata only: NEVER serialize access tokens, passwords or login payloads.
        safe = {p: {'name': obj.get('name',''), 'userId': obj.get('userId'), 'items': obj.get('items', [])[:5000], 'updated': obj.get('updated','')}
                for p, obj in self.cached.items() if p in ('anixart','yani') and isinstance(obj,dict)}
        raw = json.dumps(safe, ensure_ascii=False, indent=2)
        tmp = self.cache_file.with_suffix('.tmp')
        tmp.write_text(raw,encoding='utf8');os.chmod(tmp,0o600);tmp.replace(self.cache_file)
        lines = ['AniSpawn · Мои библиотеки', 'Сохранено: '+datetime.datetime.now().astimezone().strftime('%Y-%m-%d %H:%M'), '']
        for provider, obj in safe.items():
            lines.append('=== '+provider+' / '+safe_text(obj.get('name'))+' ===')
            for item in obj.get('items',[]):
                lines.append('['+safe_text(item.get('status'))+'] '+safe_text(item.get('name'))+' ('+safe_text(item.get('id'))+')')
            lines.append('')
        tmp_txt = self.txt_file.with_suffix('.tmp');tmp_txt.write_text('\n'.join(lines),encoding='utf8');os.chmod(tmp_txt,0o600);tmp_txt.replace(self.txt_file)
