"""Conservative cross-provider grouping for Anixart and AniLiberty.

Exact title matches can be grouped in search, but never merge their remote IDs,
bookmarks, auth sessions, video rights or playback state. A fuzzy result is
always labelled as a suggestion that needs a user click.
"""
from __future__ import annotations
from difflib import SequenceMatcher
import re
import unicodedata


def canonical_title(value):
    if not isinstance(value, str):
        return ''
    cleaned = unicodedata.normalize('NFKC', value).casefold().replace('ё', 'е')
    return ' '.join(re.findall(r'[^\W_]+', cleaned, flags=re.UNICODE))[:250]


def _titles(item):
    return {x for label in ('name', 'original', 'title') if (x := canonical_title(item.get(label)))}


def _year(value):
    try:
        year = int(str(value).strip()[:4])
        return year if 1900 <= year <= 2200 else None
    except (ValueError, TypeError):
        return None


def compare(a, b):
    """Return exact/suggested/None. Never claim identity from fuzzy search."""
    if not isinstance(a, dict) or not isinstance(b, dict):
        return None
    if a.get('source') == b.get('source'):
        return None
    if {a.get('source'), b.get('source')} != {'anixart', 'libria'}:
        return None
    ay, by = _year(a.get('year')), _year(b.get('year'))
    if ay is not None and by is not None and ay != by:
        return None
    aa, bb = _titles(a), _titles(b)
    if aa & bb:
        return 'exact'
    # Different seasons should not be silently linked. Fuzzy candidates are only
    # offered for manual inspection and NEVER deduplicated in catalog results.
    if aa and bb and max(SequenceMatcher(None, x, y).ratio() for x in aa for y in bb) >= .87:
        return 'suggested'
    return None


def group_catalog(anixart, libria):
    """Group exact Anixart/AniLiberty hits; retain both independent identifiers."""
    results = []
    matched_libria = set()
    for a in anixart:
        if not isinstance(a, dict):
            continue
        item = dict(a)
        pairs = [b for b in libria if isinstance(b, dict) and b.get('id') not in matched_libria and compare(a, b) == 'exact']
        if pairs:
            # Keep one Anixart record, but list all exact AniLiberty variants.
            matched_libria.update(b['id'] for b in pairs)
            item['availableSources'] = ['anixart', 'libria']
            item['alternatives'] = [dict(id=b['id'], source='libria', name=b.get('name', ''), original=b.get('original', ''), year=b.get('year', ''), match='exact') for b in pairs]
        results.append(item)
    results.extend(dict(b) for b in libria if isinstance(b, dict) and b.get('id') not in matched_libria)
    return results


def suggestions(anchor, candidates, maximum=12):
    records = []
    for item in candidates:
        status = compare(anchor, item)
        if status and item.get('id'):
            records.append(dict(id=item['id'], source=item['source'], name=item.get('name', ''), original=item.get('original', ''), year=item.get('year', ''), match=status, blocked=bool(item.get('blocked'))))
    records.sort(key=lambda x: (x['match'] != 'exact', canonical_title(x['name'])))
    return records[:maximum]
