"""Read-only external anime video provider response adapters.

No scraping, keys, password extraction or protected stream deciphering.
Remote iframe URLs are never trusted as local HTML or arbitrary FFmpeg inputs.
"""
from __future__ import annotations
import ipaddress
import re
from urllib.parse import urlparse, quote, urlencode

MIKAI_BASE = 'https://api.mikai.me/public/v1'
KINObOX_BASE = 'https://kinobox.tv/api/players'
ANIXART_BASE = 'https://api.anixsekai.com'

EMBED_DOMAINS = frozenset({
    'kodik.info', 'kodikplayer.com',
    'video.sibnet.ru', 'youtube.com', 'youtube-nocookie.com',
})

def external_url(url):
    """Accept only sensible external HTTPS sites, never local links/IPs/credentials."""
    if not isinstance(url, str) or not 8 <= len(url) <= 2048:
        return ''
    try:
        u = urlparse(url)
        if u.scheme != 'https' or not u.hostname or u.username or u.password:
            return ''
        host = u.hostname.lower().rstrip('.')
        if any(host == x or host.endswith('.'+x) for x in ('rutube.ru','vk.com','vkvideo.ru','vk.ru','vkvideo.app')):
            return ''
        if not re.fullmatch(r'[a-z0-9.-]+', host) or '..' in host or '.' not in host:
            return ''
        if host.endswith(('.local', '.localhost', '.internal', '.test', '.example', '.invalid', '.onion')):
            return ''
        if u.port not in (None, 443):
            return ''
        try:
            ipaddress.ip_address(host)
            return ''
        except ValueError:
            pass
        return url
    except (ValueError, UnicodeError):
        return ''

def embed_url(url):
    result = external_url(url)
    if not result:
        return ''
    host = urlparse(result).hostname
    return result if any(host == name or host.endswith('.'+name) for name in EMBED_DOMAINS) else ''

def player_from_url(name, url, episode='?', provider='', trusted_embed=False):
    url = external_url(url)
    if not url:
        return None
    return {
        'name': str(name or provider or 'Видеоплеер')[:100],
        'episode': str(episode or '?')[:50],
        'provider': str(provider or '')[:70],
        'embed': (url if trusted_embed else embed_url(url)),
        'external': url,
    }

def mikai_item(item):
    if not isinstance(item, dict):
        return None
    ids = item.get('ids') or {}
    if not isinstance(ids, dict) or not isinstance(ids.get('mikai'), int) or ids['mikai'] < 1:
        return None
    name = item.get('titles') or {}
    if not isinstance(name, dict): name = {}
    img = item.get('images') or {}
    if not isinstance(img, dict): img = {}
    poster = img.get('poster') or {}
    big = poster.get('big') if isinstance(poster, dict) else {}
    image = (big.get('webp') or big.get('jpg') or '') if isinstance(big, dict) else ''
    anime_id = ids['mikai']
    episodes = item.get('episodes')
    if isinstance(episodes, dict): episodes = episodes.get('localized') or episodes.get('aired') or episodes.get('total')
    return {
        'id': f'mikai:{anime_id}', 'remoteId': str(anime_id), 'source': 'mikai',
        'name': str(name.get('ua') or name.get('english') or name.get('original') or f'Аниме {anime_id}')[:250],
        'original': str(name.get('original') or name.get('english') or '')[:250],
        'image': external_url(image), 'description': str(item.get('description') or '')[:20000],
        'year': item.get('year') or (str(item.get('startDate') or '')[:4]),
        'rating': None, 'episodesTotal': episodes, 'category': item.get('format') or 'Аниме',
        'playable': not bool(item.get('licensed')), 'blocked': bool(item.get('licensed')),
        'url': 'https://mikai.me/anime/' + quote(str(ids.get('slug') or anime_id), safe=''),
    }

def mikai_players(data):
    if not isinstance(data, dict): return [], False, ''
    result = data.get('result', data)
    if not isinstance(result, dict): return [], False, ''
    licensed = result.get('licensed') is True
    license_text = ''
    if licensed:
        lic = result.get('license') or {}
        if isinstance(lic, dict): license_text = str(lic.get('name') or lic.get('title') or lic.get('holder') or '')[:150]
        return [], True, license_text
    players = []
    for release in (result.get('releases') or [])[:40]:
        if not isinstance(release, dict):continue
        teams = release.get('teams') or []
        titles = ', '.join(str(x.get('name') or '') for x in teams if isinstance(x, dict))[:100] or 'Озвучка'
        kind = 'Субтитры' if release.get('kind') == 'sub' else 'Озвучка'
        for ep in (release.get('episodes') or [])[:200]:
            if not isinstance(ep, dict): continue
            n = ep.get('label') or ep.get('number') or '?'
            for src in (ep.get('sources') or [])[:8]:
                if not isinstance(src, dict): continue
                prov = str(src.get('provider') or '')[:60]
                player = player_from_url(f'{kind}: {titles} · {prov}', src.get('embedUrl'), n, prov, trusted_embed=prov.lower() in {'ashdi','moon'})
                if player:players.append(player)
                if len(players) >= 800:return players, False, ''
    return players, False, ''

def kinobox_players(data):
    if not isinstance(data, list):return []
    results = []
    for group in data[:20]:
        if not isinstance(group, dict) or group.get('success') is False:continue
        provider = str(group.get('source') or 'Kinobox')[:80]
        for translation in (group.get('translations') or [])[:30]:
            if not isinstance(translation,dict):continue
            title = f'{provider} · {str(translation.get("name") or "Озвучка")[:90]}'
            quality = str(translation.get('quality') or '')[:30]
            player = player_from_url(title + (f' · {quality}' if quality else ''), translation.get('iframeUrl'), 'в плеере', provider, trusted_embed=provider.lower() in {'alloha','ashdi','cdnmovies','collaps','hdvb','kodik','turbo','vibix','videocdn','voidboost'})
            if player:results.append(player)
        if not group.get('translations'):
            player = player_from_url(provider,group.get('iframeUrl'),'в плеере',provider, trusted_embed=provider.lower() in {'alloha','ashdi','cdnmovies','collaps','hdvb','kodik','turbo','vibix','videocdn','voidboost'})
            if player:results.append(player)
        if len(results) >= 100:break
    return results[:100]

def anixart_dubs(payload):
    if not isinstance(payload, dict):return []
    return [{'id':x['id'], 'name':str(x.get('name') or f'Озвучка {x["id"]}')[:150], 'sub':bool(x.get('is_sub'))}
            for x in (payload.get('types') or [])[:100]
            if isinstance(x, dict) and isinstance(x.get('id'), int) and x['id']>=0]

def anixart_sources(payload):
    if not isinstance(payload,dict):return []
    return [{'id':x['id'], 'name':str(x.get('name') or f'Источник {x["id"]}')[:150], 'count':x.get('episodes_count',0)}
            for x in (payload.get('sources') or [])[:100]
            if isinstance(x,dict) and isinstance(x.get('id'),int) and x['id']>=0]

def anixart_episodes(payload):
    if not isinstance(payload,dict):return []
    players=[]
    for episode in (payload.get('episodes') or [])[:600]:
        if not isinstance(episode,dict):continue
        n = episode.get('name') or episode.get('position', '?')
        video=episode.get('url')
        player=player_from_url(f'Серия {n}',video,str(n),'Anixart',trusted_embed=episode.get('iframe') is True and not str(video).lower().split('?',1)[0].endswith(('.mp4','.m3u8')))
        if player:players.append(player)
    return players
