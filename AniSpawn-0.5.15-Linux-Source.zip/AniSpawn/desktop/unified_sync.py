"""AniSpawn unified desktop collection with opt-in account connection and write queue.

Local state is authoritative for pending user edits; remote snapshots are otherwise
read-only imported. Session secrets are never written to disk.
"""
from __future__ import annotations
import datetime
import json
import os
from pathlib import Path
import re
import threading

STATUS = {
    'anixart': {1:'Смотрю', 2:'В планах', 3:'Просмотрено', 4:'Отложено', 5:'Брошено'},
    'yani': {0:'Смотрю', 1:'В планах', 2:'Просмотрено', 3:'Брошено', 5:'Отложено'},
}
VALID_ID = re.compile(r'^(anixart|yani):[0-9]{1,12}$')

class UnifiedSync:
    def __init__(self, backend):
        self.backend=backend
        self.accounts=backend.accounts
        self.lock=threading.RLock()
        self.sync_lock=threading.Lock()
        self.pending_file=backend.directory/'sync-pending.json'
        self.pending={}
        try:
            obj=json.loads(self.pending_file.read_text('utf8'))
            if isinstance(obj,dict):
                for key,task in obj.items():
                    if VALID_ID.fullmatch(key) and isinstance(task,dict) and (task.get('status') is None or task.get('status') in STATUS[key.partition(':')[0]]):
                        self.pending[key]={'status':task.get('status'),'previous':task.get('previous'),'userId':task.get('userId')}
        except (OSError,ValueError,TypeError):pass
        # Populate the unified library offline from previous account caches on upgrade.
        for provider,obj in self.accounts.cached.items():
            if provider in STATUS and isinstance(obj,dict):
                self.merge_library(provider,obj.get('items',[]),authoritative=False,user_id=obj.get('userId'))

    def save_queue(self):
        tmp=self.pending_file.with_suffix('.tmp')
        tmp.write_text(json.dumps(self.pending,ensure_ascii=False,indent=2),encoding='utf8')
        os.chmod(tmp,0o600)
        tmp.replace(self.pending_file)

    def merge_library(self,provider,items,authoritative=True,user_id=None):
        if provider not in STATUS or not isinstance(items,list):return
        valid={x['id']:x for x in items if isinstance(x,dict) and VALID_ID.fullmatch(str(x.get('id',''))) and x['id'].startswith(provider+':')}
        with self.backend.lock:
            existing={x['id']:x for x in self.backend.state['bookmarks']}
            updated=[]
            for old in self.backend.state['bookmarks']:
                if old.get('remoteAccount')==provider and old['id'] not in valid and old['id'] not in self.pending and authoritative:
                    continue
                updated.append(old)
            present={x['id']:x for x in updated}
            for item_id,source in valid.items():
                if item_id in self.pending: continue
                old=present.get(item_id)
                values={'id':item_id,'name':str(source.get('name') or item_id)[:200], 'source':provider,
                        'image':str(source.get('image') or '')[:2000], 'year':str(source.get('year') or '')[:20],
                        'status':str(source.get('status') or 'В планах')[:60],
                        'statusId':source.get('statusId') if source.get('statusId') in STATUS[provider] else next((n for n,label in STATUS[provider].items() if label==source.get('status')),None),
                        'remoteAccount':provider,'remoteUserId':user_id}
                if old:old.update(values)
                else: updated.append(values)
            self.backend.state['bookmarks']=updated[-5000:]
            self.backend._save()

    def merge_history(self,provider,items):
        if provider not in STATUS or not isinstance(items,list): return
        with self.backend.lock:
            seen={(e['id'],str(e.get('episode',''))):e for e in self.backend.state['history']}
            for entry in items:
                if not isinstance(entry,dict) or not VALID_ID.fullmatch(str(entry.get('id',''))):continue
                key=(entry['id'],str(entry.get('episode','')))
                old=seen.get(key)
                # Never clobber a local seek position with empty remote history metadata.
                if old:
                    if float(entry.get('position') or 0)>float(old.get('position') or 0):
                        old['position']=entry['position']
                    old['completed']=bool(old.get('completed') or entry.get('completed'))
                    continue
                if len(self.backend.state['history'])>=1000:break
                clean={k:entry.get(k) for k in ('id','name','episode','date','position','duration','completed','remoteAccount')}
                self.backend.state['history'].append(clean)
                seen[key]=clean
            self.backend.state['history'].sort(key=lambda e:e.get('date') or '',reverse=True)
            self.backend._save();self.backend._write_history_txt()

    def edit(self,item,new_status):
        item_id=item.get('id') if isinstance(item,dict) else None
        if not isinstance(item_id,str) or not VALID_ID.fullmatch(item_id):raise ValueError('Неверный ID')
        provider=item_id.partition(':')[0]
        if new_status is not None and new_status not in STATUS[provider]:raise ValueError('Неизвестный статус')
        with self.lock,self.backend.lock:
            old=next((x for x in self.backend.state['bookmarks'] if x['id']==item_id),None)
            previous=old.get('statusId') if old else None
            if item_id in self.pending:previous=self.pending[item_id].get('previous')
            session=self.accounts.sessions.get(provider)
            user_id=(old or {}).get('remoteUserId') if old else None
            if user_id is None and isinstance(session,dict):user_id=session.get('user_id')
            if new_status is None:
                self.backend.state['bookmarks']=[x for x in self.backend.state['bookmarks'] if x['id']!=item_id]
            else:
                values={'id':item_id,'name':str(item.get('name') or (old or {}).get('name') or item_id)[:200],
                        'image':str(item.get('image') or (old or {}).get('image') or '')[:2000],
                        'source':provider,'year':str(item.get('year') or (old or {}).get('year') or '')[:20],
                        'status':STATUS[provider][new_status],'statusId':new_status,'remoteAccount':provider,'remoteUserId':user_id}
                if old:old.update(values)
                else:self.backend.state['bookmarks'].append(values)
            self.pending[item_id]={'previous':previous,'status':new_status,'userId':user_id}
            self.save_queue();self.backend._save()
            return {'bookmarks':self.backend.state['bookmarks'].copy(),'queued':True,'pending':len(self.pending)}

    def flush(self,provider):
        synced=0;errors=[]
        # Operation lock held around queue for consistency across concurrent RPC requests.
        with self.lock:
            session=self.accounts.sessions.get(provider)
            current_user=session.get('user_id') if isinstance(session,dict) else None
            for item_id,task in list(self.pending.items()):
                if not item_id.startswith(provider+':'):continue
                if task.get('userId') is not None and str(task['userId'])!=str(current_user):
                    errors.append('Изменение относится к другому аккаунту и не отправлено');continue
                try:self.accounts.change_remote_status(provider,item_id,task['status'],task.get('previous'))
                except Exception as err:errors.append(str(err)[:140]);continue
                self.pending.pop(item_id,None);synced+=1
            if synced:self.save_queue()
        return synced,errors

    def sync(self):
        with self.sync_lock:
            return self._sync_once()

    def _sync_once(self):
        report={'providers':{},'pending':0,'updated':False}
        for provider in STATUS:
            if not self.accounts.public(provider):
                report['providers'][provider]={'connected':False,'status':'Не подключён'}
                continue
            pushed,errors=self.flush(provider)
            try:
                lib=self.accounts.library(provider)
                if lib.get('stale'):
                    raise RuntimeError(lib.get('warning') or 'Нет связи с сервисом')
                self.merge_library(provider,lib.get('items',[]),user_id=lib.get('userId'))
                history_warning=None
                try:self.merge_history(provider,self.accounts.remote_history(provider))
                except Exception as ex:history_warning=str(ex)[:160]
                report['providers'][provider]={'connected':True,'status':'Синхронизировано',
                    'count':len(lib.get('items',[])),'pushed':pushed,'warning':history_warning or ('; '.join(errors) if errors else '')}
                report['updated']=True
            except Exception as err:
                report['providers'][provider]={'connected':True,'status':'Офлайн: локальные данные сохранены',
                                                'pushed':pushed,'warning':str(err)[:160]}
        report['pending']=len(self.pending)
        report['bookmarks']=len(self.backend.state['bookmarks'])
        report['history']=len(self.backend.state['history'])
        report['updatedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        return report
