"""Opt-in public release page import for AniSpawn.

Read metadata and an explicitly offered, allowlisted iframe. Never emulate an
account, solve a challenge, extract stream signatures, proxy whole websites,
read cookies, or download/crawl collections. User provides one URL at a time.
"""
from __future__ import annotations
from html.parser import HTMLParser
from html import unescape
import hashlib
import ipaddress
import re
from urllib.parse import urlsplit, urlunsplit, urljoin
import urllib.request

# Explicitly excludes RUTUBE and VK, including players discovered inside a site.
SITES = {
    'sovetromantica.com': 'SovetRomantica',
    'animevost.org': 'AnimeVost',
    'shiza-project.com': 'SHIZA-Project',
}
HOSTS = frozenset(SITES) | frozenset('www.' + x for x in SITES)
PLAYER_HOSTS = frozenset({
    'kodik.info', 'kodikplayer.com', 'video.sibnet.ru',
    'sovetromantica.com', 'animevost.org', 'shiza-project.com',
})
DISALLOWED_HOSTS = frozenset({'rutube.ru', 'vk.com', 'vkvideo.ru', 'vk.ru', 'vkvideo.app'})
MAX_HTML = 1_000_000


def forbidden_host(host):
    host = (host or '').lower().rstrip('.')
    return any(host == x or host.endswith('.' + x) for x in DISALLOWED_HOSTS)


def validate_page_url(value):
    if not isinstance(value, str) or not 16 <= len(value) <= 2048 or any(ord(x) < 32 for x in value):
        raise ValueError('Вставьте HTTPS-ссылку на страницу релиза')
    try:
        u = urlsplit(value.strip())
        host = (u.hostname or '').lower().rstrip('.')
        if (u.scheme != 'https' or host not in HOSTS or u.username or u.password
                or u.port is not None or u.fragment):
            raise ValueError()
        if host.endswith('sovetromantica.com'):
            valid = re.fullmatch(r'/anime/[0-9]{1,8}-[a-z0-9-]{1,150}/?', u.path)
        elif host.endswith('animevost.org'):
            valid = re.fullmatch(r'/tip/(?:[a-z0-9-]{1,60}/){1,4}[0-9]{1,8}-[a-z0-9-]{1,140}\.html', u.path)
        else:
            valid = re.fullmatch(r'/releases/(?:@|%40)[0-9]{5,25}/?', u.path, flags=re.I)
        if not valid or u.query:
            raise ValueError()
        return urlunsplit(('https', host, u.path, '', ''))
    except (ValueError, UnicodeError):
        raise ValueError('Поддерживаются только публичные релизы SovetRomantica, AnimeVost и SHIZA-Project') from None


def safe_public_url(value, base=''):
    if not isinstance(value, str) or not value or len(value) > 2048:
        return ''
    try:
        u = urlsplit(urljoin(base, value))
        host = (u.hostname or '').lower().rstrip('.')
        if u.scheme != 'https' or not host or forbidden_host(host) or u.username or u.password or u.port not in (None, 443):
            return ''
        if '.' not in host or host.endswith(('.local', '.internal', '.onion', '.test', '.invalid', '.localhost')):
            return ''
        try:
            ipaddress.ip_address(host)
            return ''
        except ValueError:
            pass
        return u.geturl()
    except (ValueError, UnicodeError):
        return ''


def allowed_embed(value):
    url = safe_public_url(value)
    if not url:
        return ''
    u = urlsplit(url)
    host = (u.hostname or '').lower().rstrip('.')
    for provider in PLAYER_HOSTS:
        if host == provider or host.endswith('.' + provider):
            # The original website's *release page* is not itself an iframe.
            if provider in SITES and not re.match(r'^/(?:embed|player|video/embed)/', u.path, re.I):
                return ''
            return url
    return ''


class PublicPageParser(HTMLParser):
    def __init__(self, base):
        super().__init__(convert_charrefs=True)
        self.base = base
        self.meta = {}
        self.frames = []
        self.title = ''
        self._title = False
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == 'meta':
            name = (a.get('property') or a.get('name') or '').lower()
            if name in ('og:title', 'twitter:title', 'og:description', 'description',
                        'og:image', 'twitter:image', 'og:video', 'og:video:url'):
                value = a.get('content', '')
                if value and name not in self.meta:
                    self.meta[name] = unescape(value[:2500])
        elif tag == 'iframe' and len(self.frames) < 20:
            candidate = allowed_embed(urljoin(self.base, a.get('src') or ''))
            if candidate and candidate not in self.frames:
                self.frames.append(candidate)
        elif tag == 'title':
            self._title = True
    def handle_endtag(self, tag):
        if tag == 'title':
            self._title = False
    def handle_data(self, data):
        if self._title and len(self.title) < 400:
            self.title += data[:400]


def read_public_html(page, open_url, timeout=8):
    """One explicitly chosen page; app transport rejects redirects and honours DNS/proxy."""
    page = validate_page_url(page)
    request = urllib.request.Request(page, headers={
        'User-Agent': 'AniSpawn/0.5.14 (desktop public-page import; user initiated)',
        'Accept': 'text/html,application/xhtml+xml',
    })
    with open_url(request, timeout=timeout) as response:
        # Guard even if a custom transport replaces the project's no-redirect opener.
        if response.geturl() != page:
            raise ValueError('Переадресация запрещена: используйте конечную ссылку на релиз')
        if not any(x in response.headers.get('Content-Type', '').lower() for x in ('text/html', 'application/xhtml+xml')):
            raise ValueError('Сайт не вернул HTML-страницу')
        data = response.read(MAX_HTML + 1)
        if len(data) > MAX_HTML:
            raise ValueError('HTML-страница слишком большая')
        return data.decode('utf-8', 'replace')


def import_page(page, html):
    page = validate_page_url(page)
    if not isinstance(html, str):
        raise ValueError('Некорректный HTML')
    parsed = PublicPageParser(page)
    parsed.feed(html[:MAX_HTML])
    host = urlsplit(page).hostname.removeprefix('www.')
    site = SITES[host]
    title = (parsed.meta.get('og:title') or parsed.meta.get('twitter:title') or parsed.title).strip()
    if not title:
        title = f'Релиз {site}'
    description = (parsed.meta.get('og:description') or parsed.meta.get('description') or '')[:3000]
    poster = safe_public_url(parsed.meta.get('og:image') or parsed.meta.get('twitter:image') or '', page)
    meta_embed = allowed_embed(parsed.meta.get('og:video:url') or parsed.meta.get('og:video') or '')
    embeds = list(dict.fromkeys(([meta_embed] if meta_embed else []) + parsed.frames))[:20]
    key = hashlib.sha256(page.encode('utf-8')).hexdigest()[:32]
    players = [{'name': site, 'episode': 'на сайте', 'provider': site, 'embed': url, 'external': url}
               for url in embeds]
    return {'id': 'sites:' + key, 'remoteId': key, 'source': 'sites',
            'name': title[:240], 'original': '', 'image': poster,
            'description': description, 'year': '', 'rating': None,
            'episodesTotal': None, 'category': site + ' · публичная страница',
            'playable': bool(players), 'blocked': False, 'url': page,
            'players': players, 'episodes': [],
            'credits': site + ' · импорт публичной HTML-страницы'}
