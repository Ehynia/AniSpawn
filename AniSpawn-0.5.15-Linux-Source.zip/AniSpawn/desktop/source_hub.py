"""Federated public catalogs and bounded background health checks for AniSpawn.

A provider's items keep their native IDs. Only Anixart/AniLiberty can be grouped
by their existing conservative exact-match rules. Site imports are local user-
selected pages, NOT evidence that the remote site or its player is online.
"""
from __future__ import annotations
import concurrent.futures
import copy
import threading
import time
from urllib.parse import urlsplit

import shared_sources
import site_bridges
import network_settings

CATALOG_SOURCES = ('anixart', 'libria', 'mikai', 'yani', 'kodik', 'shiki', 'anilist', 'jikan')
SITE_IDS = {'sovetromantica.com': 'site-sovetromantica', 'animevost.org': 'site-animevost', 'shiza-project.com': 'site-shiza'}


def status_entry(source, state='unknown', *, count=0, ms=None, message='', updated=None):
    return {'id': source, 'state': state, 'count': max(0, int(count)), 'ms': ms,
            'message': str(message or '')[:190], 'updated': updated}


def requirement(backend, source):
    if source == 'yani' and not backend.yani_token:
        return 'Нужен ключ приложения Yani (X-Application); пользовательский логин его не заменяет'
    if source == 'kodik' and not backend.kodik_token:
        return 'Нужен разрешённый Kodik API-токен'
    return ''


def merge_catalog(results, page=1, query=''):
    """Keep provider identity and video rights; group only verified cross-IDs."""
    anix = results.get('anixart', {}).get('items', [])
    libria = results.get('libria', {}).get('items', [])
    grouped = shared_sources.group_catalog(anix, libria)
    seen = {r.get('id') for r in grouped}
    for source in CATALOG_SOURCES:
        if source in ('anixart', 'libria'):
            continue
        for record in results.get(source, {}).get('items', []):
            if isinstance(record, dict) and record.get('id') and record['id'] not in seen:
                grouped.append(dict(record))
                seen.add(record['id'])
    return grouped


class SourceHub:
    def __init__(self, backend):
        self.backend = backend
        self._lock = threading.RLock()
        self._rows = {s: status_entry(s) for s in CATALOG_SOURCES}
        self._site_rows = {ident: status_entry(ident, 'not_imported') for ident in SITE_IDS.values()}
        self._testing = False
        self._generation = 0
        self._last_test = None

    def update(self, source, state, count=0, ms=None, message=''):
        with self._lock:
            self._rows[source] = status_entry(source, state, count=count, ms=ms,
                                               message=message, updated=time.time())

    def is_busy(self):
        with self._lock:
            return self._testing

    def snapshot(self):
        with self._lock:
            rows = copy.deepcopy(self._rows)
            sites = copy.deepcopy(self._site_rows)
            testing = self._testing
            tested_at = self._last_test
        for source in CATALOG_SOURCES:
            required = requirement(self.backend, source)
            if required:
                rows[source] = status_entry(source, 'auth_required', message=required)
        # Locally saved pages are not a health signal for their remote sites.
        with self.backend.lock:
            items = [dict(x) for x in self.backend.site_items.values()]
        for host, ident in SITE_IDS.items():
            page_items = [x for x in items if (urlsplit(x.get('url', '')).hostname or '').removeprefix('www.') == host]
            if not page_items:
                sites[ident] = status_entry(ident, 'not_imported', message='Нет импортированных страниц')
            elif sites[ident]['state'] == 'not_imported':
                sites[ident] = status_entry(ident, 'saved', count=len(page_items),
                                           message='Страницы сохранены; доступность сайта ещё не проверена')
            else:
                sites[ident]['count'] = len(page_items)
        rows.update(sites)
        rows['sites'] = status_entry('sites', 'saved' if items else 'not_imported', count=len(items),
                                     message='Сохранённые страницы; плееры проверяются при открытии')
        responsive = sum(1 for s in CATALOG_SOURCES if rows[s]['state'] == 'online')
        cached = sum(1 for s in CATALOG_SOURCES if rows[s]['state'] == 'cached')
        rows['all'] = status_entry('all', 'online' if responsive else 'cached' if cached or items else 'offline',
                                   count=responsive+cached, message=f'{responsive} API доступны, {cached} с кэшем')
        pair = [rows[x]['state'] for x in ('anixart', 'libria')]
        rows['both'] = status_entry('both', 'online' if 'online' in pair else 'cached' if 'cached' in pair else 'offline',
                                    count=sum(x == 'online' for x in pair))
        return {'testing': testing, 'testedAt': tested_at, 'sources': rows,
                'summary': {'online': responsive, 'cached': cached,
                            'unavailable': sum(rows[x]['state'] == 'offline' for x in CATALOG_SOURCES),
                            'authRequired': sum(rows[x]['state'] == 'auth_required' for x in CATALOG_SOURCES)}}

    def combined(self, page=1, query=''):
        page = max(1, min(100, int(page)))
        query = str(query or '').strip()[:120]
        results = {}
        failures = {}
        def load(source):
            key = f'search:{source}:{page}:{query}' if query else f'list:{source}:{page}'
            return self.backend._cached(key, lambda: self.backend.catalog(source, page, query))
        eligible = [s for s in CATALOG_SOURCES if not requirement(self.backend, s)]
        for s in CATALOG_SOURCES:
            if s not in eligible:
                self.update(s, 'auth_required', message=requirement(self.backend, s))
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(eligible) or 1, thread_name_prefix='source-catalog') as pool:
            futures = {pool.submit(load, s): s for s in eligible}
            for future in concurrent.futures.as_completed(futures):
                source = futures[future]
                try:
                    result = future.result()
                    results[source] = result
                    self.update(source, 'cached' if result.get('stale') else 'online',
                                len(result.get('items', [])),
                                message='Использован сохранённый каталог' if result.get('stale') else '')
                except Exception as exc:
                    failures[source] = str(exc)[:140]
                    self.update(source, 'offline', message=failures[source])
        items = merge_catalog(results, page, query)
        # Sites remain user-imported-only; importing a page does not crawl a domain.
        site_items = self.backend.sites_catalog(page, query)
        ids = {x['id'] for x in items}
        items.extend(x for x in site_items if x.get('id') not in ids)
        warnings = [f'{s}: {msg}' for s, msg in failures.items()]
        warnings.extend(f'{s}: кэш' for s, result in results.items() if result.get('stale'))
        # If online providers return nothing, report that faithfully instead of using a fake list.
        if not results and not site_items:
            return {'items': [], 'stale': True, 'warning': 'Нет доступных источников · '+'; '.join(warnings)[:220],
                    'providers': {s: self.snapshot()['sources'][s]['state'] for s in CATALOG_SOURCES}}
        return {'items': items, 'stale': bool(warnings), 'warning': ' · '.join(warnings)[:380],
                'providers': {s: ('offline' if s in failures else 'cached' if results.get(s, {}).get('stale') else
                                   'online' if s in results else 'auth_required') for s in CATALOG_SOURCES}}

    def _check_one(self, source):
        start = time.monotonic()
        try:
            key = f'list:{source}:1'
            result = self.backend._cached(key, lambda: self.backend.catalog(source, 1))
            self.update(source, 'cached' if result.get('stale') else 'online',
                        len(result.get('items', [])), round((time.monotonic()-start)*1000),
                        'Сохранённый каталог' if result.get('stale') else '')
        except Exception as exc:
            self.update(source, 'offline', ms=round((time.monotonic()-start)*1000), message=str(exc))

    def _check_site(self, ident, item):
        start = time.monotonic()
        try:
            # Only verify already imported, expressly selected URLs; no scraping/indexing.
            site_bridges.read_public_html(item['url'], network_settings.open_url, timeout=6)
            outcome = status_entry(ident, 'online', ms=round((time.monotonic()-start)*1000),
                                   message='Публичная страница отвечает; воспроизведение не гарантировано',updated=time.time())
        except Exception as exc:
            outcome = status_entry(ident, 'cached', ms=round((time.monotonic()-start)*1000),
                                   message='Сайт недоступен, импорт сохранён: '+str(exc)[:100],updated=time.time())
        with self._lock:
            self._site_rows[ident] = outcome

    def refresh(self):
        with self._lock:
            if self._testing:
                return self.snapshot()
            self._testing = True
            self._generation += 1
            for source in CATALOG_SOURCES:
                self._rows[source] = status_entry(source, 'checking') if not requirement(self.backend, source) else status_entry(source, 'auth_required')
        def worker():
            try:
                with self.backend.lock:
                    pages = [dict(x) for x in self.backend.site_items.values()]
                eligible = [s for s in CATALOG_SOURCES if not requirement(self.backend, s)]
                tasks = []
                with concurrent.futures.ThreadPoolExecutor(max_workers=min(9, len(eligible) + 3) or 1) as pool:
                    for src in eligible:
                        tasks.append(pool.submit(self._check_one, src))
                    for host, ident in SITE_IDS.items():
                        item = next((x for x in pages if (urlsplit(x.get('url', '')).hostname or '').removeprefix('www.') == host), None)
                        if item:
                            tasks.append(pool.submit(self._check_site, ident, item))
                    for job in concurrent.futures.as_completed(tasks):
                        job.result()
            finally:
                with self._lock:
                    self._testing = False
                    self._last_test = time.time()
        threading.Thread(target=worker, name='source-health', daemon=True).start()
        return self.snapshot()
