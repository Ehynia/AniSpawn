"""AniSpawn-only DNS-over-HTTPS and proxy transport, stdlib and verified TLS.

No system DNS changes, no TLS bypass, no untrusted resolver URLs.  Proxy
credentials are deliberately unsupported (nothing sensitive stored on disk).
SOCKS5 sends destination hostnames to the proxy to avoid local DNS leaks.
"""
from __future__ import annotations
import base64
import concurrent.futures
import copy
import http.client
import ipaddress
import json
import os
from pathlib import Path
import secrets
import socket
import ssl
import struct
import threading
import time
import urllib.parse
import urllib.request

DOH = {
    'cloudflare': dict(name='Cloudflare 1.1.1.1', host='cloudflare-dns.com', ip='1.1.1.1', path='/dns-query', url='https://cloudflare-dns.com/dns-query'),
    'google': dict(name='Google Public DNS', host='dns.google', ip='8.8.8.8', path='/dns-query', url='https://dns.google/dns-query'),
    'adguard': dict(name='AdGuard DNS', host='dns.adguard-dns.com', ip='94.140.14.14', path='/dns-query', url='https://dns.adguard-dns.com/dns-query'),
}
MODES = ('auto','system',*DOH)
TEST_HOSTS = ('api.anixsekai.com','api-s.anixsekai.com','anilibria.top')
MAX_PROXY_LEN = 240


def validate_proxy(raw):
    if not isinstance(raw,str) or len(raw)>MAX_PROXY_LEN:
        raise ValueError('Некорректный адрес прокси')
    if not raw:return ''
    try:
        p=urllib.parse.urlsplit(raw)
        if p.scheme not in ('http','socks5') or not p.hostname or p.username or p.password or p.query or p.fragment or p.path not in ('','/') or not 1<=p.port<=65535:
            raise ValueError()
        if any(c in raw for c in '\r\n\t '):raise ValueError()
        host=p.hostname
        if ':' in host:host='['+host+']'
        return f'{p.scheme}://{host}:{p.port}'
    except (ValueError,TypeError) as exc:
        raise ValueError('Используйте http://хост:порт или socks5://хост:порт, без логина и пароля') from None


def _read_exact(sock, n):
    data=b''
    while len(data)<n:
        chunk=sock.recv(n-len(data))
        if not chunk:raise OSError('SOCKS5: connection closed')
        data+=chunk
    return data


def _socks_connect(host,port,proxy,timeout):
    target=urllib.parse.urlsplit(proxy)
    sock=socket.create_connection((target.hostname,target.port),timeout=timeout)
    try:
        sock.settimeout(timeout)
        sock.sendall(b'\x05\x01\x00')
        if _read_exact(sock,2)!=b'\x05\x00':raise OSError('SOCKS5 authentication not supported')
        host_bytes=host.encode('idna')
        if len(host_bytes)>255:raise ValueError('Host too long')
        sock.sendall(b'\x05\x01\x00\x03'+bytes([len(host_bytes)])+host_bytes+struct.pack('!H',port))
        response=_read_exact(sock,4)
        if response[0]!=5 or response[1]!=0:raise OSError('SOCKS5 connection refused')
        length=4 if response[3]==1 else 16 if response[3]==4 else _read_exact(sock,1)[0] if response[3]==3 else None
        if length is None:raise OSError('Malformed SOCKS5 response')
        _read_exact(sock,length+2)
        return sock
    except Exception:
        sock.close();raise


class _RoutedHTTPS(http.client.HTTPSConnection):
    def __init__(self, host, *, resolver=None, proxy='', **kw):
        super().__init__(host, **kw)
        self.resolver=resolver
        self.proxy=proxy
    def connect(self):
        # HTTP CONNECT is handled by urllib's ProxyHandler, never this path.
        if self.proxy.startswith('socks5://'):
            raw=_socks_connect(self.host,self.port,self.proxy,self.timeout)
        elif self.resolver:
            raw=None;error=None
            for ip in self.resolver(self.host):
                try:
                    raw=socket.create_connection((ip,self.port),timeout=self.timeout)
                    break
                except (OSError,TimeoutError) as exc:error=exc
            if raw is None:raise error or OSError('DNS resolution failed')
        else:
            raw=socket.create_connection((self.host,self.port),timeout=self.timeout)
        try:
            self.sock=self._context.wrap_socket(raw, server_hostname=self.host)
        except Exception:
            raw.close();raise


class _RoutingHandler(urllib.request.HTTPSHandler):
    def __init__(self, resolver=None,proxy=''):
        super().__init__()
        self.resolver=resolver;self.proxy=proxy
    def https_open(self,req):
        return self.do_open(lambda host,**kw:_RoutedHTTPS(host,resolver=self.resolver,proxy=self.proxy,**kw),req)


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):return None


def _parse_dns_packet(packet, expected_id):
    if len(packet)<12:raise ValueError('DoH packet too short')
    qid,flags,qd,an,_,_=struct.unpack('!HHHHHH',packet[:12])
    if qid!=expected_id or flags & 0x8000==0 or flags & 0xF!=0 or qd!=1:raise ValueError('Invalid DoH DNS answer')
    def skip_name(pos):
        for _ in range(128):
            if pos>=len(packet):raise ValueError('Bad DNS name')
            size=packet[pos]
            if size&0xc0==0xc0:
                if pos+1>=len(packet):raise ValueError('Bad DNS pointer')
                return pos+2
            if size&0xc0:raise ValueError('Bad DNS label')
            pos+=1
            if size==0:return pos
            pos+=size
        raise ValueError('Long DNS name')
    pos=skip_name(12)+4
    results=[]
    for _ in range(min(an,64)):
        pos=skip_name(pos)
        if pos+10>len(packet):raise ValueError('Bad DNS answer')
        kind,cl,_,length=struct.unpack('!HHIH',packet[pos:pos+10]);pos+=10
        if pos+length>len(packet):raise ValueError('Bad DNS rdata')
        if kind==1 and cl==1 and length==4:
            ip=str(ipaddress.IPv4Address(packet[pos:pos+4]))
            if ipaddress.ip_address(ip).is_global:results.append(ip)
        pos+=length
    if not results:raise OSError('Resolver returned no public IPv4 records')
    return list(dict.fromkeys(results))


def dns_query(provider,domain,timeout=4):
    """RFC 8484 wireformat with fixed bootstrap IP and verified SNI/certificate."""
    if provider not in DOH:raise ValueError('Unknown DoH resolver')
    if not isinstance(domain,str) or len(domain)>253 or not all(0<len(x)<=63 for x in domain.split('.')):raise ValueError('Invalid DNS name')
    info=DOH[provider];qid=secrets.randbelow(65536)
    labels=[label.encode('idna') for label in domain.split('.')]
    if any(len(label)>63 for label in labels):raise ValueError('Invalid DNS label')
    encoded=b''.join(bytes([len(label)])+label for label in labels)+b'\x00'
    request=struct.pack('!HHHHHH',qid,0x0100,1,0,0,0)+encoded+b'\x00\x01\x00\x01'
    qs=urllib.parse.urlencode({'dns':base64.urlsafe_b64encode(request).rstrip(b'=').decode('ascii')})
    connection=_RoutedHTTPS(info['host'],resolver=lambda _: [info['ip']],timeout=timeout)
    try:
        connection.request('GET',info['path']+'?'+qs,headers={'Accept':'application/dns-message'})
        reply=connection.getresponse()
        if reply.status!=200:raise OSError('DoH HTTP '+str(reply.status))
        answer=reply.read(8193)
        if len(answer)>8192:raise ValueError('DoH response too long')
        return _parse_dns_packet(answer,qid)
    finally:connection.close()


class NetworkManager:
    def __init__(self,directory):
        self.path=Path(directory)/'network-settings.json'
        self.lock=threading.RLock()
        self.settings={'mode':'auto','selected':'system','proxy':'','tested':False}
        self.results=[];self.testing=False;self.cache={}
        try:
            raw=json.loads(self.path.read_text(encoding='utf8'))
            self.configure({k:raw[k] for k in ('mode','proxy') if k in raw},save=False)
            if isinstance(raw.get('results'),list):
                self.results=[x for x in raw['results'][:4] if isinstance(x,dict) and x.get('id') in ('system',*DOH)]
            if raw.get('tested') is True:self.settings['tested']=True
            if raw.get('selected') in ('system',*DOH):self.settings['selected']=raw['selected']
        except (OSError,ValueError,TypeError,AttributeError):pass

    def _write(self):
        tmp=self.path.with_suffix('.tmp')
        tmp.write_text(json.dumps({**self.settings,'results':self.results},ensure_ascii=False,indent=2),encoding='utf8')
        os.chmod(tmp,0o600);tmp.replace(self.path)

    def configure(self,patch,save=True):
        if not isinstance(patch,dict):raise ValueError('Неверные параметры сети')
        if set(patch).difference({'mode','proxy','selected','tested'}):raise ValueError('Неизвестный параметр сети')
        mode=patch.get('mode',self.settings['mode']);proxy=validate_proxy(patch.get('proxy',self.settings['proxy']))
        if mode not in MODES:raise ValueError('Неизвестный DNS сервер')
        with self.lock:
            self.settings['mode']=mode
            self.settings['proxy']=proxy
            self.settings['selected']=mode if mode!='auto' else self.settings['selected']
            self.cache.clear()
            if save:self._write()
            return self.status()

    def status(self):
        with self.lock:
            s=copy.deepcopy(self.settings)
            return {**s,'effectiveDns':'proxy' if s['proxy'] else (s['selected'] if s['mode']=='auto' else s['mode']),
                    'testing':self.testing,'results':copy.deepcopy(self.results),'restartBrowser':bool(s['proxy'] or s['mode']!='system')}

    def lookup(self,host,provider):
        with self.lock:
            item=self.cache.get((provider,host))
            if item and item[1]>time.monotonic():return item[0]
        addresses=dns_query(provider,host)
        with self.lock:self.cache[(provider,host)]=(addresses,time.monotonic()+90)
        return addresses

    def open(self,request,timeout):
        with self.lock:s=dict(self.settings)
        proxy=s['proxy'];mode=s['selected'] if s['mode']=='auto' else s['mode']
        if proxy.startswith('http://'):
            opener=urllib.request.build_opener(urllib.request.ProxyHandler({'http':proxy,'https':proxy}),_NoRedirect)
        elif proxy.startswith('socks5://'):
            opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),_RoutingHandler(proxy=proxy),_NoRedirect)
        elif mode in DOH:
            opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),_RoutingHandler(resolver=lambda host:self.lookup(host,mode)),_NoRedirect)
        else:
            opener=urllib.request.build_opener(_NoRedirect)
        return opener.open(request,timeout=timeout)

    def _probe(self,provider):
        stamp=time.monotonic();good=0;dns_ok=0;errors=[];good_hosts=set()
        for host in TEST_HOSTS:
            try:
                if provider=='system':
                    addresses=[x[4][0] for x in socket.getaddrinfo(host,443,type=socket.SOCK_STREAM)]
                else:addresses=self.lookup(host,provider)
                dns_ok+=1
                conn=_RoutedHTTPS(host,resolver=lambda _:addresses,timeout=3)
                try:
                    conn.request('HEAD','/',headers={'User-Agent':'AniSpawn-DNS-check'})
                    response=conn.getresponse()
                    if 100<=response.status<500:good+=1;good_hosts.add(host)
                    else:errors.append(host+': HTTP '+str(response.status))
                finally:conn.close()
            except (OSError,TimeoutError,ssl.SSLError,ValueError) as exc:
                errors.append(host+': '+type(exc).__name__)
        latency=int((time.monotonic()-stamp)*1000)
        # One of the two published Anixart endpoints plus AniLiberty must work.
        # The RU host alone is not representative of the Anixart service.
        healthy_anixart = any(host in good_hosts for host in TEST_HOSTS[:2])
        healthy_libria = TEST_HOSTS[-1] in good_hosts
        return {'id':provider,'name':'Системный DNS' if provider=='system' else DOH[provider]['name'],
                'dnsOk':dns_ok,'httpsOk':good,'checks':len(TEST_HOSTS),'ms':latency,'ok':healthy_anixart and healthy_libria,
                'error':'; '.join(errors)[:150]}

    def benchmark(self):
        with self.lock:
            if self.testing:return self.status()
            self.testing=True
        try:
            providers=['system',*DOH]
            with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
                output=list(pool.map(self._probe,providers))
            healthy=[x for x in output if x['ok']]
            # Incomplete TLS connectivity must not win solely on DNS lookup speed.
            best=min(healthy,key=lambda x:x['ms'])['id'] if healthy else 'system'
            with self.lock:
                self.results=output
                if self.settings['mode']=='auto':self.settings['selected']=best
                self.settings['tested']=True
                self._write()
            return self.status()
        finally:
            with self.lock:self.testing=False

    def start_first_run_test(self):
        with self.lock:
            if self.settings['tested'] or self.testing:return
        threading.Thread(target=self.benchmark,daemon=True,name='AniSpawn-DNS-probe').start()

    def browser_flags(self):
        with self.lock:s=dict(self.settings)
        if s['proxy']:
            # Chromium owns iframe/media requests; proxy is scoped to this app's browser.
            return ['--proxy-server='+s['proxy']]
        mode=s['selected'] if s['mode']=='auto' else s['mode']
        if mode in DOH:
            return ['--dns-over-https-templates='+DOH[mode]['url'],'--dns-over-https-mode=secure']
        return []

    def ffmpeg_proxy_flags(self):
        with self.lock:proxy=self.settings['proxy']
        # FFmpeg supports HTTP CONNECT, but not SOCKS5 natively.
        return ['-http_proxy',proxy] if proxy.startswith('http://') else []

_active=None

def set_active(manager):
    global _active
    _active=manager

def open_url(request,timeout=7):
    if _active is None:
        return urllib.request.urlopen(request,timeout=timeout)
    return _active.open(request,timeout)
