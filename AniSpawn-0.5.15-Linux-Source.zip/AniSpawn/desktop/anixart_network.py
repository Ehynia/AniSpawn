"""Resilient Anixart API requests, without disabling TLS verification.

Only two Anixart hosts explicitly published in AnixHelper/pages/urls.json are
trusted. Connection failures trigger one alternate-host attempt; HTTP 401,
403, 404 and 429 never trigger host hopping. This is transport failover, not
an attempt to bypass service content restrictions or authorization.
"""
from __future__ import annotations
import json
import socket
import ssl
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import network_settings

HOSTS = ('https://api.anixsekai.com', 'https://api-s.anixsekai.com')
_STATE_LOCK = threading.Lock()
_preferred = None
_preferred_until = 0.0

class ApiUnavailable(RuntimeError):
    """Both trusted HTTPS endpoints could not be reached."""

class ApiResponseError(RuntimeError):
    """The API returned a non-retryable error or invalid JSON."""

class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

_OPENER = urllib.request.build_opener(_NoRedirect)

def _open(request, timeout):
    return network_settings.open_url(request, timeout=timeout)

def _host_order():
    with _STATE_LOCK:
        preferred = _preferred if time.monotonic() < _preferred_until else None
    return (preferred, *(x for x in HOSTS if x != preferred)) if preferred else HOSTS

def _mark_success(host):
    global _preferred, _preferred_until
    with _STATE_LOCK:
        _preferred, _preferred_until = host, time.monotonic() + 300

def request_json(url, method='GET', data=None, timeout=5, headers=None, form=False):
    """Call an allowlisted Anixart API URL with bounded TLS/mirror failover.

    Secrets and full URLs are deliberately absent from errors and logs.
    Request bodies are never written to disk. A failed TLS handshake on the
    first host is followed by a single attempt against the other known host.
    """
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != 'https' or parsed.username or parsed.password or parsed.port not in (None, 443) or parsed.netloc not in ('api.anixsekai.com', 'api-s.anixsekai.com') or not parsed.path.startswith('/') or parsed.path.startswith('//'):
        raise ValueError('Неподдерживаемый адрес API Anixart')
    if method not in ('GET', 'POST'):
        raise ValueError('Неподдерживаемый метод API Anixart')
    # Do not use parsed URL's host for the request until it has been allowlisted.
    path = urllib.parse.urlunsplit(('', '', parsed.path, parsed.query, ''))
    body = (urllib.parse.urlencode(data).encode('utf8') if form else json.dumps(data).encode('utf8')) if data is not None else None
    request_headers = {'Accept': 'application/json', 'User-Agent': 'AniSpawn/0.5.13',
                       **({'Content-Type': 'application/x-www-form-urlencoded' if form else 'application/json'} if body is not None else {}),
                       **(headers or {})}
    # Never accept caller-controlled Host headers or auth-bearing URL redirects.
    request_headers = {k:v for k,v in request_headers.items() if k.lower() not in ('host','proxy-authorization')}
    timeout = min(8, max(2, float(timeout)))
    last_reason = 'нет соединения'
    for host in _host_order():
        request = urllib.request.Request(host + path, data=body, headers=request_headers, method=method)
        try:
            with _open(request, timeout) as response:
                if response.status >= 400:
                    raise ApiResponseError('Anixart: HTTP ' + str(response.status))
                result = json.loads(response.read(6_000_001))
            if not isinstance(result, (dict, list)):
                raise ApiResponseError('Anixart вернул ответ неизвестного формата')
            _mark_success(host)
            return result
        except urllib.error.HTTPError as exc:
            if exc.code in (502, 503, 504):
                last_reason = 'HTTP ' + str(exc.code)
                continue
            raise ApiResponseError('Anixart: HTTP ' + str(exc.code)) from None
        except (urllib.error.URLError, socket.timeout, TimeoutError, ssl.SSLError, OSError):
            last_reason = 'соединение или TLS-рукопожатие не завершилось'
        except (json.JSONDecodeError, UnicodeDecodeError):
            raise ApiResponseError('Anixart вернул невалидный JSON') from None
    raise ApiUnavailable('Anixart недоступен с обоих API-адресов: ' + last_reason + '. Можно открыть сохранённую карточку.')


def diagnose(timeout=4):
    """Probe the two published API hosts separately (never send account tokens).

    A valid TLS connection is not equivalent to API permission or success. This
    function intentionally reports those stages separately; it does not follow
    redirects or switch hosts for an individual probe.
    """
    timeout = min(6, max(2, float(timeout)))
    results = []
    for host in HOSTS:
        began = time.monotonic()
        row = {'host': urllib.parse.urlsplit(host).hostname, 'tls': False,
               'http': None, 'api': False, 'ms': None, 'error': ''}
        try:
            # A documented random release metadata endpoint exercises the API JSON path.
            # No credentials and no third-party links are included.
            req = urllib.request.Request(host + '/release/random?extended_mode=false',
                  headers={'Accept':'application/json', 'User-Agent':'AniSpawn/0.5.13 network-check'},
                  method='GET')
            with _open(req, timeout) as response:
                row['tls'] = True
                row['http'] = response.status
                data = json.loads(response.read(262144))
            if isinstance(data, dict) and data.get('code') == 0 and isinstance(data.get('release'),dict):
                row['api'] = True
            else:
                row['error'] = 'Ответ HTTPS получен, но данные релиза не подтверждены'
        except urllib.error.HTTPError as exc:
            row['tls'] = True
            row['http'] = exc.code
            row['error'] = 'API отказал в доступе' if exc.code in (401,403) else ('HTTP '+str(exc.code))
        except (urllib.error.URLError, socket.timeout, TimeoutError, ssl.SSLError, OSError):
            row['error'] = 'Ошибка соединения или TLS'
        except (ValueError, UnicodeError):
            row['tls'] = True
            row['error'] = 'Неожиданный формат ответа API'
        row['ms'] = int((time.monotonic()-began)*1000)
        results.append(row)
    available = any(x['api'] for x in results)
    connected = any(x['tls'] for x in results)
    return {'available':available, 'connected':connected, 'hosts':results,
            'summary': ('API Anixart доступен' if available else
                        'HTTPS доступен, но API не вернул пригодный ответ' if connected else
                        'Нет защищённого соединения с обоими Anixart API; смена DNS поможет только при проблемах DNS')}
