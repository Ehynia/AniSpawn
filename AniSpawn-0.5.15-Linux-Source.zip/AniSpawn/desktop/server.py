#!/usr/bin/env python3
"""AniSpawn Linux standalone backend: stdlib-only API and loopback desktop transport.
Renderer runs in a private Chromium --app window, not in a regular browser tab.
"""
from __future__ import annotations
import contextlib
import concurrent.futures
import hashlib
import math
import copy
import datetime
import functools
import http.server
import json
import mimetypes
import os
from pathlib import Path
import re
import secrets
import shutil
import socket
import ssl
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import anixart_network
import network_settings
import site_bridges
import shared_sources
from source_hub import SourceHub
import webbrowser
from accounts import Accounts
import video_providers as vp
from unified_sync import UnifiedSync

BASE = Path(__file__).resolve().parent.parent
RENDERER = BASE / 'renderer'
RUNTIME = BASE / 'runtime'
VERSION = '0.5.15'
SOURCES = [
 {'id':'all','name':'Все источники · единый каталог','kind':'video','description':'Anixart, AniLiberty, Mikai, Yani, Kodik, AniList, Shikimori, Jikan и импортированные сайты — параллельно. Состояние каждого отдельно.'},
 {'id':'both','name':'Anixart + AniLiberty','kind':'video','description':'Единый каталог, поиск и выбор серий обеих платформ. Похожие названия требуют проверки.'},
 {'id':'libria','name':'AniLiberty / AniLibria','kind':'video','description':'Релизы с эпизодами и HLS-видео, если доступны в регионе.'},
 {'id':'anixart','name':'Anixart (каталог + эпизоды)','kind':'embedded','description':'Поиск по названию и ID, озвучки и эпизоды. Ограниченные релизы показываются с меткой, без обхода видеоблокировок.'},
 {'id':'anilist','name':'AniList','kind':'catalog','description':'Рейтинги и описание; видео не предоставляется.'},
 {'id':'shiki','name':'Shikimori','kind':'catalog','description':'Русскоязычные метаданные; видео не предоставляется.'},
 {'id':'jikan','name':'Jikan / MyAnimeList','kind':'catalog','description':'Информация о тайтлах; видео не предоставляется.'},
 {'id':'yani','name':'YummyAnime / Yani','kind':'embedded','description':'Поиск и видео через Yani API. Требуется личный X-Application токен; iframe зависит от поставщика.'},
 {'id':'mikai','name':'Mikai — украинское аниме','kind':'embedded','description':'Публичный каталог, озвучки и видео по провайдерам; ключ не нужен. Источник: mikai.me.'},
 {'id':'sites','name':'Страницы сайтов · SovetRomantica / AnimeVost / SHIZA-Project','kind':'embedded','description':'Импорт публичной HTTPS-страницы по ссылке, без API-ключа, скрытого браузера и доступа к вашим cookies.'},
 {'id':'kodik','name':'Kodik (ваш токен)','kind':'embedded','description':'Плеер платформы по личному токену; условия доступа задаёт Kodik.'},
]
BASES = ['https://anilibria.top/api/v1','https://api.anilibria.app/api/v1','https://aniliberty.top/api/v1']
DEFAULT_STATE = dict(cacheVideo=True,theme='dark',source='all',bookmarks=[],history=[],volume=.8,quality='1080',upscale=dict(enabled=False,mode='balanced',scale=1.5,strength=.45))
ALLOWED_ID = re.compile(r'^(libria|anixart|anilist|shiki|jikan|kodik|yani|mikai|sites):[A-Za-z0-9_-]{1,100}$')

ANIXART_RELEASE_HOSTS = frozenset({'anixart-app.com','www.anixart-app.com','mirror.anixart-app.com','anixart.app','www.anixart.app','anixart.tv','www.anixart.tv'})
def parse_anixart_release_url(value):
 """Resolve an Anixart release URL to a numeric identifier, without fetching external HTML."""
 if not isinstance(value,str) or len(value)>2048:return None
 if m:=re.fullmatch(r'(?:anixart:)?([1-9][0-9]{0,11})',value.strip(),re.I):return m[1]
 try:
  u=urllib.parse.urlsplit(value.strip())
  if u.scheme!='https' or u.hostname not in ANIXART_RELEASE_HOSTS or u.username or u.password or u.port is not None:return None
  m=re.fullmatch(r'/release/([1-9][0-9]{0,11})/?',u.path,re.I)
  return m[1] if m else None
 except ValueError:return None

def as_list(v):
 if isinstance(v,list):return v
 if isinstance(v,dict):
  for k in ('data','releases','results','list','content','items','animes'):
   if k in v:
    arr=as_list(v[k])
    if arr:return arr
 return []

def absolute(src,base):
 if not isinstance(src,str) or not src:return ''
 u=urllib.parse.urljoin(base,src)
 return u if urllib.parse.urlparse(u).scheme=='https' else ''

def first_str(*values):
 for v in values:
  if isinstance(v,str) and v.strip():return v.strip()
 return ''

def normalize(item,source,base='https://anilibria.top'):
 if source=='mikai':return vp.mikai_item(item)
 if not isinstance(item,dict):return None
 if source=='libria':
  key=item.get('id'); name=item.get('name') or {}; poster=item.get('poster') or {}; typ=item.get('type') or {}
  if key is None:return None
  if not isinstance(name,dict):name={'main':name}
  if not isinstance(poster,dict):poster={'src':poster}
  return dict(id=f'libria:{key}',remoteId=str(key),source=source,name=first_str(name.get('main'),name.get('english'),item.get('title')) or f'Релиз {key}',original=first_str(name.get('english')),image=absolute((poster.get('optimized') or {}).get('preview') or poster.get('src') or poster.get('preview'),base),description=first_str(item.get('description')),year=item.get('year') or '',rating=(item.get('rating') or {}).get('average') if isinstance(item.get('rating'),dict) else None,episodesTotal=item.get('episodes_total'),category=typ.get('description','Аниме') if isinstance(typ,dict) else 'Аниме',playable=True,blocked=bool(item.get('is_blocked_by_geo') or item.get('is_blocked_by_copyrights')),url=f'https://anilibria.top/anime/releases/{key}')
 if source=='shiki':
  key=item.get('id')
  if key is None:return None
  im=item.get('image') or {};im=im if isinstance(im,dict) else {}
  return dict(id=f'shiki:{key}',remoteId=str(key),source=source,name=first_str(item.get('russian'),item.get('name')),original=first_str(item.get('name')),image=absolute(im.get('original') or im.get('preview'),'https://shikimori.one'),description=first_str(item.get('description')),year=(item.get('aired_on') or '')[:4],rating=item.get('score'),episodesTotal=item.get('episodes'),category=item.get('kind') or 'Аниме',playable=False,blocked=False,url=f'https://shikimori.one/animes/{key}')
 if source=='jikan':
  key=item.get('mal_id')
  if key is None:return None
  im=item.get('images') or {}; im=im.get('webp') or im.get('jpg') or {}
  return dict(id=f'jikan:{key}',remoteId=str(key),source=source,name=first_str(item.get('title_english'),item.get('title')),original=first_str(item.get('title')),image=absolute(im.get('large_image_url') or im.get('image_url'),'https://myanimelist.net'),description=first_str(item.get('synopsis')),year=item.get('year') or '',rating=item.get('score'),episodesTotal=item.get('episodes'),category=item.get('type') or 'Аниме',playable=False,blocked=False,url=absolute(item.get('url'),'https://myanimelist.net'))
 if source=='anilist':
  key=item.get('id');title=item.get('title') or {};im=item.get('coverImage') or {}
  if key is None:return None
  return dict(id=f'anilist:{key}',remoteId=str(key),source=source,name=first_str(title.get('english'),title.get('romaji'),title.get('native')),original=first_str(title.get('romaji')),image=absolute(im.get('extraLarge') or im.get('large'),'https://anilist.co'),description=re.sub(r'<[^>]*>','',first_str(item.get('description'))),year=item.get('seasonYear') or '',rating=(float(item['averageScore'])/10 if item.get('averageScore') else None),episodesTotal=item.get('episodes'),category=item.get('format') or 'Аниме',playable=False,blocked=False,url=absolute(item.get('siteUrl'),'https://anilist.co'))
 if source=='anixart':
  key=item.get('id')
  if key is None:return None
  blocked = bool(item.get('is_view_blocked') or item.get('is_ru_blocked') or item.get('is_play_disabled'))
  return dict(id=f'anixart:{key}',remoteId=str(key),source=source,name=first_str(item.get('title_ru'),item.get('title'),item.get('title_original')),original=first_str(item.get('title_original'),item.get('title_alt')),image=absolute(item.get('image'),'https://anixart.app'),description=first_str(item.get('description')),year=item.get('year') or '',rating=item.get('grade'),episodesTotal=item.get('episodes_released'),category='Аниме',playable=not blocked,blocked=blocked,hiddenByProvider=bool(item.get('is_view_blocked')),accessNote=('Ограничение сервиса: доступ к воспроизведению не предоставлен' if blocked else ''),url=f'https://anixart-app.com/release/{key}')
 if source=='yani':
  key=item.get('anime_id')
  if key is None:return None
  poster=item.get('poster') or {}
  if not isinstance(poster,dict):poster={}
  rating=item.get('rating') or {};rating=rating if isinstance(rating,dict) else {}
  episodes=item.get('episodes') or {};episodes=episodes if isinstance(episodes,dict) else {}
  return dict(id=f'yani:{key}',remoteId=str(key),source=source,name=first_str(item.get('title')),original=first_str(item.get('original')),image=absolute(poster.get('big') or poster.get('medium') or poster.get('huge'),'https://yummyani.me'),description=first_str(item.get('description')),year=item.get('year') or '',rating=rating.get('average'),episodesTotal=episodes.get('count'),category='Аниме',playable=True,blocked=False,url='https://yummyani.me/catalog/item/'+str(item.get('anime_url') or key))
 if source=='kodik':
  key=item.get('id');link=item.get('link') or '';u=urllib.parse.urlparse(link if not link.startswith('//') else 'https:'+link)
  if not isinstance(key,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,100}',key):return None
  embed=u.geturl() if u.scheme=='https' and (u.hostname in ('kodik.info','kodikplayer.com') or (u.hostname or '').endswith(('.kodik.info','.kodikplayer.com'))) else ''
  return dict(id=f'kodik:{key}',remoteId=key,source=source,name=first_str(item.get('title'),item.get('title_orig')),original=first_str(item.get('title_orig')),image='',description='Видео из каталога Kodik.',year=item.get('year') or '',rating=None,episodesTotal=None,category=item.get('type') or 'Видео',playable=bool(embed),blocked=False,embed=embed,url=embed)
 return None

def episodes_libria(release,base):
 res=[]
 for i,ep in enumerate(release.get('episodes') or []):
  if not isinstance(ep,dict):continue
  qualities={}
  for q in ('1080','720','480'):
   link=ep.get('hls_'+q) or (ep.get('hls') or {}).get(q)
   if isinstance(link,dict):link=link.get('src') or link.get('url')
   src=absolute(link,base)
   if src:qualities[q]=src
  if qualities:res.append(dict(id=str(ep.get('id') or i+1),ordinal=ep.get('ordinal',i+1),name=first_str(ep.get('name'),ep.get('title')) or f'Эпизод {i+1}',quality=qualities,duration=float(ep.get('duration') or ((release.get('average_duration_of_episode') or 0)*60))))
 return res

def fetch_json(url,method='GET',data=None,timeout=7,headers=None):
 if urllib.parse.urlsplit(url).hostname in ('api.anixsekai.com','api-s.anixsekai.com'):
  return anixart_network.request_json(url,method=method,data=data,timeout=timeout,headers=headers)
 parsed=urllib.parse.urlparse(url)
 if parsed.scheme!='https':raise ValueError('Требуется HTTPS для API')
 body=json.dumps(data).encode() if data is not None else None
 request=urllib.request.Request(url,body,headers={**({'Accept':'application/json','User-Agent':'AniSpawn/0.5.13 desktop','Content-Type':'application/json'} if body else {'Accept':'application/json','User-Agent':'AniSpawn/0.5.13 desktop'}),**(headers or {})},method=method)
 try:
  with network_settings.open_url(request,timeout=timeout) as response:
   if response.status>=400:raise RuntimeError(f'HTTP {response.status}')
   result=json.loads(response.read(6_000_000))
 except urllib.error.HTTPError as error:
  raise RuntimeError('Сервис ответил HTTP '+str(error.code)) from None
 except (urllib.error.URLError,TimeoutError,ssl.SSLError,OSError):
  raise RuntimeError('Не удалось установить защищённое соединение с '+str(parsed.hostname or 'API')+'. Проверьте кэш или другой источник.') from None
 if isinstance(result,dict) and result.get('errors'):raise RuntimeError('API: '+str(result['errors'][0])[:120])
 return result

class Backend:
 def __init__(self, user_dir=None):
  self.lock=threading.RLock();self.directory=Path(user_dir or os.getenv('XDG_CONFIG_HOME') or Path.home()/'.config')/'AniSpawn';self.directory.mkdir(parents=True,exist_ok=True);os.chmod(self.directory,0o700)
  self.state_file=self.directory/'state.json';self.state=copy.deepcopy(DEFAULT_STATE)
  try:self.state=self.clean_state(json.loads(self.state_file.read_text(encoding='utf-8')))
  except (OSError,ValueError,TypeError):pass
  self.accounts=Accounts(self.directory);self.base=BASES[0];self.cache={};self.valid_streams={};self.playbacks={};self.kodik_token='';self.kodik_cache={};self.player_links={};self.kinobox_last=0;self.kinobox_cache={};self.yani_token=self.accounts.yani_app_token
  self.cache_dir=Path(os.getenv('XDG_CACHE_HOME') or Path.home()/'.cache')/'AniSpawn';self.cache_dir.mkdir(parents=True,exist_ok=True)
  self.video_dir=self.cache_dir/'videos';self.video_dir.mkdir(parents=True,exist_ok=True)
  self.metadata_dir=self.cache_dir/'catalog';self.metadata_dir.mkdir(parents=True,exist_ok=True)
  self.site_file=self.directory/'site-imports.json';self.site_items={}
  try:
   saved=json.loads(self.site_file.read_text(encoding='utf-8'))
   for item in saved.get('pages',[])[:300]:
    if isinstance(item,dict) and re.fullmatch(r'sites:[0-9a-f]{32}',str(item.get('id',''))):
     try:
      if site_bridges.validate_page_url(item.get('url','')):
       self.site_items[item['id']]=site_bridges.import_page(item['url'],'<html></html>')|{k:item[k] for k in ('name','description','image') if k in item}|{'players':[v for v in item.get('players',[])[:20] if isinstance(v,dict) and site_bridges.allowed_embed(v.get('embed')) and site_bridges.allowed_embed(v.get('external'))]}
     except (ValueError,TypeError):pass
  except (OSError,ValueError,TypeError,AttributeError):pass
  self.history_txt=self.directory/'watch-history.txt';self.history_events=self.directory/'watch-events.txt'
  self.video_index_path=self.directory/'video-index.json'
  try:self.video_index=json.loads(self.video_index_path.read_text(encoding='utf-8'))
  except (OSError,ValueError,TypeError):self.video_index={}
  if not isinstance(self.video_index,dict):self.video_index={}
  self.download_jobs={};self.ffmpeg=str(RUNTIME/'ffmpeg'/'ffmpeg') if (RUNTIME/'ffmpeg'/'ffmpeg').exists() else shutil.which('ffmpeg')
  self._write_history_txt()
  self.unified=UnifiedSync(self)
  self.network=network_settings.NetworkManager(self.directory)
  self.source_hub=SourceHub(self)
  network_settings.set_active(self.network)
 def save_sites(self):
  # Imported pages contain only public metadata and approved URLs, never cookies.
  data={'format':1,'pages':list(self.site_items.values())[-300:]}
  f=self.site_file.with_suffix('.tmp');f.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');os.chmod(f,0o600);f.replace(self.site_file)
 def sites_catalog(self,page=1,query=''):
  q=str(query or '').strip().casefold()
  items=list(reversed(list(self.site_items.values())))
  if q:items=[x for x in items if q in str(x.get('name','')).casefold() or q in str(x.get('description','')).casefold()]
  return [dict(x,players=[]) for x in items[(page-1)*24:page*24]]
 def import_site(self,url):
  page=site_bridges.validate_page_url(url)
  html=site_bridges.read_public_html(page,network_settings.open_url)
  result=site_bridges.import_page(page,html)
  with self.lock:
   if len(self.site_items)>=300 and result['id'] not in self.site_items:self.site_items.pop(next(iter(self.site_items)))
   self.site_items.pop(result['id'],None);self.site_items[result['id']]=result
   self.save_sites()
  return {**result,'players':self._register_players(result['players'])}
 def remove_site(self,item_id):
  if not isinstance(item_id,str) or not re.fullmatch(r'sites:[0-9a-f]{32}',item_id):raise ValueError('Неверный идентификатор страницы')
  with self.lock:
   found=self.site_items.pop(item_id,None) is not None
   if found:self.save_sites()
  return {'removed':found}
 def clean_state(self,s):
  v=copy.deepcopy(DEFAULT_STATE)
  if not isinstance(s,dict):return v
  if isinstance(s.get('cacheVideo'),bool):v['cacheVideo']=s['cacheVideo']
  if s.get('theme') in ('dark','light'):v['theme']=s['theme']
  if s.get('source') in [p['id'] for p in SOURCES]:v['source']=s['source']
  if s.get('quality') in ('480','720','1080'):v['quality']=s['quality']
  if isinstance(s.get('volume'),(int,float)) and math.isfinite(s['volume']):v['volume']=max(0,min(1,s['volume']))
  for k,lim in (('bookmarks',5000),('history',1000)):
   arr=s.get(k)
   if isinstance(arr,list):v[k]=[x for x in arr if isinstance(x,dict) and ALLOWED_ID.fullmatch(str(x.get('id','')))][-lim:]
  upscale=s.get('upscale') or {}
  if isinstance(upscale,dict):
   v['upscale']['enabled']=upscale.get('enabled') is True
   if upscale.get('mode') in ('fast','balanced','anime','soft'):v['upscale']['mode']=upscale['mode']
   if upscale.get('scale') in (1,1.5,2):v['upscale']['scale']=upscale['scale']
   if isinstance(upscale.get('strength'),(int,float)) and math.isfinite(upscale['strength']):v['upscale']['strength']=max(0,min(1,upscale['strength']))
  return v
 def _save(self):
  f=self.state_file.with_suffix('.tmp');f.write_text(json.dumps(self.state,ensure_ascii=False,indent=2),encoding='utf8');os.chmod(f,0o600);f.replace(self.state_file)
 def update(self,patch):
  if not isinstance(patch,dict):raise ValueError('Invalid settings')
  with self.lock:self.state=self.clean_state({**self.state,**patch});self._save();return copy.deepcopy(self.state)
 def bookmark(self,item):
  if not isinstance(item,dict) or not ALLOWED_ID.fullmatch(str(item.get('id',''))):raise ValueError('Неверная закладка')
  if item['id'].startswith(('anixart:','yani:')):
   current=next((x for x in self.state['bookmarks'] if x.get('id')==item['id']),None)
   status=None if current else (2 if item['id'].startswith('anixart:') else 1)
   result=self.unified.edit(item,status)
   return {'added':status is not None,**result}
  with self.lock:
   exists=any(x.get('id')==item['id'] for x in self.state['bookmarks'])
   self.state['bookmarks']=[x for x in self.state['bookmarks'] if x.get('id')!=item['id']]
   if not exists:self.state['bookmarks'].append({k:str(item.get(k,'') or '')[:(2000 if k=='image' else 200)] for k in ('id','name','image','source','year')})
   self._save();return dict(added=not exists,bookmarks=copy.deepcopy(self.state['bookmarks']))
 def set_list_status(self,item,status):
  if status is not None:status=int(status)
  return self.unified.edit(item,status)
 def account_login(self,provider,login,password):
  profile=self.accounts.login(provider,login,password)
  return profile
 def _write_history_txt(self):
  lines=['AniSpawn — история просмотров', 'Последнее обновление: '+datetime.datetime.now().astimezone().strftime('%Y-%m-%d %H:%M:%S'), '']
  for e in self.state['history']:
   position=e.get('position',0);duration=e.get('duration',0)
   position=position if isinstance(position,(int,float)) and math.isfinite(position) else 0
   duration=duration if isinstance(duration,(int,float)) and math.isfinite(duration) else 0
   lines.extend([f"{str(e.get('name') or e['id']).replace(chr(10),' ')} | Эпизод {e.get('episode','?')}",f"  Дата: {e.get('date','?')} | Прогресс: {position:.0f} / {duration:.0f} сек | Завершено: {'да' if e.get('completed') else 'нет'}",''])
  file=self.history_txt.with_suffix('.tmp');file.write_text('\n'.join(lines),encoding='utf-8');os.chmod(file,0o600);file.replace(self.history_txt)
 def history_info(self):
  return {'historyTxt':str(self.history_txt),'eventsTxt':str(self.history_events),'videoCache':str(self.video_dir),'videoCaching':self.state.get('cacheVideo',True)}
 def update_progress(self,entry):
  if not isinstance(entry,dict) or not ALLOWED_ID.fullmatch(str(entry.get('id',''))):raise ValueError('Bad playback position')
  seconds=entry.get('position',0);duration=entry.get('duration',0)
  if not all(isinstance(x,(int,float)) and math.isfinite(x) and 0<=x<=172800 for x in (seconds,duration)):raise ValueError('Bad time')
  with self.lock:
   for event in self.state['history']:
    if event['id']==entry['id'] and event.get('episode')==str(entry.get('episode','')):
     event.update(position=round(seconds,2),duration=round(duration,2),completed=seconds>0 and duration>0 and seconds>=duration-15)
     self._save();self._write_history_txt();return copy.deepcopy(event)
  return None
 def watched(self,entry):
  if not isinstance(entry,dict) or not ALLOWED_ID.fullmatch(str(entry.get('id',''))):raise ValueError('Неверная запись истории')
  with self.lock:
   self.state['history']=[{'id':entry['id'],'episode':str(entry.get('episode',''))[:80],'name':str(entry.get('name',''))[:180],'date':datetime.datetime.now(datetime.timezone.utc).isoformat(),'position':0.0,'duration':0.0,'completed':False},*[x for x in self.state['history'] if not (x['id']==entry['id'] and x.get('episode')==str(entry.get('episode','')))]][:1000]
   self._save();self._write_history_txt()
   # Append-only plain-text log: no user data is silently discarded when state.json reaches its 250-item limit.
   with self.history_events.open('a',encoding='utf-8') as out:out.write(f"{datetime.datetime.now().astimezone().isoformat()} | {entry['id']} | {str(entry.get('episode',''))[:80]} | {str(entry.get('name',''))[:180].replace(chr(10),' ')}\n")
   return copy.deepcopy(self.state['history'])
 def yani(self,path,params=None):
  if not self.yani_token:raise RuntimeError('Yani требует X-Application токен разработчика (yummyani.me/dev/applications)')
  url='https://api.yani.tv'+path+('?' + urllib.parse.urlencode(params) if params else '')
  response=fetch_json(url,headers={'X-Application':self.yani_token,'Lang':'ru'})
  if isinstance(response,dict) and 'error' in response:raise RuntimeError('Yani API: '+str(response.get('error'))[:150])
  return response.get('response',response) if isinstance(response,dict) else response
 def cache_key(self,url):return hashlib.sha256(url.encode('utf-8')).hexdigest()[:24]
 def cache_path(self,url):return self.video_dir/(self.cache_key(url)+'.mp4')
 def video_status(self,url):
  if not isinstance(url,str) or not url.startswith('https://'):raise ValueError('Invalid URL')
  with self.lock:
   if url not in self.valid_streams:raise ValueError('Not a verified stream')
   job=self.download_jobs.get(self.cache_key(url))
  path=self.cache_path(url)
  return {'status':'cached' if path.is_file() else ('downloading' if job and job.get('status')=='downloading' else 'error' if job and job.get('status')=='error' else 'not-cached'), 'size':path.stat().st_size if path.is_file() else 0,'error':job.get('error') if job else None}
 def cached_videos(self):
  with self.lock:return [{**record,'key':key,'size':(self.video_dir/(key+'.mp4')).stat().st_size} for key,record in self.video_index.items() if re.fullmatch('[a-f0-9]{24}',key) and (self.video_dir/(key+'.mp4')).is_file() and isinstance(record,dict)]
 def open_cached(self,key):
  if not isinstance(key,str) or not re.fullmatch('[a-f0-9]{24}',key):raise ValueError('Invalid cached video id')
  file=self.video_dir/(key+'.mp4')
  if not file.is_file() or key not in self.video_index:raise FileNotFoundError('Cached file was not found')
  token=secrets.token_hex(16)
  with self.lock:self.playbacks[token]=(str(file),time.time(),True)
  return token
 def _register_clip(self,url,details):
  if not isinstance(details,dict) or not ALLOWED_ID.fullmatch(str(details.get('id',''))):return
  info={'id':details['id'],'episode':str(details.get('episode',''))[:64],'name':str(details.get('name',''))[:160],'quality':str(details.get('quality',''))[:10],'date':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  with self.lock:
   self.video_index[self.cache_key(url)]=info
   dest=self.video_index_path.with_suffix('.tmp');dest.write_text(json.dumps(self.video_index,ensure_ascii=False,indent=2),encoding='utf-8');dest.replace(self.video_index_path)
 def queue_cache(self,url,details=None):
  if not isinstance(url,str) or not url.startswith('https://'):raise ValueError('Invalid URL')
  with self.lock:
   if url not in self.valid_streams:raise ValueError('Not a verified stream')
   key=self.cache_key(url)
   if self.cache_path(url).exists():self._register_clip(url,details);return self.video_status(url)
   if key in self.download_jobs and self.download_jobs[key]['status']=='downloading':return self.video_status(url)
   if not self.ffmpeg:raise RuntimeError('FFmpeg unavailable')
   self.download_jobs[key]={'status':'downloading'}
  def worker():
   dest=self.cache_path(url);tmp=dest.with_suffix('.part')
   try:
    # Allow up to 10 GiB of video cache; never start when too little disk remains.
    if shutil.disk_usage(self.video_dir).free<900*1024*1024:raise RuntimeError('Less than 900 MiB free')
    env=os.environ.copy()
    if (RUNTIME/'ffmpeg'/'lib').is_dir():env['LD_LIBRARY_PATH']=str(RUNTIME/'ffmpeg'/'lib')
    cmd=[self.ffmpeg,'-nostdin','-hide_banner','-loglevel','error','-rw_timeout','12000000',*self.network.ffmpeg_proxy_flags(),'-i',url,'-map','0:v:0','-map','0:a:0?','-c','copy','-bsf:a','aac_adtstoasc','-movflags','+faststart','-f','mp4','-y',str(tmp)]
    process=subprocess.run(cmd,capture_output=True,timeout=14400,env=env)
    if process.returncode or not tmp.exists() or tmp.stat().st_size<1024:raise RuntimeError(process.stderr.decode(errors='replace')[-250:] or 'Video download failed')
    if tmp.stat().st_size>10*1024**3:raise RuntimeError('Video exceeds cache limit')
    # Global 8 GiB budget: evict oldest finished videos, never partial downloads.
    finished=sorted((x for x in self.video_dir.glob('*.mp4') if x!=dest),key=lambda f:f.stat().st_mtime)
    used=sum(x.stat().st_size for x in finished)+tmp.stat().st_size
    budget=8*1024**3
    for old in finished:
     if used<=budget:break
     try:used-=old.stat().st_size;old.unlink()
     except OSError:pass
    if used>budget:raise RuntimeError('Video cache limit of 8 GiB reached')
    tmp.rename(dest)
    self._register_clip(url,details)
    with self.lock:self.download_jobs[key]={'status':'cached'}
   except Exception as error:
    with self.lock:self.download_jobs[key]={'status':'error','error':str(error)[:180]}
   finally:tmp.unlink(missing_ok=True)
  threading.Thread(target=worker,daemon=True,name='video-cache-'+key).start()
  return self.video_status(url)
 def libria(self,route):
  errs=[]
  for base in [self.base]+[b for b in BASES if b!=self.base]:
   try:
    d=fetch_json(base+route,timeout=4);self.base=base;return d,base
   except Exception as e:errs.append(str(e))
  raise RuntimeError('AniLiberty недоступна: '+', '.join(errs)[:190])
 def kodik(self,route,params=None):
  if not self.kodik_token:raise RuntimeError('Введите Kodik-токен в настройках')
  query=urllib.parse.urlencode({'token':self.kodik_token,**(params or {})});return fetch_json('https://kodik-api.com/'+route+'?'+query)
 def anime_graphql(self,query,variables):return fetch_json('https://graphql.anilist.co','POST',{'query':query,'variables':variables}).get('data') or {}
 def combined_catalog(self,page=1,query=''):
  """Load each provider independently; one outage cannot blank the other.

  Each provider has its own persistent cache. No remote auth or media URLs are
  merged, and a result's id still identifies the actual service.
  """
  page=max(1,min(100,int(page)));query=str(query or '').strip()[:120]
  def load_one(src):
   key=('search:'+src+':'+str(page)+':'+query) if query else ('list:'+src+':'+str(page))
   return self._cached(key,lambda:self.catalog(src,page,query))
  results={};failures={}
  with concurrent.futures.ThreadPoolExecutor(max_workers=2,thread_name_prefix='catalog') as pool:
   futures={pool.submit(load_one,src):src for src in ('anixart','libria')}
   for future,src in futures.items():
    try:results[src]=future.result()
    except Exception as err:failures[src]=str(err)[:160]
  if not results:raise RuntimeError('Оба каталога недоступны: '+'; '.join(f'{k}: {v}' for k,v in failures.items()))
  items=shared_sources.group_catalog(results.get('anixart',{}).get('items',[]),results.get('libria',{}).get('items',[]))
  if page==1:items.extend(self.sites_catalog(1,query))
  warnings=[f'{src}: {msg}' for src,msg in failures.items()]
  warnings.extend(f'{src}: показан кэш' for src,obj in results.items() if obj.get('stale'))
  # A healthy second provider must remain visible even when the first is offline.
  return {'items':items,'stale':bool(warnings),'warning':' · '.join(warnings)[:300],
          'providers':{src:('offline' if src in failures else 'cached' if results[src].get('stale') else 'online') for src in ('anixart','libria')}}

 def related_sources(self,item_id,name,original='',year=''):
  """Find opt-in alternatives: exact match != permission to autoplay."""
  if not isinstance(item_id,str) or not re.fullmatch(r'(?:anixart|libria):[A-Za-z0-9_-]{1,100}',item_id):
   raise ValueError('Недопустимый идентификатор релиза')
  if not isinstance(name,str) or not 2<=len(name.strip())<=180:
   raise ValueError('Нужно название релиза')
  if not isinstance(original,str) or len(original)>180:raise ValueError('Неверное исходное название')
  year=str(year or '')[:4]
  source=item_id.split(':',1)[0];other='libria' if source=='anixart' else 'anixart'
  anchor={'id':item_id,'source':source,'name':name,'original':original,'year':year}
  found={};warnings=[]
  for q in dict.fromkeys([name.strip(),original.strip()]):
   if not q or len(q)<2:continue
   key=f'cross:{other}:{q.casefold()}'
   try:
    response=self._cached(key,lambda:self.catalog(other,1,q))
    for item in response['items']:
     if isinstance(item,dict) and item.get('id'):found[item['id']]=item
    if response.get('stale'):warnings.append('Использован сохранённый поиск '+other)
   except Exception as err:warnings.append(other+': '+str(err)[:100])
   if any(shared_sources.compare(anchor,item)=='exact' for item in found.values()):break
  return {'items':shared_sources.suggestions(anchor,found.values()),'warning':' · '.join(warnings)[:240],
          'stale':bool(warnings)}

 def catalog(self,source,page=1,query=''):
  if source not in [x['id'] for x in SOURCES]:raise ValueError('Источник неизвестен')
  page=max(1,min(100,int(page)));query=str(query or '').strip()[:120]
  if source=='both':return self.combined_catalog(page,query)['items']
  if source=='all':return self.source_hub.combined(page,query)['items']
  if source=='sites':return self.sites_catalog(page,query)
  if source=='mikai':
   params={'page':page,'limit':24,'search':query} if query else {'page':page,'limit':24,'sort':'updated','order':'desc'}
   raw=fetch_json(vp.MIKAI_BASE+'/anime?'+urllib.parse.urlencode(params),headers={'User-Agent':'AniSpawn/0.5.5 (+https://github.com/Ehynia/KoraLo)'})
   if not isinstance(raw,dict) or raw.get('ok') is not True:raise RuntimeError('Mikai: неверный ответ API')
   return [v for r in (raw.get('result') or []) if (v:=normalize(r,'mikai'))]
  if source=='libria':
   path='/app/search/releases?'+urllib.parse.urlencode({'query':query,'limit':30}) if query else ('/anime/releases/latest?limit=30' if page==1 else '/anime/catalog/releases?'+urllib.parse.urlencode({'limit':30,'page':page}))
   raw,base=self.libria(path);return [v for r in as_list(raw) if (v:=normalize(r,source,base))]
  if source=='shiki':
   path='/api/animes?'+urllib.parse.urlencode({'search':query,'limit':24} if query else {'order':'ranked','limit':24,'page':page})
   raw=fetch_json('https://shikimori.one'+path)
  elif source=='jikan':
   path='/v4/anime?'+urllib.parse.urlencode({'q':query,'limit':24}) if query else '/v4/top/anime?'+urllib.parse.urlencode({'page':page,'limit':24})
   raw=fetch_json('https://api.jikan.moe'+path)
  elif source=='anilist':
   extra='search:$search' if query else 'sort:TRENDING_DESC'
   g=f'query($page:Int,$search:String){{Page(page:$page,perPage:24){{media(type:ANIME,{extra}){{id title{{romaji english native}} coverImage{{large extraLarge}} description(asHtml:false) seasonYear episodes averageScore format siteUrl}}}}}}'
   raw=self.anime_graphql(g,{'page':page,'search':query or None}).get('Page',{}).get('media',[])
  elif source=='anixart':
   # AnixartJS documents POST /search/releases/{page} (API-Version: v2)
   # and POST /filter/{page}; both are 0-based. No unofficial unlocking or device spoofing.
   with self.accounts.lock:
    session=self.accounts.sessions.get('anixart')
    token=session.get('token') if isinstance(session,dict) else None
   if query and re.fullmatch(r'(?:anixart:)?[0-9]{1,12}',query,re.I):
    rid=query.split(':')[-1]
    data=self._anixart('/release/'+rid)
    release=data.get('release') if isinstance(data.get('release'),dict) else data
    item=normalize(release,'anixart')
    if not item:return []
    return [item]
   if query:
    endpoint='/search/releases/'+str(page-1)
    payload={'query':query,'searchBy':0}
    headers={'API-Version':'v2'}
   else:
    endpoint='/filter/'+str(page-1)
    payload={}
    headers={}
   url=vp.ANIXART_BASE+endpoint
   if token:url+='?'+urllib.parse.urlencode({'token':token})
   raw=fetch_json(url,'POST',payload,headers=headers)
   if isinstance(raw,dict) and raw.get('code',0)!=0:raise RuntimeError('Anixart: ошибка поиска '+str(raw['code']))
   results=[v for r in as_list(raw) if (v:=normalize(r,'anixart'))]
   # Authenticated bookmarks may include metadata hidden from normal search results.
   # Keep those records visible in AniSpawn without claiming blocked video is playable.
   if query and page==1:
    q=query.casefold()
    known=[dict(item) for item in self.state['bookmarks']
           if isinstance(item,dict) and item.get('id','').startswith('anixart:')
           and (q in str(item.get('name','')).casefold() or q in str(item.get('original','')).casefold())]
    existing={r['id'] for r in results}
    results.extend(item for item in known if item.get('id') not in existing)
   return results
  elif source=='yani':
   raw=self.yani('/search',{'q':query,'limit':24,'offset':(page-1)*24}) if query else self.yani('/anime',{'limit':24,'offset':(page-1)*24})
  else:
   raw=self.kodik('search',{'title':query,'limit':24}) if query else self.kodik('list',{'limit':30})
  results=[v for r in as_list(raw) if (v:=normalize(r,source))]
  if source=='kodik':self.kodik_cache.update((r['remoteId'],r) for r in results)
  return results
 def details(self,item_id):
  if not ALLOWED_ID.fullmatch(str(item_id)):raise ValueError('ID релиза не принят')
  source,key=item_id.split(':',1)
  if source=='sites':
   with self.lock:item=copy.deepcopy(self.site_items.get(item_id))
   if not item:raise ValueError('Страница не импортирована или удалена')
   return {**item,'players':self._register_players(item.get('players',[])),'episodes':[]}
  if source=='libria':
   raw,base=self.libria('/anime/releases/'+urllib.parse.quote(key));release=raw.get('release') or raw.get('data') or raw
   v=normalize(release,source,base)
   if not v:raise ValueError('Релиз не найден')
   episodes=[] if v['blocked'] else episodes_libria(release,base)
   now=time.time()
   with self.lock:
    self.valid_streams={u:t for u,t in self.valid_streams.items() if now-t<3600}
    for ep in episodes:
     for url in ep['quality'].values():self.valid_streams[url]=now
   return {**v,'episodes':episodes}
  if source=='mikai':
   raw=fetch_json(vp.MIKAI_BASE+'/anime/'+urllib.parse.quote(key,safe=''),headers={'User-Agent':'AniSpawn/0.5.5 (+https://github.com/Ehynia/KoraLo)'})
   if not isinstance(raw,dict) or raw.get('ok') is not True:raise RuntimeError('Mikai: неверный ответ карточки')
   item=normalize(raw.get('result') or {},'mikai')
   if not item:raise ValueError('Mikai: запись не найдена')
   data=fetch_json(vp.MIKAI_BASE+'/anime/'+urllib.parse.quote(key,safe='')+'/player',headers={'User-Agent':'AniSpawn/0.5.5 (+https://github.com/Ehynia/KoraLo)'})
   if not isinstance(data,dict) or data.get('ok') is not True:raise RuntimeError('Mikai: неверный ответ плеера')
   players,licensed,licensor=vp.mikai_players(data)
   item['blocked']=item['blocked'] or licensed
   return {**item,'players':self._register_players(players),'episodes':[], 'credits':'Mikai · mikai.me · данные команд озвучки','licenseNotice':('Контент лицензирован'+(' · '+licensor if licensor else '') if licensed else '')}
  if source=='yani':
   raw=self.yani('/anime/'+urllib.parse.quote(key),{'need_videos':1})
   item=normalize(raw,'yani')
   if not item:raise ValueError('Yani returned invalid anime')
   videos=raw.get('videos') if isinstance(raw,dict) else []
   if not isinstance(videos,list):videos=[]
   # iframe fields are documented by YummyAPI, validate each URL before passing to the client.
   embeds=[]
   for v in videos:
    if not isinstance(v,dict):continue
    url=v.get('iframe_url','');data=v.get('data') or {}
    if not isinstance(data,dict):data={}
    if safe_embed(url):embeds.append({'name':first_str(data.get('dubbing'),data.get('player')) or 'Плеер','episode':str(v.get('number') or v.get('index') or '?')[:32],'embed':url})
   return {**item,'players':embeds,'episodes':[]}
  if source=='kodik':
   item=self.kodik_cache.get(key)
   if not item:raise ValueError('Сначала выберите Kodik-запись из каталога')
   return {**item,'episodes':[]}
  if source=='shiki':raw=fetch_json('https://shikimori.one/api/animes/'+key)
  elif source=='jikan':raw=fetch_json('https://api.jikan.moe/v4/anime/'+key+'/full');raw=raw.get('data')
  elif source=='anilist':
   q='query($id:Int){Media(id:$id,type:ANIME){id title{romaji english native} coverImage{large extraLarge} description(asHtml:false) seasonYear episodes averageScore format siteUrl}}'
   raw=self.anime_graphql(q,{'id':int(key)}).get('Media')
  else:
   # Cached public metadata is usable when both Anixart API hosts time out.
   try:
    raw=self._anixart('/release/'+key)
   except anixart_network.ApiUnavailable as error:
    return self._offline_anixart_detail(key,error)
   if isinstance(raw,dict) and isinstance(raw.get('release'),dict):raw=raw['release']
  item=normalize(raw,source)
  if not item:raise ValueError('Запись не найдена')
  if source=='anixart':
   # Cache only public fields, never auth tokens, streams or signed player URLs.
   self._save_anixart_detail(key,item)
   if item.get('blocked'):
    return {**item,'blocked':True,'episodes':[],'dubs':[]}
   try:
    dubs=vp.anixart_dubs(self._anixart('/episode/'+key))
   except Exception as ex:
    return {**item,'episodes':[],'dubs':[],'playersError':str(ex)[:180]}
   return {**item,'episodes':[],'dubs':dubs}
  return {**item,'episodes':[]}
 def _anixart_detail_file(self,key):
  if not re.fullmatch(r'[0-9]{1,12}',str(key)):raise ValueError('Недопустимый ID')
  return self.metadata_dir/('anixart-detail-'+str(key)+'.json')
 def _save_anixart_detail(self,key,item):
  public=('id','remoteId','source','name','original','image','description','year','rating','episodesTotal','category','playable','blocked','hiddenByProvider','accessNote','url')
  record={k:item[k] for k in public if k in item}
  try:
   path=self._anixart_detail_file(key);tmp=path.with_suffix('.tmp')
   with tmp.open('w',encoding='utf8') as f:json.dump(record,f,ensure_ascii=False)
   tmp.chmod(0o600);tmp.replace(path)
  except OSError:pass
 def _offline_anixart_detail(self,key,error):
  try:
   obj=json.loads(self._anixart_detail_file(key).read_text(encoding='utf8'))
   if not isinstance(obj,dict) or obj.get('id')!='anixart:'+key:obj=None
  except (OSError,ValueError,TypeError):obj=None
  if obj is None:
   obj=next((copy.deepcopy(x) for x in self.state['bookmarks'] if isinstance(x,dict) and x.get('id')=='anixart:'+key),None)
  if obj is None:
   obj={'id':'anixart:'+key,'remoteId':key,'source':'anixart','name':'Релиз Anixart №'+key,'image':'','description':'Данные релиза ещё не сохранены на этом устройстве.','blocked':False,'placeholder':True}
  # Do not claim streams are playable or known while the provider is unreachable.
  return {**obj,'source':'anixart','stale':True,'episodes':[],'dubs':[],
          'playersError':'Офлайн: Anixart временно недоступен. Показана сохранённая информация; серии загрузятся после восстановления связи.'}
 def _anixart(self,path):
  with self.accounts.lock:session=self.accounts.sessions.get('anixart')
  token=session.get('token') if isinstance(session,dict) else None
  url=vp.ANIXART_BASE+path
  if token:url+='?'+urllib.parse.urlencode({'token':token})
  raw=fetch_json(url,timeout=7)
  if not isinstance(raw,dict):raise RuntimeError('Anixart: неверный формат')
  if raw.get('code',0)!=0:raise RuntimeError('Anixart: ошибка '+str(raw['code']))
  return raw
 def anixart_sources(self,item_id,dubber_id):
  if not isinstance(item_id,str) or not re.fullmatch(r'anixart:[0-9]{1,12}',item_id):raise ValueError('Неверный ID Anixart')
  dubber_id=int(dubber_id)
  if not 0<=dubber_id<=100000000:raise ValueError('Неверный ID озвучки')
  rid=item_id.partition(':')[2]
  return vp.anixart_sources(self._anixart('/episode/'+rid+'/'+str(dubber_id)))
 def anixart_episodes(self,item_id,dubber_id,source_id):
  if not isinstance(item_id,str) or not re.fullmatch(r'anixart:[0-9]{1,12}',item_id):raise ValueError('Неверный ID Anixart')
  dubber_id=int(dubber_id);source_id=int(source_id)
  if not(0<=dubber_id<=100000000 and 0<=source_id<=100000000):raise ValueError('Неверный ID источника')
  rid=item_id.partition(':')[2]
  return self._register_players(vp.anixart_episodes(self._anixart('/episode/'+rid+'/'+str(dubber_id)+'/'+str(source_id))))
 def _register_players(self,players):
  now=time.time();result=[]
  with self.lock:
   self.player_links={k:v for k,v in self.player_links.items() if now-v[1]<1200}
   for item in players:
    link=item.get('external')
    if not vp.external_url(link):continue
    token=secrets.token_hex(16);self.player_links[token]=(link,now)
    result.append({k:v for k,v in item.items() if k!='external'}|{'linkToken':token})
  return result
 def find_players(self,title):
  if not isinstance(title,str) or not 2<=len(title.strip())<=120:raise ValueError('Название от 2 до 120 символов')
  key=title.strip().casefold();now=time.monotonic()
  with self.lock:
   old=self.kinobox_cache.get(key)
   if old and now-old[1]<300:return self._register_players(old[0])
   if now-self.kinobox_last<.6:raise RuntimeError('Kinobox: не чаще двух запросов в секунду')
   self.kinobox_last=now
  data=fetch_json(vp.KINObOX_BASE+'?'+urllib.parse.urlencode({'title':title.strip()}),timeout=8)
  players=vp.kinobox_players(data)
  with self.lock:self.kinobox_cache[key]=(players,time.monotonic())
  return self._register_players(players)
 def open_player(self,token):
  if not isinstance(token,str):raise ValueError('Неверная ссылка')
  with self.lock:entry=self.player_links.get(token)
  if not entry or time.time()-entry[1]>1200:raise ValueError('Ссылка устарела — откройте карточку заново')
  if not vp.external_url(entry[0]):raise ValueError('Недопустимый адрес')
  if not webbrowser.open(entry[0]):raise RuntimeError('Не удалось открыть внешний браузер')
  return True
 def prepare(self,url):
  if not isinstance(url,str) or not url.startswith('https://'):raise ValueError('Неверный поток')
  with self.lock:
   ts=self.valid_streams.get(url)
   if ts is None or time.time()-ts>3600:raise ValueError('Ссылка на видео не подтверждена API')
   token=secrets.token_hex(16);self.playbacks[token]=(url,time.time())
  return token
 def call(self,method,args):
  source=args[0] if args else 'libria'
  if method=='sources':return SOURCES
  if method=='sourceStatus':return self.source_hub.snapshot()
  if method=='refreshSourceStatus':return self.source_hub.refresh()
  if method=='importSite':return self.import_site(args[0])
  if method=='removeSite':return self.remove_site(args[0])
  if method=='findPlayers':return self.find_players(args[0])
  if method=='relatedSources':return self.related_sources(args[0],args[1],args[2] if len(args)>2 else '',args[3] if len(args)>3 else '')
  if method=='openPlayer':return self.open_player(args[0])
  if method=='anixartSources':return self.anixart_sources(args[0],args[1])
  if method=='anixartEpisodes':return self.anixart_episodes(args[0],args[1],args[2])
  if method=='accountProviders':return self.accounts.providers()
  if method=='accountLogin':return self.account_login(args[0],args[1],args[2])
  if method=='accountLogout':return self.accounts.logout(args[0])
  if method=='accountLibrary':return self.accounts.library(args[0])
  if method=='syncAll':return self.unified.sync()
  if method=='syncStatus':return {'pending':len(self.unified.pending),'bookmarks':len(self.state['bookmarks']),'history':len(self.state['history'])}
  if method=='setListStatus':return self.set_list_status(args[0],args[1])
  if method=='accountLibraryPath':return str(self.accounts.txt_file)
  if method=='networkStatus':return self.network.status()
  if method=='networkConfigure':return self.network.configure(args[0])
  if method=='networkBenchmark':return self.network.benchmark()
  if method=='anixartDiagnose':return anixart_network.diagnose()
  if method=='getState':return copy.deepcopy(self.state)
  if method=='updateState':return self.update(args[0])
  if method=='toggleBookmark':return self.bookmark(args[0])
  if method=='recordWatch':return self.watched(args[0])
  if method=='recordProgress':return self.update_progress(args[0])
  if method=='historyInfo':return self.history_info()
  if method=='cacheStatus':return self.video_status(args[0])
  if method=='cacheVideo':return self.queue_cache(args[0],args[1] if len(args)>1 else None)
  if method=='cachedVideos':return self.cached_videos()
  if method=='openCached':return self.open_cached(args[0])
  if method=='list':
   page=int(args[1]) if len(args)>1 else 1
   if source=='sites':return {'items':self.sites_catalog(page),'stale':False}
   if source=='both':return self.combined_catalog(page)
   if source=='all':return self.source_hub.combined(page)
   return self._cached(f'list:{source}:{page}',lambda:self.catalog(source,page))
  if method=='search':
   query=args[1] if len(args)>1 else ''
   page=max(1,min(100,int(args[2]))) if len(args)>2 else 1
   if source=='sites':return {'items':self.sites_catalog(page,query),'stale':False}
   if source=='both':return self.combined_catalog(page,query)
   if source=='all':return self.source_hub.combined(page,query)
   return self._cached(f'search:{source}:{page}:{query}',lambda:self.catalog(source,page,query))
  if method=='details':return self.details(args[0])
  if method=='health' and source=='all':return self.source_hub.snapshot()
  if method=='health' and source=='sites':return {'ok':True,'ms':0,'local':True}
  if method=='health':
   t=time.monotonic()
   try:self.catalog(source,1);return {'ok':True,'ms':round((time.monotonic()-t)*1000)}
   except Exception as ex:return {'ok':False,'ms':round((time.monotonic()-t)*1000),'error':str(ex)[:200]}
  if method=='configureYani':
   token=args[0]
   if not isinstance(token,str) or not re.fullmatch(r'[A-Za-z0-9_.-]{0,512}',token):raise ValueError('Неверный токен Yani')
   self.yani_token=token;return {'configured':bool(token)}
  if method=='configureKodik':
   token=args[0]
   if not isinstance(token,str) or not re.fullmatch('[A-Za-z0-9_-]{0,512}',token):raise ValueError('Недопустимый токен')
   self.kodik_token=token;return {'configured':bool(token)}
  if method=='prepareStream':return self.prepare(args[0])
  if method=='openExternal':
   url=str(args[0]);u=urllib.parse.urlparse(url)
   if parse_anixart_release_url(url):raise ValueError('Релиз Anixart открывается внутри AniSpawn, а не в браузере')
   allowed=('anilibria.top','aniliberty.top','anilibria.app','anixart.app','anilist.co','shikimori.one','myanimelist.net','kodik.info','kodikplayer.com','mikai.me')
   if u.scheme!='https' or not any(u.hostname==h or (u.hostname or '').endswith('.'+h) for h in allowed):raise ValueError('URL не разрешён')
   return webbrowser.open(url)
  raise ValueError('Неизвестный метод')
 def _cached(self,key,operation):
  file=self.metadata_dir/(hashlib.sha256(key.encode()).hexdigest()+'.json')
  try:
   result=operation()
   with self.lock:self.cache[key]=(result,time.time())
   try:
    tmp=file.with_suffix('.tmp');tmp.write_text(json.dumps({'created':time.time(),'data':result},ensure_ascii=False),encoding='utf-8');tmp.replace(file)
   except OSError:pass
   return {'items':result,'stale':False}
  except Exception as ex:
   with self.lock:cached=self.cache.get(key)
   if cached:return {'items':cached[0],'stale':True,'warning':str(ex)}
   try:
    old=json.loads(file.read_text(encoding='utf-8'))
    if isinstance(old.get('data'),list):return {'items':old['data'],'stale':True,'warning':str(ex)}
   except (OSError,ValueError,TypeError):pass
   raise

def safe_embed(url):
 if not isinstance(url,str):return False
 try:
  u=urllib.parse.urlparse(url)
  allowed=('kodik.info','kodikplayer.com','video.sibnet.ru','sovetromantica.com','animevost.org','shiza-project.com')
  return u.scheme=='https' and u.hostname and any(u.hostname==x or u.hostname.endswith('.'+x) for x in allowed)
 except ValueError:return False

class Server(http.server.ThreadingHTTPServer):
 daemon_threads=True;allow_reuse_address=False
 def __init__(self,addr,backend):
  super().__init__(addr,Handler)
  self.backend=backend;self.key=secrets.token_urlsafe(32);self.prefix='/app/'+self.key+'/'
  self.ffmpeg=str(RUNTIME/'ffmpeg'/'ffmpeg') if (RUNTIME/'ffmpeg'/'ffmpeg').exists() else shutil.which('ffmpeg')
  self.ffmpeg_lib=str(RUNTIME/'ffmpeg'/'lib')

class Handler(http.server.BaseHTTPRequestHandler):
 protocol_version='HTTP/1.1'
 def log_message(self,fmt,*args):pass
 def _reply(self,code,body,content_type='application/json; charset=utf-8'):
  self.send_response(code)
  self.send_header('Content-Type',content_type)
  self.send_header('Content-Length',str(len(body)))
  self.send_header('X-Content-Type-Options','nosniff')
  self.send_header('Cache-Control','no-store')
  self.send_header('Referrer-Policy','no-referrer')
  self.end_headers()
  self.wfile.write(body)
 def _bad(self,code,msg):self._reply(code,json.dumps({'error':msg},ensure_ascii=False).encode())
 def do_POST(self):
  if self.path!=self.server.prefix+'rpc':return self._bad(404,'Not found')
  if self.headers.get('Origin')!=f'http://127.0.0.1:{self.server.server_port}':return self._bad(403,'Origin rejected')
  if self.headers.get('Content-Type','').split(';')[0]!='application/json':return self._bad(415,'JSON only')
  length=int(self.headers.get('Content-Length','0') or '0')
  if length<1 or length>65536:return self._bad(413,'Request too large')
  try:
   req=json.loads(self.rfile.read(length));meth=req['method'];args=req.get('args',[])
   if not isinstance(meth,str) or not isinstance(args,list) or len(args)>8:raise ValueError('Invalid payload')
   value=self.server.backend.call(meth,args)
   if meth in ('prepareStream','openCached'):value=self.server.prefix+'media/'+value+'.mp4'
   self._reply(200,json.dumps({'result':value},ensure_ascii=False,allow_nan=False).encode())
  except Exception as e:self._bad(400,str(e)[:300])
 def do_GET(self):
  if not self.path.startswith(self.server.prefix):return self._bad(404,'Not found')
  path=urllib.parse.urlparse(self.path).path[len(self.server.prefix):]
  if path.startswith('media/'):
   ident=path[6:].removesuffix('.mp4')
   return self._stream(ident)
  if path in ('','index.html'):path='index.html'
  if not path or '..' in Path(path).parts or path.startswith('/') or '\\' in path:return self._bad(404,'Not found')
  file=(RENDERER/path).resolve()
  if RENDERER.resolve() not in file.parents or not file.is_file():return self._bad(404,'Not found')
  ctype=mimetypes.guess_type(file.name)[0] or 'application/octet-stream'
  if file.suffix=='.js':ctype='text/javascript; charset=utf-8'
  if file.suffix=='.css':ctype='text/css; charset=utf-8'
  data=file.read_bytes();self._reply(200,data,ctype)
 def _serve_cached_file(self,file,start):
  # HTTP Range supports true seek for cached video. For time-based seeks, FFmpeg is used
  # instead of incorrectly equating seconds with byte offsets.
  if start:
   process=subprocess.Popen([self.server.ffmpeg,'-nostdin','-hide_banner','-loglevel','error','-ss',str(start),'-i',str(file),'-map','0:v:0','-map','0:a:0?','-c','copy','-bsf:a','aac_adtstoasc','-movflags','frag_keyframe+empty_moov+default_base_moof','-f','mp4','pipe:1'],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
   self.send_response(200);self.send_header('Content-Type','video/mp4');self.send_header('Connection','close');self.close_connection=True;self.end_headers()
   try:
    while chunk:=process.stdout.read(65536):self.wfile.write(chunk)
   except (BrokenPipeError,ConnectionResetError):pass
   finally:process.kill();process.wait(timeout=5)
   return
  size=file.stat().st_size;range_header=self.headers.get('Range','');start_byte=0;end_byte=size-1
  if range_header:
   match=re.fullmatch(r'bytes=(\d*)-(\d*)',range_header)
   if not match:return self._bad(416,'Bad range')
   try:
    if match.group(1):
     start_byte=int(match.group(1));end_byte=min(int(match.group(2)),size-1) if match.group(2) else size-1
    elif match.group(2):start_byte=max(0,size-int(match.group(2)))
    else:raise ValueError()
   except ValueError:return self._bad(416,'Bad range')
   if start_byte>=size or end_byte<start_byte:return self._bad(416,'Bad range')
  total=end_byte-start_byte+1
  self.send_response(206 if range_header else 200)
  self.send_header('Content-Type','video/mp4');self.send_header('Content-Length',str(total));self.send_header('Accept-Ranges','bytes')
  if range_header:self.send_header('Content-Range',f'bytes {start_byte}-{end_byte}/{size}')
  self.end_headers()
  with file.open('rb') as f:
   f.seek(start_byte)
   while total>0:
    chunk=f.read(min(total,65536))
    if not chunk:break
    self.wfile.write(chunk);total-=len(chunk)
 def _stream(self,ident):
  playback=self.server.backend.playbacks.get(ident)
  if not playback or time.time()-playback[1]>1800:return self._bad(404,'Video session expired')
  if not self.server.ffmpeg:return self._bad(503,'FFmpeg unavailable')
  if len(playback)>=3 and playback[2] is True:
   path=Path(playback[0]);base=self.server.backend.video_dir.resolve()
   if path.resolve().parent!=base or not path.is_file():return self._bad(404,'Cached file unavailable')
   return self._serve_cached_file(path,0)
  url=playback[0]
  query=urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
  try:start=float(query.get('start',['0'])[0])
  except (ValueError,OverflowError):return self._bad(400,'Invalid seek')
  if not math.isfinite(start) or start<0 or start>172800:return self._bad(400,'Invalid seek')
  cached=self.server.backend.cache_path(url)
  if cached.is_file():
   return self._serve_cached_file(cached,start)
  # FFmpeg accesses the HTTPS URL already approved by AniLiberty. No user-supplied arbitrary URL.
  command=[self.server.ffmpeg,'-nostdin','-hide_banner','-loglevel','error','-rw_timeout','12000000',*self.server.backend.network.ffmpeg_proxy_flags(),*(['-ss',str(start)] if start else []),'-i',url,'-map','0:v:0','-map','0:a:0?','-c','copy','-bsf:a','aac_adtstoasc','-movflags','frag_keyframe+empty_moov+default_base_moof','-f','mp4','pipe:1']
  env=os.environ.copy()
  if (RUNTIME/'ffmpeg'/'lib').is_dir():env['LD_LIBRARY_PATH']=self.server.ffmpeg_lib
  process=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,env=env)
  self.send_response(200);self.send_header('Content-Type','video/mp4');self.send_header('Cache-Control','no-store');self.send_header('Connection','close');self.close_connection=True;self.send_header('Access-Control-Allow-Origin',f'http://127.0.0.1:{self.server.server_port}');self.end_headers()
  try:
   while buf:=process.stdout.read(32768):
    self.wfile.write(buf);self.wfile.flush()
  except (BrokenPipeError,ConnectionResetError):pass
  finally:
   process.kill();process.wait(timeout=5)

def chromium_path():
 bundled=RUNTIME/'chromium'/'chromium'
 if bundled.is_file():return str(bundled)
 return shutil.which('chromium') or shutil.which('chromium-browser')

def main():
 backend=Backend();server=Server(('127.0.0.1',0),backend)
 threading.Thread(target=server.serve_forever,daemon=True).start()
 if '--selftest' not in sys.argv:backend.network.start_first_run_test()
 address=f'http://127.0.0.1:{server.server_port}{server.prefix}'
 deep_link=next((parse_anixart_release_url(arg) for arg in sys.argv[1:] if parse_anixart_release_url(arg)),None)
 if deep_link:address+='#/release/anixart/'+deep_link
 if '--selftest' in sys.argv:
  print(address,flush=True)
  try:
   while True:time.sleep(.5)
  except KeyboardInterrupt:pass
  return
 chromium=chromium_path()
 if not chromium:
  print('AniSpawn: Chromium runtime not found',file=sys.stderr);sys.exit(2)
 userdata=backend.directory/'browser-profile';userdata.mkdir(parents=True,exist_ok=True)
 command=[chromium,'--app='+address,'--user-data-dir='+str(userdata),'--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-component-update','--disable-sync','--disable-features=MediaRouter','--window-size=1440,900',*backend.network.browser_flags()]
 if '--test-headless' in sys.argv:command+=['--headless=new','--no-sandbox','--disable-gpu','--virtual-time-budget=1500','--screenshot='+str(BASE/'runtime-smoke.png')]
 try:
  # Scope ABI-compatible libraries to bundled Chromium only. FFmpeg has a separate
  # private library directory; the backend Python process retains system libraries.
  env=os.environ.copy()
  chromium_lib=RUNTIME/'chromium/lib'
  if chromium==str(RUNTIME/'chromium/chromium') and chromium_lib.is_dir():
   env['LD_LIBRARY_PATH']=str(chromium_lib)
  p=subprocess.Popen(command,cwd=str(RUNTIME/'chromium') if (RUNTIME/'chromium').exists() else None,env=env)
  return p.wait()
 finally:server.shutdown();server.server_close()

if __name__=='__main__':sys.exit(main())
