const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname,'..');
const src = path.join(root, 'node_modules','hls.js','dist','hls.min.js');
const dest = path.join(root, 'renderer','vendor','hls.min.js');
if (!fs.existsSync(src)) {
  console.error('hls.js not installed. Run npm install.');
  process.exitCode = 1;
} else {
  fs.mkdirSync(path.dirname(dest),{recursive:true});
  fs.copyFileSync(src,dest);
  console.log('Local HLS engine prepared:', dest);
}
