import base64,re
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]/'renderer'
html=(R/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','http-equiv="X-Test-CSP-Disabled"').replace('<script defer src=','<script data-src=').replace('<link rel="stylesheet" href=','<link rel="stylesheet" data-href=')
for path in set(re.findall(r'(\.\/assets\/[^" ]+)',html)):
 f=R/path[2:]
 if not f.exists():raise FileNotFoundError(f)
 mime='image/webp' if f.suffix=='.webp' else 'image/png'
 html=html.replace(path,'data:'+mime+';base64,'+base64.b64encode(f.read_bytes()).decode('ascii'))
fixture={'id':'anixart:2563','remoteId':'2563','source':'anixart','name':'О моём перерождении в слизь','original':'Tensei Shitara Slime Datta Ken','image':'','description':'Релиз найден по API, просмотр недоступен у поставщика','year':'2018','rating':4.9,'episodesTotal':24,'category':'Аниме','blocked':True,'hiddenByProvider':True,'accessNote':'Ограничение сервиса: доступ к воспроизведению не предоставлен','url':'https://anixart.tv/release/2563'}
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 page=b.new_page(viewport={'width':1480,'height':900})
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(html,wait_until='domcontentloaded',timeout=15000)
 page.add_style_tag(content=(R/'styles.css').read_text())
 page.add_script_tag(content=(R/'upscale.js').read_text())
 page.evaluate('''fixture=>{window.anispawn={
 getState:async()=>({source:'anixart',theme:'dark',quality:'1080',bookmarks:[],history:[],volume:.8,upscale:{enabled:false,mode:'balanced',scale:1.5,strength:.45}}),
 list:async()=>({items:[fixture],stale:false}),search:async()=>({items:[fixture],stale:false}),
 details:async()=>({...fixture,episodes:[],dubs:[]}),
 sources:async()=>[{id:'anixart',name:'Anixart',kind:'embedded',description:'Test'}],
 health:async()=>({ok:true,ms:1}), updateState:async()=>({}), toggleBookmark:async v=>({added:true,bookmarks:[v]}),
 recordWatch:async v=>[v], prepareStream:async u=>u,chooseVideo:async()=>null,
 openExternal:async()=>{},configureKodik:async()=>({configured:true}),
 syncAll:async()=>({providers:{},pending:0})}}''',fixture)
 page.add_script_tag(content=(R/'release-router.js').read_text())
 page.add_script_tag(content=(R/'app.js').read_text())
 page.wait_for_timeout(550)
 for name in ['home','search','library','history','account','settings','play','sync']:
  imgs=page.locator('img[src^="data:"]')
  assert imgs.count()>12
  assert page.locator('button[data-view="settings"]').count()==1
 assert page.locator('#catalog-grid .anime-card').count()==1
 assert page.locator('#catalog-grid .content-limit').count()==1
 page.screenshot(path='/mnt/data/AniSpawn-0.5.8-UI-Preview.png',animations='disabled')
 page.locator('button[data-view="settings"]').click()
 assert page.locator('#view-settings').is_visible()
 page.locator('button[data-view="home"]').click()
 assert page.locator('#view-home').is_visible()
 page.locator('#catalog-grid .anime-card').click()
 assert page.locator('#view-release').is_visible()
 assert page.locator('#detail-back').is_visible()
 assert 'ограничено' in page.locator('#episode-list').inner_text().lower() or 'Ограничение' in page.locator('#episode-list').inner_text()
 print('UI: images, single settings, blocked title card, modal, no errors:',errors)
 assert not errors,errors
 b.close()
