#!/usr/bin/env python3
"""Offline Linux amd64 package from system-provided browser and FFmpeg runtimes.
This build step does NOT contact npm, pip or any external network.
"""
from pathlib import Path
import os
import shutil
import subprocess
import time
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
OUT=Path('/mnt/data')
PKG=OUT/'.anispawn-0.5-deb-stage'
if PKG.exists():shutil.rmtree(PKG)
DEST=PKG/'opt'/'anispawn'
(DEST/'desktop').mkdir(parents=True)
shutil.copy2(ROOT/'desktop/server.py',DEST/'desktop/server.py')
shutil.copy2(ROOT/'desktop/shared_sources.py',DEST/'desktop/shared_sources.py')
shutil.copy2(ROOT/'desktop/accounts.py',DEST/'desktop/accounts.py')
shutil.copy2(ROOT/'desktop/unified_sync.py',DEST/'desktop/unified_sync.py')
shutil.copy2(ROOT/'desktop/video_providers.py',DEST/'desktop/video_providers.py')
shutil.copy2(ROOT/'desktop/anixart_network.py',DEST/'desktop/anixart_network.py')
shutil.copy2(ROOT/'desktop/network_settings.py',DEST/'desktop/network_settings.py')
shutil.copy2(ROOT/'desktop/site_bridges.py',DEST/'desktop/site_bridges.py')
shutil.copy2(ROOT/'desktop/source_hub.py',DEST/'desktop/source_hub.py')
shutil.copytree(ROOT/'renderer',DEST/'renderer',ignore=shutil.ignore_patterns('__pycache__'))
(DEST/'runtime/chromium').mkdir(parents=True)
chromium=Path('/usr/lib/chromium')
if not (chromium/'chromium').is_file():raise RuntimeError('Chromium binary unavailable')
for entry in chromium.iterdir():
 if entry.name in ('extensions','libVkLayer_khronos_validation.so','libVkLayer_khronos_validation.so.TOC','libVkICD_mock_icd.so','libVkICD_mock_icd.so.TOC'):continue
 dest=DEST/'runtime/chromium'/entry.name
 if entry.is_dir():shutil.copytree(entry,dest)
 elif entry.is_file():shutil.copy2(entry,dest)
# Chromium is built on Debian 13. A target Ubuntu may have a different libjpeg.so.62
# (classic IJG rather than libjpeg-turbo) that lacks jpeg_crop_scanline.
# Vendor the ELF library closure in a private directory and use it ONLY for
# the Chromium subprocess. Never overwrite system libraries.
libdir=DEST/'runtime/chromium/lib';libdir.mkdir(parents=True)
chromium_binary=DEST/'runtime/chromium/chromium'
chromium_ldd=subprocess.run(['ldd',str(chromium_binary)],capture_output=True,text=True,check=True).stdout
SYSTEM_LIBS={'libc.so.6','libm.so.6','libdl.so.2','libpthread.so.0',
             'librt.so.1','libresolv.so.2','libnss_files.so.2','libnss_dns.so.2',
             'ld-linux-x86-64.so.2',
             # Graphics drivers must match the destination OS, not the build host.
             'libgbm.so.1','libdrm.so.2','libudev.so.1'}
private_libraries=[]
for line in chromium_ldd.splitlines():
 bits=line.strip().split()
 if 'not found' in line:raise RuntimeError('Unresolved Chromium library: '+line)
 if '=>' not in bits:continue
 name=bits[0]
 if name in SYSTEM_LIBS:continue
 lib=Path(bits[bits.index('=>')+1])
 if not lib.exists():raise RuntimeError('Chromium library unavailable: '+str(lib))
 if (libdir/name).exists():continue
 shutil.copy2(lib,libdir/name)
 private_libraries.append(name)
# Fails the build if the expected turbo-specific symbol was not actually copied.
libjpeg=libdir/'libjpeg.so.62'
if not libjpeg.exists():raise RuntimeError('Chromium-compatible libjpeg not bundled')
symbols=subprocess.run(['objdump','-T',str(libjpeg)],capture_output=True,text=True,check=True).stdout
if 'jpeg_crop_scanline' not in symbols:raise RuntimeError('Bundled libjpeg lacks jpeg_crop_scanline')
# Include license notices for redistributed Linux libraries.
licenses=DEST/'licenses/chromium-libs';licenses.mkdir(parents=True)
# Resolve package ownership using the original system files.
for line in chromium_ldd.splitlines():
 bits=line.strip().split()
 if '=>' not in bits or bits[0] not in private_libraries:continue
 original=Path(bits[bits.index('=>')+1]).resolve()
 owners=subprocess.run(['dpkg-query','-S',str(original)],capture_output=True,text=True)
 if owners.returncode:continue
 pkg=owners.stdout.split(': ',1)[0].split(',')[0].split(':')[0]
 copy=Path('/usr/share/doc')/pkg/'copyright'
 if copy.exists() and not (licenses/(pkg+'.copyright')).exists():shutil.copy2(copy,licenses/(pkg+'.copyright'))
print('Bundled Chromium libs:',len(private_libraries),flush=True)
# FFmpeg needs bundled library dependencies; keep glibc from the target OS to avoid distro mismatch.
ffmpeg=Path('/usr/bin/ffmpeg')
if not ffmpeg.exists():raise RuntimeError('FFmpeg unavailable')
ffdir=DEST/'runtime/ffmpeg';(ffdir/'lib').mkdir(parents=True)
shutil.copy2(ffmpeg,ffdir/'ffmpeg')
ldd=subprocess.run(['ldd',str(ffmpeg)],capture_output=True,text=True,check=True).stdout
count=0
for line in ldd.splitlines():
 bits=line.strip().split()
 if '=>' not in bits:continue
 lib=Path(bits[bits.index('=>')+1])
 if not lib.exists():raise RuntimeError('Missing library: '+str(lib))
 # Never bundle glibc and its intrinsic loader; rely on host glibc (glibc >=2.36).
 if lib.name in ('libc.so.6','libm.so.6','libdl.so.2','libpthread.so.0','librt.so.1','libresolv.so.2','libnss_files.so.2','libnss_dns.so.2'):continue
 if (ffdir/'lib'/lib.name).exists():continue
 shutil.copy2(lib,ffdir/'lib'/lib.name);count+=1
print('Included FFmpeg libs:',count,flush=True)
# copy distribution copyright files
for name,src in [('CHROMIUM_COPYRIGHT','/usr/share/doc/chromium/copyright'),('FFMPEG_COPYRIGHT','/usr/share/doc/ffmpeg/copyright')]:
 if Path(src).exists():shutil.copy2(src,DEST/name)
shutil.copy2(ROOT/'LICENSE',DEST/'LICENSE')
# Brand icon generated for AniSpawn. Keep it in standard Linux icon theme locations.
icon_src=ROOT/'renderer/assets/icon-256.png'
if not icon_src.exists():raise RuntimeError('AniSpawn icon missing')
shutil.copy2(icon_src,DEST/'icon.png')
for n in (16,32,48,64,128,256,512):
 folder=PKG/f'usr/share/icons/hicolor/{n}x{n}/apps'
 folder.mkdir(parents=True,exist_ok=True)
 shutil.copy2(ROOT/f'renderer/assets/icon-{n}.png',folder/'anispawn.png')
(PKG/'DEBIAN').mkdir(parents=True)
(PKG/'DEBIAN').chmod(0o755)
(PKG/'DEBIAN/control').write_text('''Package: anispawn
Version: 0.5.15
Section: video
Priority: optional
Architecture: amd64
Depends: python3 (>= 3.9), libc6 (>= 2.39), apparmor (>= 4.0)
Maintainer: AniSpawn Project <anispawn@localhost>
Description: AniSpawn independent offline-packaged desktop anime client
 HTML/CSS/JavaScript interface, bundled Chromium engine and FFmpeg HLS-to-MP4.
 No npm, Node.js or Electron installation required on the destination system.
 Private libraries bundled for Chromium ABI compatibility.
''')
# Install AppArmor's narrow userns permission profile automatically (Ubuntu 23.10+).
profile_dir=PKG/'etc/apparmor.d'
profile_dir.mkdir(parents=True,exist_ok=True)
shutil.copy2(ROOT/'packaging/apparmor.d/anispawn-chromium',profile_dir/'anispawn-chromium')
for hook in ('postinst','prerm'):
 script=PKG/'DEBIAN'/hook
 shutil.copy2(ROOT/'packaging/debian'/hook,script)
 script.chmod(0o755)
(PKG/'usr/bin').mkdir(parents=True)
launcher=PKG/'usr/bin/anispawn'
launcher.write_text('#!/bin/sh\nexec /usr/bin/python3 /opt/anispawn/desktop/server.py "$@"\n')
launcher.chmod(0o755)
(PKG/'usr/share/applications').mkdir(parents=True)
(PKG/'usr/share/applications/anispawn.desktop').write_text('''[Desktop Entry]
Type=Application
Name=AniSpawn
Comment=Autonomous desktop anime client
Exec=/usr/bin/anispawn
Icon=anispawn
Terminal=false
Categories=AudioVideo;Video;Player;
StartupWMClass=AniSpawn
''')
(PKG/'usr/share/doc/anispawn').mkdir(parents=True)
(PKG/'usr/share/doc/anispawn/README').write_text('''AniSpawn 0.5.15 Linux amd64. Runtime embedded. No npm needed.
Run from your app menu (AniSpawn) or execute anispawn.
Saved state: ~/.config/AniSpawn/state.json
Edit HTML: /opt/anispawn/renderer/index.html and styles.css (requires write permission).
Note: Chromium depends on common Linux graphical and system libraries.
Video is accessed only from providers authorized by the user and subject to service restrictions.
''')
file=OUT/'AniSpawn-0.5.15-linux-amd64.deb'
print('Creating',file,flush=True)
subprocess.run(['dpkg-deb','--root-owner-group','-Zzstd','-z10','--build',str(PKG),str(file)],check=True)
print('Size:',file.stat().st_size,flush=True)
