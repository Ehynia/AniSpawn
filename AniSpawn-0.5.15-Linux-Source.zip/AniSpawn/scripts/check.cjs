const fs=require('node:fs');const path=require('node:path');const cp=require('node:child_process');
const base=path.resolve(__dirname,'..');
const folders=['electron','src','renderer','scripts'];
let files=[];
for(const folder of folders){const scan=p=>{for(const entry of fs.readdirSync(p,{withFileTypes:true})){const full=path.join(p,entry.name);if(entry.isDirectory())scan(full);else if(/\.([cm]?js)$/.test(entry.name))files.push(full)}};scan(path.join(base,folder));}
for(const file of files){const r=cp.spawnSync(process.execPath,['--check',file],{stdio:'inherit'});if(r.status!==0)process.exit(r.status||1)}
console.log('Syntax OK:',files.length,'JS files');
