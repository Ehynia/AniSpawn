"""Opt-in offline GUI check for joined source controls with mocked provider data."""
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]/'renderer'
A={'id':'anixart:2563','source':'anixart','remoteId':'2563','name':'О моём перерождении в слизь','original':'Tensei Shitara Slime Datta Ken','year':2018,'image':'','blocked':False,'alternatives':[{'id':'libria:8452','source':'libria','name':'О моём перерождении в слизь','year':2018,'match':'exact'}],'availableSources':['anixart','libria']}
L={'id':'libria:8452','source':'libria','remoteId':'8452','name':A['name'],'original':A['original'],'year':2018,'image':'','blocked':False}
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 page=browser.new_page(viewport={'width':1350,'height':900})
 errors=[];page.on('pageerror',lambda x:errors.append(str(x)))
 html=(R/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','http-equiv="X-Test-CSP-Disabled"').replace('<script defer src=', '<script data-src=').replace('<link rel="stylesheet" href=', '<link rel="stylesheet" data-href=')
 page.set_content(html,wait_until='domcontentloaded')
 page.add_style_tag(content=(R/'styles.css').read_text())
 page.add_script_tag(content=(R/'upscale.js').read_text())
 page.evaluate('''([a,l])=>{
 window.anispawn={
  getState:async()=>({source:'both',theme:'dark',quality:'1080',bookmarks:[],history:[],volume:.8}),
  list:async()=>({items:[a],stale:false,providers:{anixart:'online',libria:'online'}}),
  search:async()=>({items:[a],stale:false}),
  details:async id=>id.startsWith('anixart')?{...a,dubs:[{id:1,name:'Озвучка Anixart'}],episodes:[]}:{...l,episodes:[{ordinal:1,name:'Первая серия',quality:{'720':'https://media.example/1.m3u8'},duration:1342}]},
  relatedSources:async id=>({items:id.startsWith('anixart')?[{id:l.id,source:'libria',name:l.name,year:2018,match:'exact'}]:[{id:a.id,source:'anixart',name:a.name,year:2018,match:'exact'}],stale:false}),
  anixartSources:async()=>[{id:2,name:'Kodik',count:1}],anixartEpisodes:async()=>[{name:'Серия 1',episode:'1',embed:'https://kodik.info/x'}],
  sources:async()=>[], health:async()=>({ok:true}),updateState:async v=>v,recordWatch:async()=>[],historyInfo:async()=>({}),
  chooseVideo:async()=>null, configureKodik:async()=>true
 };
}''',[A,L]);page.add_script_tag(content=(R/'app.js').read_text())
 page.locator('#catalog-grid .anime-card').first.wait_for(timeout=8000)
 assert 'Anixart + AniLiberty' in page.locator('.poster-badge').first.inner_text()
 page.locator('#catalog-grid .anime-card').first.click()
 page.locator('#detail-integrated').wait_for(timeout=8000)
 page.get_by_role('button',name='Показать HLS-серии').first.click()
 page.locator('.source-fusion-episodes button',has_text='720p').first.wait_for(timeout=8000)
 assert 'Первая серия' in page.locator('#detail-integrated-results').inner_text()
 assert 'Озвучка Anixart' in page.locator('#episode-list').inner_text()
 assert page.locator('#detail-title').inner_text()==A['name']
 assert not errors,errors
 page.screenshot(path='/mnt/data/AniSpawn-0.5.11-Unified-Preview.png',animations='disabled')
 print('UI JOINED OK: one title, Anixart dubs + AniLiberty HLS, no page errors')
 browser.close()
