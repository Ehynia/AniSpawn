# AppArmor sandbox rule for AniSpawn

This package installs `/etc/apparmor.d/anispawn-chromium` and loads it during
`.deb` configuration. The exact-path profile grants the root-owned Chromium
binary `userns,` permission on Ubuntu 23.10+, so Chromium can create its own
sandbox without changing sysctls or launching with `--no-sandbox`.

`flags=(unconfined)` relaxes AppArmor confinement for **this one executable**;
Chromium's internal process sandbox stays enabled. This is narrower than
turning off `kernel.apparmor_restrict_unprivileged_userns` for all users.
The package removes the loaded profile during upgrades and removal.

Based on Chromium's AppArmor userns documentation and Ubuntu release notes.
The AppArmor parser is tested in the build environment, but a runtime test
on Ubuntu 26.10 with AppArmor enforcement is still required.
