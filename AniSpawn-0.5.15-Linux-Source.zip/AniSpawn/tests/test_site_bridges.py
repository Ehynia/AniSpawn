import sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'desktop'))
import site_bridges as sites
import video_providers as vp
import server

SR='https://sovetromantica.com/anime/1523-senpai-wa-otokonoko'
AV='https://animevost.org/tip/tv/3802-tensei-shitara-slime-datta-ken-4th-season.html'
SH='https://shiza-project.com/releases/@695474288479703040'

class SitesTest(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.backend=server.Backend(self.temp.name)
    def tearDown(self):
        self.temp.cleanup()
    def test_public_releases_only(self):
        for url in (SR, AV, SH, SH.replace('@','%40')):
            self.assertEqual(sites.validate_page_url(url),url)
        for url in ('https://vk.com/video-1_3','https://rutube.ru/video/abcdef1234567890abcdef1234567890/',
                    'https://vkvideo.ru/video-1_2','http://sovetromantica.com/anime/1523-a',
                    'https://sovetromantica.com.evil/anime/1523-a',
                    'https://user:pass@animevost.org/tip/tv/3802-a.html',
                    'https://shiza-project.com/release/%40abc',
                    'https://127.0.0.1/anime/1523-a',
                    'https://animevost.org/tip/tv/3802-a.html?next=https://localhost'):
            with self.subTest(url=url), self.assertRaises(ValueError):
                sites.validate_page_url(url)
    def test_public_html_metadata_without_embeds(self):
        doc='''<title>Название фильма</title><meta property="og:description" content="Русские субтитры">'''
        result=sites.import_page(SR,doc)
        self.assertEqual(result['name'],'Название фильма')
        self.assertEqual(result['description'],'Русские субтитры')
        self.assertEqual(result['players'],[])
        self.assertFalse(result['playable'])
        self.assertEqual(result['source'],'sites')
    def test_player_whitelist_refuses_vk_and_rutube_in_html(self):
        doc='''<meta property="og:title" content="Anime title"><iframe src="https://vk.com/video_ext.php?oid=-1&id=2"></iframe>
        <iframe src="https://rutube.ru/play/embed/abcdef1234567890abcdef1234567890/"></iframe>
        <iframe src="https://kodik.info/serial/abc"></iframe>
        <iframe src="https://127.0.0.1/video"></iframe>
        <iframe src="javascript:alert(1)"></iframe>
        <iframe src="https://evil.example/embed/123"></iframe>'''
        item=sites.import_page(AV,doc)
        self.assertEqual(len(item['players']),1)
        self.assertEqual(item['players'][0]['embed'],'https://kodik.info/serial/abc')
        for url in ('https://vk.com/video_ext.php?oid=-1&id=2','https://rutube.ru/play/embed/123','https://sub.vkvideo.ru/video'):
            self.assertFalse(vp.external_url(url))
            self.assertFalse(vp.embed_url(url))
            self.assertFalse(sites.allowed_embed(url))
    def test_embed_cannot_point_at_release_page_in_self_site(self):
        self.assertFalse(sites.allowed_embed(SR))
        self.assertEqual(sites.allowed_embed('https://sovetromantica.com/embed/abc'),'https://sovetromantica.com/embed/abc')
    def test_api_import_catalog_details_remove_and_persist(self):
        self.assertEqual(self.backend.call('list',['sites',1])['items'],[])
        with patch.object(sites,'read_public_html',return_value='<meta property="og:title" content="Example"><iframe src="https://video.sibnet.ru/shell.php?videoid=2"></iframe>'):
            imported=self.backend.call('importSite',[SR])
        self.assertEqual(imported['name'],'Example')
        self.assertEqual(imported['id'][:6],'sites:')
        self.assertTrue(imported['playable'])
        self.assertNotIn('external',imported['players'][0])
        self.assertTrue(imported['players'][0]['linkToken'])
        self.assertIn(imported['id'],[x['id'] for x in self.backend.call('list',['sites',1])['items']])
        details=self.backend.call('details',[imported['id']])
        self.assertEqual(details['players'][0]['embed'],'https://video.sibnet.ru/shell.php?videoid=2')
        # Persist public metadata and safe embeds, but never credentials.
        path=self.backend.site_file
        text=path.read_text(encoding='utf-8')
        self.assertIn('Example',text)
        self.assertNotIn('token',text.lower())
        new=server.Backend(self.temp.name)
        self.assertEqual(new.call('details',[imported['id']])['name'],'Example')
        self.assertTrue(new.call('removeSite',[imported['id']])['removed'])
        self.assertEqual(new.call('list',['sites',1])['items'],[])
    def test_bad_import_never_makes_request(self):
        with patch.object(sites,'read_public_html') as get:
            with self.assertRaises(ValueError):self.backend.call('importSite',['https://vk.com/video-1_3'])
            get.assert_not_called()
    def test_read_html_limits_size_and_redirect(self):
        class Response:
            headers={'Content-Type':'text/html; charset=utf-8'}
            def __init__(self, dest, html):self.dest=dest;self.html=html
            def __enter__(self):return self
            def __exit__(self,*exc):return False
            def geturl(self):return self.dest
            def read(self,n):return self.html
        def redirect(req,timeout):return Response('https://localhost/admin',b'<h1>X</h1>')
        with self.assertRaisesRegex(ValueError,'Переадресация'):
            sites.read_public_html(SR,redirect)
        with self.assertRaisesRegex(ValueError,'слишком большая'):
            sites.read_public_html(SR,lambda req,timeout:Response(SR,b'x'*(sites.MAX_HTML+1)))

if __name__=='__main__':unittest.main()
