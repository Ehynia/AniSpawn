import sys,unittest, tempfile
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'desktop'))
import server, video_providers as vp

class VideoProviderTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory()
  self.backend=server.Backend(self.temp.name)
 def tearDown(self):self.temp.cleanup()
 def test_mikai_normalization(self):
  raw={'ids':{'mikai':1523,'mal':21,'slug':'one-piece'},'titles':{'ua':'Ван Піс'},'year':1999,'images':{'poster':{'big':{'webp':'https://images.mikai.me/a.webp'}}}}
  item=server.normalize(raw,'mikai')
  self.assertEqual(item['id'],'mikai:1523');self.assertEqual(item['image'],'https://images.mikai.me/a.webp')
 def test_mikai_page_and_search_use_documented_envelope(self):
  captured=[]
  def mock(url,**kwargs):
   captured.append(url);return {'ok':True,'result':[{'ids':{'mikai':20},'titles':{'english':'Title'}}]}
  with patch.object(server,'fetch_json',side_effect=mock):
   result=self.backend.catalog('mikai',page=2,query='one piece')
  self.assertEqual(result[0]['source'],'mikai')
  self.assertIn('search=one+piece',captured[0]);self.assertIn('page=2',captured[0]);self.assertIn('public/v1/anime?',captured[0])
 def test_mikai_player_releases_and_credits(self):
  raw={'ok':True,'result':{'releases':[{'kind':'voice','teams':[{'name':'FanVoxUA'}], 'episodes':[{'number':1.5,'sources':[{'provider':'kodik','embedUrl':'https://kodik.info/serial/abc'},{'provider':'moon','embedUrl':'https://moon.video/abc'}]}]}]}}
  players,blocked,lic=vp.mikai_players(raw)
  self.assertEqual(len(players),2);self.assertFalse(blocked)
  self.assertIn('FanVoxUA',players[0]['name']);self.assertEqual(players[0]['episode'],'1.5')
  self.assertTrue(players[0]['embed']);self.assertEqual(players[1]['embed'],'https://moon.video/abc')
 def test_mikai_licensed_no_playback(self):
  self.assertEqual(vp.mikai_players({'result':{'licensed':True,'license':{'name':'Studio A'},'releases':[{'episodes':[{}]}]}}),([],True,'Studio A'))
 def test_mikai_detail_registers_external_token_and_has_no_api_keys(self):
  raw={'ids':{'mikai':55},'titles':{'ua':'Example'},'description':'Valid'}
  play={'ok':True,'result':{'releases':[{'teams':[{'name':'Group'}],'episodes':[{'number':1,'sources':[{'provider':'moon','embedUrl':'https://moon.video/embed/1'}]}]}]}}
  with patch.object(server,'fetch_json',side_effect=[{'ok':True,'result':raw},play]) as fetch:
   info=self.backend.details('mikai:55')
  self.assertEqual(info['id'],'mikai:55')
  self.assertEqual(len(info['players']),1)
  self.assertNotIn('external',info['players'][0]);self.assertTrue(info['players'][0]['linkToken'])
  self.assertEqual(fetch.call_args_list[0].args[0],vp.MIKAI_BASE+'/anime/55')
 def test_external_urls_reject_insecure_local_credentials(self):
  for s in ['http://example.org/foo','https://127.0.0.1/x','https://localhost/x','https://admin:secret@evil.com/','https://evil.local/','file:///etc/passwd','https://x.com:8080/a','https://evil.com@localhost/a']:
   self.assertFalse(vp.external_url(s),s)
  self.assertEqual(vp.external_url('https://moon.video/embed/1'),'https://moon.video/embed/1')
 def test_kinobox_translations_and_allowlist(self):
  data=[{'source':'kodik','success':True,'translations':[{'name':'Voice A','quality':'1080p','iframeUrl':'https://kodik.info/a'},{'name':'Voice B','iframeUrl':'https://moon.video/b'}]},{'source':'notworking','success':False,'iframeUrl':'https://kodik.info/blocked'}]
  rows=vp.kinobox_players(data)
  self.assertEqual(len(rows),2)
  self.assertEqual(rows[0]['embed'],'https://kodik.info/a')
  self.assertEqual(rows[1]['embed'],'https://moon.video/b')
 def test_kinobox_is_manual_query_and_rate_limited(self):
  with patch.object(server,'fetch_json',return_value=[{'source':'kodik','success':True,'iframeUrl':'https://kodik.info/video'}]) as fetch:
   first=self.backend.find_players('Bleach')
   second=self.backend.find_players('Bleach')
   self.assertEqual(first[0]['name'],'kodik');self.assertEqual(len(second),1)
   self.assertEqual(fetch.call_count,1)
   self.assertIn('title=Bleach',fetch.call_args.args[0])
   with self.assertRaises(RuntimeError):self.backend.find_players('Naruto')
 def test_backend_open_player_requires_registered_token(self):
  with self.assertRaises(ValueError):self.backend.open_player('not-a-token')
  registered=self.backend._register_players([vp.player_from_url('provider','https://moon.video/a')])
  with patch.object(server.webbrowser,'open',return_value=True) as wb:
   self.assertTrue(self.backend.open_player(registered[0]['linkToken']))
   wb.assert_called_once_with('https://moon.video/a')
 def test_anixart_filters_dubs_sources_and_episodes(self):
  self.assertEqual(vp.anixart_dubs({'types':[{'id':1,'name':'Dub'},{'id':'bad','name':'Invalid'}]}),[{'id':1,'name':'Dub','sub':False}])
  self.assertEqual(vp.anixart_sources({'sources':[{'id':8,'name':'Kodik','episodes_count':12}]}),[{'id':8,'name':'Kodik','count':12}])
  ep=vp.anixart_episodes({'episodes':[{'name':'1','url':'https://kodik.info/a','iframe':True},{'name':'2','url':'javascript:alert(1)'}]})
  self.assertEqual(len(ep),1);self.assertEqual(ep[0]['embed'],'https://kodik.info/a')
 def test_anixart_api_endpoints_mapped(self):
  with patch.object(server,'fetch_json',side_effect=[{'code':0,'sources':[{'id':50,'name':'S'}]},{'code':0,'episodes':[{'name':'1','url':'https://kodik.info/serial/abc/'}]}]) as fetch:
   a=self.backend.anixart_sources('anixart:321',4)
   b=self.backend.anixart_episodes('anixart:321',4,50)
  self.assertEqual(a[0]['id'],50);self.assertEqual(b[0]['provider'],'Anixart')
  self.assertEqual(fetch.call_args_list[0].args[0],vp.ANIXART_BASE+'/episode/321/4')
  self.assertEqual(fetch.call_args_list[1].args[0],vp.ANIXART_BASE+'/episode/321/4/50')
 def test_invalid_anixart_ids_block_before_network(self):
  with self.assertRaises(ValueError):self.backend.anixart_sources('mikai:3',1)
  with self.assertRaises(ValueError):self.backend.anixart_episodes('anixart:1',1,-2)
 def test_backend_stream_is_never_registered_from_untrusted_external_player(self):
  info=self.backend._register_players([vp.player_from_url('Video','https://moon.video/a')]);self.assertEqual(len(info),1)
  with self.assertRaises(ValueError):self.backend.prepare('https://moon.video/a')

if __name__=='__main__':unittest.main()
