import sys,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'desktop'))
import server, video_providers as vp

class AnixartVisibilityTests(unittest.TestCase):
 def setUp(self):
  import tempfile
  self.temp=tempfile.TemporaryDirectory()
  self.backend=server.Backend(self.temp.name)
 def tearDown(self):self.temp.cleanup()
 def test_current_search_api_v2_post_not_get(self):
  recorded=[]
  def fake(url,method='GET',data=None,**kwargs):
   recorded.append((url,method,data,kwargs))
   return {'code':0,'releases':[{'id':2563,'title_ru':'О моём перерождении в слизь','is_view_blocked':True,'is_play_disabled':True}]}
  with patch.object(server,'fetch_json',side_effect=fake):
   got=self.backend.catalog('anixart',page=3,query='слизь')
  self.assertEqual(len(got),1)
  self.assertEqual(got[0]['id'],'anixart:2563')
  self.assertTrue(got[0]['blocked'])
  self.assertTrue(got[0]['hiddenByProvider'])
  self.assertEqual(recorded[0][1],'POST')
  self.assertEqual(recorded[0][2]['query'],'слизь')
  self.assertTrue(recorded[0][0].endswith('/search/releases/2'))
  self.assertEqual(recorded[0][3]['headers']['API-Version'],'v2')
 def test_default_catalog_uses_post_filter(self):
  with patch.object(server,'fetch_json',return_value={'code':0,'content':[{'id':2563,'title_ru':'Слизь'}]}) as fetch:
   got=self.backend.catalog('anixart')
  self.assertEqual(len(got),1)
  self.assertIn('/filter/0',fetch.call_args.args[0])
  self.assertEqual(fetch.call_args.args[1],'POST')
  self.assertEqual(fetch.call_args.args[2],{})
 def test_search_rpc_page_is_preserved_for_anixart(self):
  with patch.object(self.backend,'catalog',return_value=[]) as catalog:
   self.backend.call('search',['anixart','слизь',4])
  catalog.assert_called_once_with('anixart',4,'слизь')
 def test_search_accepts_id(self):
  with patch.object(server,'fetch_json',return_value={'code':0,'release':{'id':2563,'title_ru':'О моём перерождении в слизь','is_play_disabled':True}}) as fetch:
   results=self.backend.catalog('anixart',query='anixart:2563')
  self.assertEqual(results[0]['id'],'anixart:2563')
  self.assertTrue(results[0]['blocked'])
  self.assertIn('/release/2563',fetch.call_args.args[0])
 def test_unavailable_still_shows_metadata_and_not_players(self):
  with patch.object(server,'fetch_json',return_value={'code':0,'release':{'id':2563,'title_ru':'О моём перерождении в слизь','description':'Аниме','is_ru_blocked':True}}):
   card=self.backend.details('anixart:2563')
  self.assertEqual(card['name'],'О моём перерождении в слизь')
  self.assertTrue(card['blocked'])
  self.assertEqual(card['dubs'],[])
  self.assertIn('Ограничение',card['accessNote'])
 def test_saved_account_bookmarks_can_be_found_without_overwriting(self):
  item=server.normalize({'id':2563,'title_ru':'О моём перерождении в слизь'},'anixart')
  self.backend.state['bookmarks']=[item]
  with patch.object(server,'fetch_json',return_value={'code':0,'releases':[]}):
   got=self.backend.catalog('anixart',query='слизь')
  self.assertEqual(len(got),1)
  self.assertEqual(got[0]['id'],item['id'])
 def test_query_use_signed_in_anixart_session_token(self):
  self.backend.accounts.sessions['anixart']={'token':'mock-token','user_id':1,'name':'fixture'}
  with patch.object(server,'fetch_json',return_value={'code':0,'releases':[]}) as f:
   self.backend.catalog('anixart',query='test')
  self.assertIn('token=mock-token',f.call_args.args[0])
 def test_ui_one_settings_button_and_generated_icons(self):
  root=Path(__file__).resolve().parents[1]
  html=(root/'renderer/index.html').read_text()
  self.assertEqual(html.count('data-view="settings"'),1)
  self.assertNotIn('id="rail-settings"',html)
  self.assertNotIn('id="side-settings"',html)
  self.assertIn('content-limit', (root/'renderer/app.js').read_text())
  for name in ('home','search','library','history','account','settings','play','sync'):
   self.assertTrue((root/'renderer/assets/ui-buttons'/f'{name}.png').is_file())
if __name__=='__main__':unittest.main()
