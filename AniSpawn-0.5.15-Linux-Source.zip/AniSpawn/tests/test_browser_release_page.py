"""UI release deep links in actual Chromium with mocked source API (no network or secrets)."""
import base64, re
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]/'renderer'
html=(R/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','http-equiv="Test-CSP-Off"').replace('<script defer src=','<script data-src=').replace('<link rel="stylesheet" href=', '<link rel="stylesheet" data-href=')
for relative in set(re.findall(r'(\.\/assets\/[^" ]+)',html)):
 file=R/relative[2:]
 if file.exists():
  mime='image/webp' if file.suffix=='.webp' else 'image/png'
  html=html.replace(relative,'data:'+mime+';base64,'+base64.b64encode(file.read_bytes()).decode())
item={'id':'anixart:2563','remoteId':'2563','source':'anixart','name':'О моём перерождении в слизь','description':'Тестовая карточка релиза','image':'','blocked':True,'year':'2018','url':'https://anixart-app.com/release/2563'}
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 page=browser.new_page(viewport={'width':1420,'height':870})
 errors=[];external=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda req:external.append(req.url) if req.url.startswith('https://anixart-app.com/') else None)
 page.goto('about:blank#/release/anixart/2563')
 page.set_content(html,wait_until='domcontentloaded')
 page.add_style_tag(content=(R/'styles.css').read_text())
 page.add_script_tag(content=(R/'upscale.js').read_text())
 page.add_script_tag(content=(R/'release-router.js').read_text())
 page.evaluate('''item=>{
 window.anispawn={getState:async()=>({source:'anixart',theme:'dark',quality:'1080',bookmarks:[],history:[],volume:.8}),list:async()=>({items:[item],stale:false}),search:async()=>({items:[item],stale:false}),details:async()=>({...item,episodes:[],dubs:[],accessNote:'Ограничение сервиса: доступ не предоставлен'}),sources:async()=>[],health:async()=>({ok:true}),updateState:async x=>x,toggleBookmark:async x=>({added:true,bookmarks:[x]}),recordWatch:async x=>[x],configureKodik:async()=>{},chooseVideo:async()=>null,openExternal:async()=>{throw Error('System browser should never be opened');}};
}''',item)
 page.add_script_tag(content=(R/'app.js').read_text())
 print('Initial release loaded',flush=True) if False else None
 page.locator('#view-release.active').wait_for(timeout=12000)
 page.get_by_role('heading',name=item['name']).wait_for(timeout=12000)
 assert 'Тестовая карточка релиза' in page.locator('#detail-desc').inner_text()
 assert 'Ограничение' in page.locator('#episode-list').inner_text()
 assert page.locator('#detail-external').inner_text()=='Копировать ссылку'
 assert page.url.endswith('#/release/anixart/2563')
 assert not external
 page.screenshot(path='/mnt/data/AniSpawn-0.5.9-Release-Preview.png',animations='disabled')
 print('Screenshot done, navigate back',flush=True)
 page.locator('#detail-back').click()
 print('Back clicked',flush=True)
 page.locator('#view-home.active').wait_for()
 page.locator('#search-input').fill('https://anixart-app.com/release/2563')
 page.locator('#search-form button[type="submit"]').click()
 print('Search link submitted',flush=True)
 page.locator('#view-release.active').wait_for()
 page.get_by_role('heading',name=item['name']).wait_for()
 assert not external
 page.evaluate('history.back()')
 print('History.back invoked',flush=True)
 page.locator('#view-home.active').wait_for()
 page.evaluate('''()=>{const a=document.createElement('a');a.id='link-test';a.href='https://anixart-app.com/release/2563';a.textContent='Release link';document.querySelector('#view-home').prepend(a)}''')
 page.locator('#link-test').click()
 print('Anchor intercepted',flush=True)
 page.locator('#view-release.active').wait_for()
 page.get_by_role('heading',name=item['name']).wait_for()
 assert not external and not errors,(external,errors)
 print('RELEASE UI OK: direct hash / pasted URL / link interception / back, no external navigation',flush=True)
 browser.close()
