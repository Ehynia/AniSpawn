'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {normalizeUpscale,targetSize,DEFAULTS,MODES}=require('../renderer/upscale.js');
const {createStore,clean}=require('../src/core/store.cjs');
test('upscaler defaults to disabled and does not run without user permission',()=>{
 assert.deepEqual(normalizeUpscale(),DEFAULTS);assert.equal(normalizeUpscale().enabled,false);
});
test('validates mode, scale, and strength',()=>{
 assert.deepEqual(normalizeUpscale({enabled:'true',mode:'unsupported',scale:7,strength:-4}),{...DEFAULTS,strength:0});
 assert.deepEqual(normalizeUpscale({enabled:true,mode:'anime',scale:'2',strength:8}),{enabled:true,mode:'anime',scale:2,strength:1});
 assert.equal(MODES.length,4);
});
test('ignores non-finite sharpness and scales',()=>{
 assert.deepEqual(normalizeUpscale({scale:Infinity,strength:NaN}),DEFAULTS);
 assert.equal(normalizeUpscale({scale:null}).scale,DEFAULTS.scale);
});
test('render output holds original aspect ratio and expected 2x size',()=>{
 const r=targetSize(640,360,640,360,1,2);assert.deepEqual(r,{width:1280,height:720});
 assert.deepEqual(targetSize(1920,1080,640,360,1,2),{width:3840,height:2160});
});
test('caps output to UHD and respects GL texture limitations',()=>{
 const a=targetSize(1920,1080,1280,720,2,2,2048);assert.equal(a.width,2048);assert.equal(a.height,1152);
 const b=targetSize(8000,4000,1200,600,1,2);assert.ok(b.width<=3840&&b.height<=2160&&b.width*b.height<=3840*2160);
});
test('protects target calculations from invalid dimensions',()=>{
 assert.deepEqual(targetSize(0,0,100,100,1,2),{width:0,height:0});
 assert.deepEqual(targetSize(NaN,360,100,100,1,2),{width:0,height:0});
});
test('upscale settings persist to disk and sanitize on reload',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'anispawn-upscale-'));
 try{
  const filename=path.join(dir,'state.json');const store=createStore(filename);
  store.patch({upscale:{enabled:true,mode:'anime',scale:2,strength:0.66}});
  assert.deepEqual(createStore(filename).get().upscale,{enabled:true,mode:'anime',scale:2,strength:0.66});
  assert.deepEqual(clean({upscale:{enabled:true,mode:'bad',scale:10,strength:5}}).upscale,{enabled:true,mode:'balanced',scale:1.5,strength:1});
 }finally{fs.rmSync(dir,{recursive:true,force:true})}
});
test('upscale module does not touch DOM when imported in Node',()=>{
 const shader=fs.readFileSync(path.join(__dirname,'../renderer/upscale.js'),'utf8');
 assert.match(shader,/precision highp float/);assert.match(shader,/lanczos/);assert.match(shader,/getContext\('webgl2'/);
 assert.doesNotMatch(shader,/https?:\/\//);
});
