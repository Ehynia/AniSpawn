"""Offline account login UI smoke, mock service only."""
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]/'renderer'
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
    page=browser.new_page(viewport={'width':1400,'height':900})
    errors=[]
    page.on('pageerror',lambda error:errors.append(str(error)))
    html=(R/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','http-equiv="X-Test-CSP-Disabled"').replace('<script defer src=','<script data-src=').replace('<link rel="stylesheet" href=','<link rel="stylesheet" data-href=')
    page.set_content(html,wait_until='domcontentloaded')
    page.add_style_tag(content=(R/'styles.css').read_text())
    page.add_script_tag(content=(R/'upscale.js').read_text())
    page.evaluate('''() => {
        window.__accounts={login:false,calls:[]};
        window.anispawn={
        getState:async()=>window.__accounts.current||({source:'libria',theme:'dark',quality:'1080',bookmarks:[],history:[],volume:.8}),
        list:async()=>({items:[],stale:false}),sources:async()=>[],
        accountProviders:async()=>[{id:'anixart',name:'Anixart',available:!window.__accounts.login,description:'Вход',user:window.__accounts.login?{name:'Demo',id:99}:null},{id:'yani',name:'Yani',available:false,description:'Нет X-Application',user:null}],
        accountLogin:async(provider,login,password)=>{window.__accounts.calls.push({provider,login,password});window.__accounts.login=true;return {name:'Demo',id:99}},
        accountLogout:async()=>{window.__accounts.login=false;return true},
        accountLibrary:async()=>window.__accounts.login?{items:[{id:'anixart:123',name:'Блич',status:'Смотрю'}],stale:false,name:'Demo'}:{items:[],stale:true},
        syncStatus:async()=>({bookmarks:window.__accounts.login?1:0,history:0,pending:0}),
        syncAll:async()=>{window.__accounts.current={source:'libria',theme:'dark',quality:'1080',bookmarks:[{id:'anixart:123',name:'Блич',status:'Смотрю',statusId:1,remoteAccount:'anixart',image:'',year:''}],history:[]};return {providers:{anixart:{connected:true,status:'Синхронизировано'}},pending:0}},
        setListStatus:async(item,status)=>({bookmarks:window.__accounts.current.bookmarks.map(x=>({...x,statusId:status}))}),
        accountLibraryPath:async()=>'/home/test/.config/AniSpawn/account-libraries.txt',
        updateState:async x=>x,recordWatch:async()=>[],historyInfo:async()=>({}),chooseVideo:async()=>null,
        configureKodik:async()=>{}, health:async()=>({ok:true})
        };
    }''')
    page.add_script_tag(content=(R/'accounts-ui.js').read_text())
    page.add_script_tag(content=(R/'app.js').read_text())
    page.locator('[data-view="accounts"]').click()
    page.locator('#account-providers button',has_text='Войти').first.click()
    assert page.locator('#account-login-modal').is_visible()
    page.locator('#account-login-name').fill('demo')
    page.locator('#account-login-password').fill('secret')
    page.locator('#account-login-submit').click()
    page.wait_for_function('window.__accounts.login === true')
    page.wait_for_timeout(150)
    page.locator('#account-open-library').click()
    page.wait_for_function("document.querySelector('#bookmark-grid').textContent.includes('Блич')")
    assert 'Блич' in page.locator('#bookmark-grid').inner_text()
    assert page.locator('#account-login-password').input_value()==''
    assert len(page.evaluate('window.__accounts.calls'))==1
    assert not errors,errors
    page.screenshot(path='/mnt/data/AniSpawn-Accounts-SMOKE.png')
    browser.close()
    print('Account UI smoke OK: login, unified library, password cleared, no errors')
