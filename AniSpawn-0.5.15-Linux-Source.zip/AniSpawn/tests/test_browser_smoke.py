from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]/'renderer'
fixture={"id":"libria:8452","source":"libria","remoteId":"8452","name":"Блич","original":"Bleach","image":"","description":"Каталог тест","year":2004,"rating":8.5,"episodesTotal":2,"category":"TV","playable":True,"blocked":False,"url":"https://anilibria.top/anime/releases/8452"}
from json import dumps
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 page=browser.new_page(viewport={'width':1400,'height':900})
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 print('setup',flush=True);page.set_content((R/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','http-equiv="X-Test-CSP-Disabled"').replace('<script defer src=', '<script data-src=').replace('<link rel="stylesheet" href=', '<link rel="stylesheet" data-href='), wait_until='domcontentloaded', timeout=5000)
 print('DOM set',flush=True);page.add_style_tag(content=(R/'styles.css').read_text())
 print('CSS set',flush=True);page.add_script_tag(content=(R/'upscale.js').read_text())
 page.evaluate('''d => {
 window.anispawn={
 getState:async()=>({source:'libria',theme:'dark',quality:'1080',bookmarks:[],history:[],volume:.8,upscale:{enabled:false,mode:'balanced',scale:1.5,strength:.45}}),
 list:async()=>({items:[d],stale:false}),
 search:async()=>({items:[d],stale:false}),
 details:async()=>({...d,episodes:[{id:'1',ordinal:1,name:'Эпизод 1',quality:{'720':'https://example.com/a.m3u8'}}]}),
 sources:async()=>[{id:'libria',name:'AniLiberty',kind:'video',description:'Тест'}],
 health:async()=>({ok:true,ms:1}),
 updateState:async v=>v,
 toggleBookmark:async v=>({added:true,bookmarks:[v]}),
 recordWatch:async v=>[v],
 prepareStream:async u=>u,
 chooseVideo:async()=>null,
 openExternal:async()=>{},
 configureKodik:async()=>({configured:true})
 }
}''',fixture)
 print('API mocked',flush=True);page.add_script_tag(content=(R/'app.js').read_text())
 print('script loaded',flush=True);page.wait_for_timeout(400)
 assert page.locator('#catalog-grid').inner_text().count('Блич')>=1, page.locator('#catalog-grid').inner_text()
 assert 'API' not in page.locator('#status-text').inner_text(),page.locator('#status-text').inner_text()
 print('catalog loaded',flush=True);page.locator('[data-view="settings"]').click(timeout=3000)
 assert page.locator('#view-settings').is_visible()
 page.locator('#setting-theme').select_option('light')
 page.locator('#save-settings').click()
 assert 'theme-light' in page.locator('body').get_attribute('class')
 page.locator('[data-view="home"]').first.click()
 page.screenshot(path='/mnt/data/AniSpawn-UI-SMOKE.png',full_page=True)
 print('GUI smoke passed: navigation, catalog, theme, JavaScript errors:',errors)
 assert not errors,errors
 browser.close()
