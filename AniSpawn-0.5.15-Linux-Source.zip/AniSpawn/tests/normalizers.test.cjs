'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');
const N=require('../src/core/normalize.cjs');
test('normalize AniLiberty release and poster',()=>{const r=N.normLib({id:123,name:{main:'Тест'},poster:{optimized:{preview:'/post.webp'}},episodes_total:8},'https://anilibria.top/api/v1');assert.equal(r.id,'libria:123');assert.equal(r.name,'Тест');assert.equal(r.image,'https://anilibria.top/post.webp');});
test('extract 1080 HLS stream from current API',()=>{const eps=N.episodesLib({episodes:[{ordinal:1,name:'Первая',hls_1080:'https://cdn.example.com/ep1.m3u8'}]});assert.equal(eps.length,1);assert.equal(eps[0].quality['1080'],'https://cdn.example.com/ep1.m3u8');});
test('extract older embedded HLS format',()=>{const eps=N.episodesLib({player:{list:{'1':{episode:1,hls:{hd:'/videos/x.m3u8'}}}}},'https://anilibria.top');assert.equal(eps[0].quality['720'],'https://anilibria.top/videos/x.m3u8');});
test('block non-http poster scheme',()=>{const r=N.normLib({id:1,name:'x',poster:'javascript:alert(1)'});assert.equal(r.image,'')});
test('normalize AniList rating',()=>{assert.equal(N.normAniList({id:3,title:{romaji:'Test'},averageScore:84}).rating,8.4)});
test('normalize search response shapes',()=>{assert.deepEqual(N.list({data:{releases:[{id:1}]}}),[{id:1}])});
