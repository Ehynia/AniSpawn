'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const {createHlsProxy}=require('../src/core/hls-proxy.cjs');
test('rewrites media playlist without HTTP server',async()=>{const proxy=createHlsProxy(async()=>new Response('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="key.key"\nseg01.ts\nhttps://cdn2.test/seg02.ts',{status:200,headers:{'content-type':'application/vnd.apple.mpegurl'}}));const url=proxy.register('https://video.test/path/playlist.m3u8');const result=await proxy.handle(new Request(url));const body=await result.text();assert.equal(result.status,200);assert.equal((body.match(/anispawn-stream:\/\/media\//g)||[]).length,3);});
test('reject arbitrary request token',async()=>{const proxy=createHlsProxy(async()=>{});const resp=await proxy.handle(new Request('anispawn-stream://media/fake'));assert.equal(resp.status,404)});
test('reject unsafe media scheme',()=>assert.throws(()=>createHlsProxy().register('file:///etc/passwd'),/HTTPS/));
