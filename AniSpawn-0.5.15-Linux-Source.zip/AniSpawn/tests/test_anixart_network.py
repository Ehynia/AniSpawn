"""No live network required: verify bounded mirror fallback and offline release view."""
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import urllib.error
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'desktop'))
import anixart_network as api
import accounts
import server

class Response:
    def __init__(self, result):self.status=200;self.payload=json.dumps(result).encode('utf8')
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def read(self,n=-1):return self.payload[:n]

class AnixartNetworkTests(unittest.TestCase):
    def setUp(self):
        api._preferred=None;api._preferred_until=0

    def test_tls_timeout_switches_to_published_mirror(self):
        with patch.object(api,'_open',side_effect=[TimeoutError('SSL handshake operation timed out'),Response({'code':0,'release':{'id':2563}})]) as fetch:
            result=api.request_json(api.HOSTS[0]+'/release/2563?token=PRIVATE',timeout=2)
        self.assertEqual(result['release']['id'],2563)
        self.assertTrue(fetch.call_args_list[0].args[0].full_url.startswith(api.HOSTS[0]))
        self.assertTrue(fetch.call_args_list[1].args[0].full_url.startswith(api.HOSTS[1]))
        self.assertEqual(fetch.call_count,2)

    def test_after_success_prefer_working_mirror(self):
        with patch.object(api,'_open',side_effect=[TimeoutError(),Response({'code':0}),Response({'code':0})]) as fetch:
            api.request_json(api.HOSTS[0]+'/release/1')
            api.request_json(api.HOSTS[0]+'/release/2')
        self.assertTrue(fetch.call_args_list[2].args[0].full_url.startswith(api.HOSTS[1]))

    def test_error_never_leaks_token_or_password(self):
        with patch.object(api,'_open',side_effect=urllib.error.URLError('token=PRIVATE_password=SECRET')) as fetch:
            with self.assertRaises(api.ApiUnavailable) as context:
                api.request_json(api.HOSTS[0]+'/release/8?token=PRIVATE')
        self.assertEqual(fetch.call_count,2)
        self.assertNotIn('PRIVATE',str(context.exception))
        self.assertNotIn('SECRET',str(context.exception))

    def test_http_403_not_bypassed_with_alt_host(self):
        err=urllib.error.HTTPError(api.HOSTS[0]+'/release/2',403,'Forbidden',{},None)
        with patch.object(api,'_open',side_effect=err) as fetch:
            with self.assertRaisesRegex(api.ApiResponseError,'403'):
                api.request_json(api.HOSTS[0]+'/release/2')
        fetch.assert_called_once()

    def test_only_verified_hosts_and_https(self):
        with patch.object(api,'_open') as fetch:
            for link in ('http://api.anixsekai.com/release/2','https://api.anixsekai.com.evil.com/release/2','https://api.anixsekai.com:444/release/2','https://me:pass@api.anixsekai.com/release/2','https://api.anixsekai.com//example.com'):
                with self.subTest(link=link),self.assertRaises(ValueError):api.request_json(link)
            fetch.assert_not_called()

    def test_backend_uses_same_transport_as_account_login(self):
        with patch.object(api,'request_json',return_value={'code':0}) as fetch:
            self.assertEqual(server.fetch_json(api.HOSTS[0]+'/release/123'),{'code':0})
            self.assertEqual(accounts.service_json(accounts.ANIXART_BASE,'/release/123'),{'code':0})
        self.assertEqual(fetch.call_count,2)

    def test_cached_anixart_card_stays_open_offline(self):
        with tempfile.TemporaryDirectory() as directory, patch.dict(os.environ,{'XDG_CACHE_HOME':directory}):
            backend=server.Backend(directory)
            original={'code':0,'release':{'id':2563,'title_ru':'О моём перерождении в слизь','description':'Публичные данные'}}
            with patch.object(backend,'_anixart',side_effect=[original,{'code':0,'types':[]}]):
                item=backend.details('anixart:2563')
            self.assertEqual(item['name'],'О моём перерождении в слизь')
            with patch.object(backend,'_anixart',side_effect=api.ApiUnavailable('Anixart временно недоступен')):
                offline=backend.details('anixart:2563')
            self.assertEqual(offline['name'],item['name'])
            self.assertTrue(offline['stale'])
            self.assertEqual(offline['dubs'],[])
            self.assertNotIn('token',backend._anixart_detail_file('2563').read_text())

    def test_unseen_release_fallback_does_not_claim_playback(self):
        with tempfile.TemporaryDirectory() as directory, patch.dict(os.environ,{'XDG_CACHE_HOME':directory}):
            backend=server.Backend(directory)
            with patch.object(backend,'_anixart',side_effect=api.ApiUnavailable('timeout')):
                item=backend.details('anixart:2563')
            self.assertEqual(item['name'],'Релиз Anixart №2563')
            self.assertTrue(item['stale'])
            self.assertEqual(item['dubs'],[])

if __name__=='__main__':unittest.main()

class AnixartConnectivityDiagnosisTests(unittest.TestCase):
    def test_tls_timeout_and_second_working_host_reported_separately(self):
        with patch.object(api, '_open', side_effect=[TimeoutError('TLS timed out'), Response({'code':0,'release':{'id':2563}})]) as fetch:
            report=api.diagnose(timeout=2)
        self.assertTrue(report['available'])
        self.assertFalse(report['hosts'][0]['tls'])
        self.assertTrue(report['hosts'][1]['tls'])
        self.assertTrue(report['hosts'][1]['api'])
        self.assertEqual(fetch.call_count,2)
        for c in fetch.call_args_list:
            self.assertNotIn('token',c.args[0].full_url)

    def test_403_is_https_connection_not_successful_api(self):
        err=urllib.error.HTTPError(api.HOSTS[0]+'/release/2563',403,'Forbidden',{},None)
        with patch.object(api,'_open',side_effect=[err, TimeoutError()]):
            report=api.diagnose(timeout=2)
        self.assertFalse(report['available'])
        self.assertTrue(report['connected'])
        self.assertTrue(report['hosts'][0]['tls'])
        self.assertEqual(report['hosts'][0]['http'],403)
        self.assertFalse(report['hosts'][0]['api'])
