const test=require('node:test');
const assert=require('node:assert/strict');
const router=require('../renderer/release-router.js');
test('canonical Anixart links become native routes',()=>{
 const r=router.parse('https://anixart-app.com/release/2563');
 assert.deepEqual(r,{source:'anixart',id:'anixart:2563',remoteId:'2563',href:'https://anixart-app.com/release/2563',hash:'#/release/anixart/2563'});
 assert.deepEqual(router.fromHash('#/release/anixart/2563'),r);
});
test('recognizes supported Anixart legacy host names, numeric IDs and trailing slash',()=>{
 for(const input of ['https://mirror.anixart-app.com/release/2563/', 'https://anixart.app/release/2563','anixart:2563','2563','https://anixart.tv/release/2563?ref=test'])
 assert.equal(router.parse(input)?.id,'anixart:2563');
});
test('does not accept untrusted domain, scheme, ports or path confusion',()=>{
 for(const input of ['https://anixart-app.com.evil.example/release/2563','https://evil.example/anixart-app.com/release/2563','http://anixart-app.com/release/2563','https://anixart-app.com:8443/release/2563','https://username:password@anixart-app.com/release/2563','https://anixart-app.com/release/2563/extra','javascript:alert(1)','/release/2563','anixart:0','anixart:2563:extra','https://anixart-app.com/release/%32%35%36%33'])
 assert.equal(router.parse(input),null,input);
});
test('release router can be imported by Node without document/window',()=>{
 assert.equal(router.fromHash('#/release/anixart/2563/'),null);
});
