"""Offline video provider UI test with mocked catalog/player API (no secret or internet)."""
from pathlib import Path
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1]/'renderer'
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-gpu'])
 page=browser.new_page(viewport={'width':1500,'height':950})
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 html=(R/'index.html').read_text().replace('http-equiv="Content-Security-Policy"','http-equiv="X-Test-CSP-Disabled"').replace('<script defer src=', '<script data-src=').replace('<link rel="stylesheet" href=', '<link rel="stylesheet" data-href=')
 page.set_content(html,wait_until='domcontentloaded')
 page.add_style_tag(content=(R/'styles.css').read_text())
 page.add_script_tag(content=(R/'upscale.js').read_text())
 page.evaluate('''() => {
 const mikai={id:'mikai:15',source:'mikai',name:'Аниме Mikai',image:'',year:2025,category:'TV',episodesTotal:24,blocked:false};
 const anixart={id:'anixart:18',source:'anixart',name:'Аниме Anixart',image:'',year:2024,category:'TV',episodesTotal:12,blocked:false};
 window.__mock={source:'mikai',externalCalls:0};
 window.anispawn={
 getState:async()=>({source:'mikai',theme:'dark',quality:'1080',bookmarks:[],history:[],volume:.8}),
 list:async source=>({items:source==='mikai'?[mikai]:[anixart],stale:false}),
 search:async source=>({items:source==='mikai'?[mikai]:[anixart],stale:false}),
 details:async id=>id.startsWith('mikai')?{...mikai,description:'Украинская озвучка',credits:'Mikai',players:[{name:'Команда 1 · Moon',episode:'1',embed:'https://moon.video/embed/1',linkToken:'key1'}],episodes:[]}:{...anixart,description:'Русская озвучка',dubs:[{id:3,name:'StudioBand',sub:false}],episodes:[]},
 findPlayers:async()=>[{name:'Kodik · Перевод',episode:'1',embed:'https://kodik.info/a',linkToken:'key2'}],
 anixartSources:async()=>[{id:4,name:'Kodik',count:1}],
 anixartEpisodes:async()=>[{name:'Серия 1',episode:'1',embed:'https://kodik.info/a',linkToken:'key3'}],
 openPlayer:async()=>{window.__mock.externalCalls++;return true},
 sources:async()=>[],health:async()=>({ok:true}),
 updateState:async s=>s,recordWatch:async()=>[],historyInfo:async()=>({}),chooseVideo:async()=>null,configureKodik:async()=>true
 };
}''')
 page.add_script_tag(content=(R/'app.js').read_text())
 page.wait_for_timeout(160)
 page.locator('#catalog-grid .anime-card').first.click()
 page.locator('#episode-list .episode-row').first.wait_for()
 assert 'Команда 1' in page.locator('#episode-list').inner_text()
 page.locator('#detail-kinobox').click()
 assert 'Kodik · Перевод' in page.locator('#detail-kinobox-results').inner_text()
 page.locator('#episode-list button',has_text='Смотреть').first.click()
 assert page.locator('#embed-player').is_visible()
 assert 'moon.video' in page.locator('#embed-player').get_attribute('src')
 page.locator('#player-close').click()
 page.locator('#source-select').select_option('anixart')
 page.wait_for_function("document.querySelector('#catalog-grid')?.textContent.includes('Аниме Anixart')")
 page.locator('#catalog-grid .anime-card').first.click()
 page.locator('.provider-controls select').first.wait_for()
 page.wait_for_function("document.querySelectorAll('.provider-episodes .episode-row').length > 0")
 assert 'Серия 1' in page.locator('.provider-episodes').inner_text()
 assert not errors,errors
 page.screenshot(path='/mnt/data/AniSpawn-Video-Sources-SMOKE.png')
 print('VIDEO UI OK: Mikai -> iframe, Kinobox -> player, Anixart -> voice/source/episode')
 browser.close()
