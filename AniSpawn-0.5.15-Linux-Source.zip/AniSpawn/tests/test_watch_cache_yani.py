"""Regression tests for AniSpawn 0.5.3 player, Yani and user-readable cache."""
import json
from pathlib import Path
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch
from urllib.request import urlopen, Request
from urllib.error import HTTPError
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'desktop'))
import server

class WatchedTextTests(unittest.TestCase):
 def setUp(self):
  self.home=tempfile.TemporaryDirectory()
  self.old_cache=server.os.environ.get('XDG_CACHE_HOME')
  server.os.environ['XDG_CACHE_HOME']=self.home.name
  self.b=server.Backend(self.home.name)
 def tearDown(self):
  if self.old_cache is None:server.os.environ.pop('XDG_CACHE_HOME',None)
  else:server.os.environ['XDG_CACHE_HOME']=self.old_cache
  self.home.cleanup()
 def test_txt_history_is_readable_and_survives_restart(self):
  self.b.watched({'id':'libria:55','episode':'2','name':'Тестовое аниме'})
  self.b.update_progress({'id':'libria:55','episode':'2','position':125,'duration':600})
  data=self.b.history_txt.read_text(encoding='utf8')
  self.assertIn('Тестовое аниме',data)
  self.assertIn('Прогресс: 125 / 600 сек',data)
  self.assertIn('libria:55',self.b.history_events.read_text(encoding='utf8'))
  self.assertIn('Тестовое аниме',server.Backend(self.home.name).history_txt.read_text(encoding='utf8'))
 def test_yani_token_is_memory_only_and_headers_correct(self):
  self.b.call('configureYani',['personal_test_token'])
  with patch.object(server,'fetch_json',return_value={'response':[{'anime_id':12,'title':'Аниме','poster':{'big':'https://cdn.example/p.png'}}]}) as call:
   found=self.b.catalog('yani',query='аниме')
   self.assertEqual(found[0]['id'],'yani:12')
   self.assertIn('X-Application',call.call_args.kwargs['headers'])
   self.assertEqual(call.call_args.kwargs['headers']['X-Application'],'personal_test_token')
  self.assertNotIn('personal_test_token',self.b.state_file.read_text() if self.b.state_file.exists() else '')
 def test_yani_video_iframe_allowlist(self):
  self.assertTrue(server.safe_embed('https://video.sibnet.ru/shell.php?videoid=1'))
  self.assertFalse(server.safe_embed('https://evil.com/kodik.info/play'))
  self.assertFalse(server.safe_embed('javascript:alert(1)'))
  self.b.call('configureYani',['token'])
  fake={'anime_id':123,'title':'Test','poster':{},'videos':[{'iframe_url':'https://kodik.info/serial/1','number':'3','data':{'dubbing':'Озвучка'}},{'iframe_url':'https://attacker.example/evil','number':'2'}]}
  with patch.object(self.b,'yani',return_value=fake):
   detail=self.b.details('yani:123')
  self.assertEqual(len(detail['players']),1)
  self.assertEqual(detail['players'][0]['name'],'Озвучка')
 def test_video_cache_index_survives_restart(self):
  link='https://example.com/allowed.m3u8';self.b.valid_streams[link]=server.time.time()
  file=self.b.cache_path(link);file.write_bytes(b'12345678')
  result=self.b.queue_cache(link,{'id':'libria:55','name':'Тест','episode':'7','quality':'720'})
  self.assertEqual(result['status'],'cached')
  clips=server.Backend(self.home.name).cached_videos()
  self.assertEqual(clips[0]['episode'],'7')
  self.assertEqual(clips[0]['quality'],'720')
 def test_download_worker_produces_indexed_offline_file(self):
  fake=Path(self.home.name)/'fake-ffmpeg'
  fake.write_text('#!/usr/bin/env python3\nimport pathlib,sys\np=pathlib.Path(sys.argv[-1]);p.write_bytes(b"0"*2048)\n')
  fake.chmod(0o755);self.b.ffmpeg=str(fake)
  url='https://example.com/test-approved-hls.m3u8';self.b.valid_streams[url]=time.time()
  self.b.queue_cache(url,{'id':'libria:22','episode':'4','name':'Тест','quality':'480'})
  for _ in range(80):
   if self.b.video_status(url)['status']!='downloading':break
   time.sleep(.03)
  self.assertEqual(self.b.video_status(url)['status'],'cached')
  self.assertEqual(self.b.cached_videos()[0]['episode'],'4')
 def test_bad_progress_rejected(self):
  with self.assertRaises(ValueError):self.b.update_progress({'id':'libria:1','episode':'1','position':float('nan'),'duration':100})

class RangeTests(unittest.TestCase):
 def setUp(self):
  self.home=tempfile.TemporaryDirectory()
  self.old_cache=server.os.environ.get('XDG_CACHE_HOME');server.os.environ['XDG_CACHE_HOME']=self.home.name
  self.backend=server.Backend(self.home.name)
  self.s=server.Server(('127.0.0.1',0),self.backend)
  self.thread=threading.Thread(target=self.s.serve_forever,daemon=True);self.thread.start()
 def tearDown(self):
  self.s.shutdown();self.s.server_close()
  if self.old_cache is None:server.os.environ.pop('XDG_CACHE_HOME',None)
  else:server.os.environ['XDG_CACHE_HOME']=self.old_cache
  self.home.cleanup()
 def test_cached_video_returns_http_206(self):
  link='https://example.com/approved.m3u8';self.backend.valid_streams[link]=server.time.time()
  self.backend.cache_path(link).write_bytes(b'0123456789abcdef')
  self.backend.queue_cache(link,{'id':'libria:22','episode':'1','name':'Тест','quality':'720'})
  token=self.backend.open_cached(self.backend.cache_key(link))
  url=f'http://127.0.0.1:{self.s.server_port}{self.s.prefix}media/{token}.mp4'
  request=Request(url,headers={'Range':'bytes=3-8'})
  with urlopen(request,timeout=5) as resp:
   self.assertEqual(resp.status,206)
   self.assertEqual(resp.headers['Content-Range'],'bytes 3-8/16')
   self.assertEqual(resp.read(),b'345678')
 def test_invalid_seek_rejected_without_running_ffmpeg(self):
  link='https://example.com/approved.m3u8';self.backend.valid_streams[link]=server.time.time()
  token=self.backend.prepare(link)
  url=f'http://127.0.0.1:{self.s.server_port}{self.s.prefix}media/{token}.mp4?start=nan'
  with self.assertRaises(HTTPError) as err:urlopen(url,timeout=5)
  self.assertEqual(err.exception.code,400)

if __name__=='__main__':unittest.main()
