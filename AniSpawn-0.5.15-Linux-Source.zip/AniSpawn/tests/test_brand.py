import pathlib
import struct
import unittest
from PIL import Image

ROOT = pathlib.Path(__file__).resolve().parents[1]
ART = ROOT / 'renderer' / 'assets'

class BrandingTests(unittest.TestCase):
    def test_icons_all_sizes_are_valid(self):
        for size in (16, 32, 48, 64, 128, 256, 512):
            p = ART / f'icon-{size}.png'
            with self.subTest(icon=p.name), Image.open(p) as im:
                self.assertEqual(im.size, (size, size))
                self.assertEqual(im.format, 'PNG')
                self.assertLessEqual(im.getpixel((0, 0))[-1], 8)

    def test_local_webp_and_origins(self):
        for name in ('mascot-full.webp','logo-full.webp','mascot-original.png','logo-original.png'):
            self.assertTrue((ART / name).is_file())
        with Image.open(ART/'mascot-full.webp') as im:
            self.assertGreater(im.width, 800)

    def test_renderer_uses_own_images(self):
        html = (ROOT/'renderer/index.html').read_text()
        for name in ('icon-64.png','icon-32.png','mascot-full.webp','icon-128.png'):
            self.assertIn(f'./assets/{name}', html)
        self.assertIn('class="hero mascot-branded"',html)
        css=(ROOT/'renderer/styles.css').read_text()
        self.assertIn('prefers-reduced-motion:reduce',css)

    def test_build_uses_hicolor_icon_and_new_version(self):
        script=(ROOT/'scripts/package-standalone-linux.py').read_text()
        self.assertIn('Version: 0.5.15',script)
        self.assertIn('Icon=anispawn',script)
        self.assertIn("f'usr/share/icons/hicolor/{n}x{n}/apps'",script)

if __name__=='__main__': unittest.main()
