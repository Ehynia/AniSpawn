'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const os=require('node:os');const path=require('node:path');
const {createStore,clean}=require('../src/core/store.cjs');
test('persist bookmarks and history',()=>{const dir=fs.mkdtempSync(path.join(os.tmpdir(),'anispawn-'));try{const p=path.join(dir,'s.json');const s=createStore(p);const b={id:'libria:44',name:'Тайтл'};assert.equal(s.bookmark(b).added,true);assert.equal(s.bookmark(b).added,false);s.bookmark(b);s.watched({id:'libria:44',episode:'1',name:'Тайтл'});assert.equal(createStore(p).get().bookmarks.length,1);assert.equal(createStore(p).get().history.length,1);}finally{fs.rmSync(dir,{recursive:true,force:true})}});
test('sanitize state and bad values',()=>{const c=clean({source:'evil',bookmarks:[{id:'evil:1'}],theme:'custom',volume:42});assert.equal(c.source,'libria');assert.deepEqual(c.bookmarks,[]);assert.equal(c.volume,1)});
