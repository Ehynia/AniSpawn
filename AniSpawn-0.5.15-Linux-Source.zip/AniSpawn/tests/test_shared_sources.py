import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'desktop'))
import server
import shared_sources as merger

A = {'id':'anixart:2563','source':'anixart','name':'О моём перерождении в слизь','original':'Tensei Shitara Slime Datta Ken','year':2018,'blocked':False}
L = {'id':'libria:345','source':'libria','name':'О моём перерождении в слизь','original':'Tensei Shitara Slime Datta Ken','year':2018,'episodesTotal':24}

class MatchRules(unittest.TestCase):
 def test_exact_title_and_separate_remote_ids(self):
  got=merger.group_catalog([A],[L]);self.assertEqual(len(got),1)
  self.assertEqual(got[0]['id'],A['id']);self.assertEqual(got[0]['alternatives'][0]['id'],L['id'])
  self.assertEqual(got[0]['availableSources'],['anixart','libria'])
 def test_yo_punctuation_case(self):
  self.assertEqual(merger.canonical_title('СЛИЗЬ / Ёж'), 'слизь еж')
 def test_year_mismatch_never_auto_groups(self):
  other={**L,'year':2021};self.assertIsNone(merger.compare(A,other))
  self.assertEqual(len(merger.group_catalog([A],[other])),2)
 def test_different_season_not_matched(self):
  s2={**L,'name':'О моём перерождении в слизь 2 сезон','original':'Tensei Shitara Slime Datta Ken Season 2','year':2021}
  self.assertIsNone(merger.compare(A,s2))
 def test_fuzzy_candidate_does_not_automerge(self):
  similar={**L,'name':'О моём перерождении в слизь!','original':'Some other name'}
  self.assertNotEqual(merger.compare(A,similar),'suggested') # punctuation-only exact
  typo={**L,'name':'О моем перерождении в слизях','original':'Unrelated'}
  self.assertEqual(merger.compare(A,typo),'suggested')
  self.assertEqual(len(merger.group_catalog([A],[typo])),2)
  self.assertEqual(merger.suggestions(A,[typo])[0]['match'],'suggested')
 def test_no_cross_service_joins_between_equal_ids(self):
  self.assertIsNone(merger.compare(A,{**A,'id':'anixart:999'}))

class BackendJoinedTests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.cache=tempfile.TemporaryDirectory()
  self.patch=patch.dict(os.environ,{'XDG_CACHE_HOME':self.cache.name});self.patch.start()
  self.backend=server.Backend(self.t.name)
 def tearDown(self):self.patch.stop();self.cache.cleanup();self.t.cleanup()
 def test_new_install_defaults_to_both(self):self.assertEqual(self.backend.state['source'],'all')
 def test_both_catalog_merges_and_propagates_page(self):
  calls=[]
  def fake(source,page,query=''):
   calls.append((source,page,query));return [A] if source=='anixart' else [L]
  with patch.object(self.backend,'catalog',side_effect=fake):
   result=self.backend.call('search',['both','слизь',3])
  self.assertEqual(result['items'][0]['id'],'anixart:2563')
  self.assertEqual(set(calls),{('anixart',3,'слизь'),('libria',3,'слизь')})
  self.assertFalse(result['stale'])
 def test_partial_outage_keeps_other_source(self):
  def fake(source,page,query=''):
   if source=='anixart':raise RuntimeError('TLS failed')
   return [L]
  with patch.object(self.backend,'catalog',side_effect=fake):
   result=self.backend.call('list',['both',1])
  self.assertEqual([x['id'] for x in result['items']],['libria:345'])
  self.assertTrue(result['stale']);self.assertIn('TLS failed',result['warning'])
 def test_related_sources_exact_and_no_credentials(self):
  with patch.object(self.backend,'catalog',return_value=[L]) as fetch:
   result=self.backend.call('relatedSources',['anixart:2563',A['name'],A['original'],2018])
  self.assertEqual(result['items'][0]['match'],'exact')
  self.assertEqual(result['items'][0]['id'],'libria:345')
  fetch.assert_called_once()
 def test_related_foreign_year_not_matched(self):
  with patch.object(self.backend,'catalog',return_value=[{**L,'year':2019}]):
   result=self.backend.call('relatedSources',['anixart:2563',A['name'],A['original'],2018])
  self.assertFalse(result['items'])
 def test_readonly_cache_after_service_dropout(self):
  with patch.object(self.backend,'catalog',return_value=[L]):
   first=self.backend.call('relatedSources',['anixart:2563',A['name'],A['original'],2018])
  with patch.object(self.backend,'catalog',side_effect=RuntimeError('offline')):
   second=self.backend.call('relatedSources',['anixart:2563',A['name'],A['original'],2018])
  self.assertEqual(first['items'],second['items']);self.assertTrue(second['stale'])
 def test_bad_ids_cannot_trigger_network(self):
  for id_ in ('http://127.0.0.1','../../passwd','kodik:33','anixart:'):
   with self.subTest(id_=id_),self.assertRaises(ValueError):self.backend.related_sources(id_,'Тайтл')
 def test_page_contains_joined_controls(self):
  root=Path(__file__).resolve().parents[1]
  html=(root/'renderer/index.html').read_text();js=(root/'renderer/app.js').read_text()
  self.assertIn('value="both"',html)
  self.assertIn('id="detail-integrated-results"',html)
  self.assertIn('loadRelatedSources',js)
  self.assertIn('relatedSources:(id', (root/'renderer/desktop-bridge.js').read_text())

if __name__=='__main__':unittest.main()
