'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const os=require('node:os');const path=require('node:path');
const {createLocalMedia,rangeFor}=require('../src/core/local-media.cjs');
test('parse seeking ranges and suffix requests',()=>{
 assert.deepEqual(rangeFor('bytes=5-9',100),{start:5,end:9});
 assert.deepEqual(rangeFor('bytes=9-',100),{start:9,end:99});
 assert.deepEqual(rangeFor('bytes=-10',100),{start:90,end:99});
 assert.deepEqual(rangeFor('bytes=0-900',100),{start:0,end:99});
 assert.equal(rangeFor('bytes=100-101',100),null);
 assert.equal(rangeFor('bytes=5-1',100),null);
 assert.equal(rangeFor('bytes=0-4,6-10',100),null);
});
test('serve only picker-approved video with Range and CORS headers',async()=>{
 const directory=fs.mkdtempSync(path.join(os.tmpdir(),'anispawn-media-'));
 try{const file=path.join(directory,'source.webm');fs.writeFileSync(file,Buffer.from('0123456789'));const local=createLocalMedia();const url=local.register(file);
  const full=await local.handle(new Request(url));assert.equal(full.status,200);assert.equal(await full.text(),'0123456789');assert.equal(full.headers.get('access-control-allow-origin'),'*');
  const part=await local.handle(new Request(url,{headers:{Range:'bytes=2-5'}}));assert.equal(part.status,206);assert.equal(await part.text(),'2345');assert.equal(part.headers.get('content-range'),'bytes 2-5/10');
  const invalid=await local.handle(new Request(url,{headers:{Range:'bytes=100-101'}}));assert.equal(invalid.status,416);
  const privateFile=await local.handle(new Request('anispawn-local://media/unknown'));assert.equal(privateFile.status,404);
  assert.throws(()=>local.register(path.join(directory,'secret.txt')),/формат/);
 }finally{fs.rmSync(directory,{force:true,recursive:true})}
});
