'use strict';
const {test}=require('node:test');const assert=require('node:assert/strict');
const {createProviders}=require('../src/core/providers.cjs');
function fakeFetch(url,opts){if(String(url).includes('/app/search/releases?'))return Promise.resolve({ok:true,json:async()=>[{id:22,name:{main:'Найдено'}}]});
if(String(url).includes('/anime/releases/22'))return Promise.resolve({ok:true,json:async()=>({id:22,name:{main:'Найдено'},episodes:[{ordinal:1,hls_720:'https://cdn.example/x.m3u8'}]})});
if(String(url).includes('/anime/releases/latest'))return Promise.resolve({ok:true,json:async()=>[{id:22,name:{main:'Найдено'}}]});
if(String(url).includes('graphql.anilist.co'))return Promise.resolve({ok:true,json:async()=>({data:{Page:{media:[{id:5,title:{romaji:'Hello'}}]}}})});
throw new Error('unexpected '+url)}
test('AniLiberty listing and search',async()=>{const api=createProviders(fakeFetch);assert.equal((await api.catalog('libria'))[0].id,'libria:22');assert.equal((await api.search('libria','поиск'))[0].name,'Найдено');});
test('AniLiberty episode details and direct HLS',async()=>{const api=createProviders(fakeFetch);const d=await api.details('libria:22');assert.equal(d.episodes[0].quality[720],'https://cdn.example/x.m3u8');});
test('AniList metadata catalog',async()=>{const api=createProviders(fakeFetch);const d=await api.catalog('anilist');assert.equal(d[0].id,'anilist:5');assert.equal(d[0].playable,false);});
test('reject invalid detail ID',async()=>{await assert.rejects(()=>createProviders(fakeFetch).details('libria:../../secret'),/Неверный/)});
