"""End-to-end backend sync contract with simulated API and no account secrets on disk."""
import sys, tempfile, json
from pathlib import Path
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'desktop'))
import server, accounts

class SyncTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.b=server.Backend(self.tmp.name)
        self.b.accounts.sessions['anixart']={'token':'private-not-for-disk','user_id':101,'name':'Tester'}
    def tearDown(self):self.tmp.cleanup()
    def data(self):
        return [{'id':'anixart:123','name':'Bleach','status':'Смотрю','statusId':1,'source':'anixart','year':'2024'}]
    def test_remote_import_is_visible_in_main_state_after_restart(self):
        with patch.object(self.b.accounts,'library',return_value={'stale':False,'items':self.data(),'name':'Tester','userId':101}),patch.object(self.b.accounts,'remote_history',return_value=[{'id':'anixart:123','name':'Bleach','episode':'3','date':'2026-10-25T00:00:00+00:00','position':43,'duration':0,'completed':False}]):
            report=self.b.call('syncAll',[])
        self.assertEqual(report['bookmarks'],1)
        self.assertEqual(self.b.call('getState',[])['bookmarks'][0]['status'],'Смотрю')
        self.assertEqual(self.b.call('getState',[])['history'][0]['episode'],'3')
        self.assertIn('Bleach',self.b.history_txt.read_text('utf8'))
        after=server.Backend(self.tmp.name)
        self.assertEqual(after.call('getState',[])['bookmarks'][0]['name'],'Bleach')
        self.assertIn('private-not-for-disk',self.b.accounts.sessions['anixart']['token'])
        for f in Path(self.tmp.name).glob('*'):
            if f.is_file():self.assertNotIn('private-not-for-disk',f.read_text('utf8'))
    def test_remote_edits_wait_offline_and_flush_when_connected(self):
        self.b.unified.merge_library('anixart',self.data(),user_id=101)
        result=self.b.call('setListStatus',[{'id':'anixart:123','name':'Bleach'},3])
        self.assertEqual(result['pending'],1)
        self.assertEqual(self.b.state['bookmarks'][0]['status'],'Просмотрено')
        with patch.object(self.b.accounts,'change_remote_status',side_effect=RuntimeError('offline')) as do:
            report=self.b.call('syncAll',[])
        self.assertEqual(report['pending'],1)
        self.assertEqual(self.b.state['bookmarks'][0]['status'],'Просмотрено')
        with patch.object(self.b.accounts,'change_remote_status',return_value=True) as do,patch.object(self.b.accounts,'library',return_value={'stale':False,'items':[dict(self.data()[0],status='Просмотрено',statusId=3)],'userId':101}),patch.object(self.b.accounts,'remote_history',return_value=[]):
            report=self.b.call('syncAll',[])
        do.assert_called_once_with('anixart','anixart:123',3,1)
        self.assertEqual(report['pending'],0)
        self.assertEqual(self.b.state['bookmarks'][0]['status'],'Просмотрено')
    def test_queue_kept_on_restart_without_credentials(self):
        self.b.unified.merge_library('anixart',self.data(),user_id=101)
        self.b.call('setListStatus',[{'id':'anixart:123','name':'Bleach'},5])
        after=server.Backend(self.tmp.name)
        self.assertEqual(after.unified.pending['anixart:123']['status'],5)
        self.assertEqual(after.state['bookmarks'][0]['status'],'Брошено')
        self.assertNotIn('private-not-for-disk',after.unified.pending_file.read_text())
        # A different account must not receive old offline edits.
        after.accounts.sessions['anixart']={'token':'OTHER','user_id':202,'name':'Other'}
        with patch.object(after.accounts,'change_remote_status') as attempt,patch.object(after.accounts,'library',return_value={'stale':False,'items':[],'userId':202}),patch.object(after.accounts,'remote_history',return_value=[]):
            report=after.call('syncAll',[])
        attempt.assert_not_called()
        self.assertEqual(report['pending'],1)
    def test_unrelated_local_bookmarks_are_preserved(self):
        self.b.call('toggleBookmark',[{'id':'libria:7','name':'Offline bookmark'}])
        self.b.unified.merge_library('anixart',self.data(),user_id=101)
        self.b.unified.merge_library('anixart',[],user_id=101)
        self.assertEqual([x['id'] for x in self.b.state['bookmarks']],['libria:7'])
    def test_history_merge_never_rolls_back_local_playback(self):
        self.b.call('recordWatch',[{'id':'anixart:123','episode':'1','name':'Bleach'}])
        self.b.call('recordProgress',[{'id':'anixart:123','episode':'1','position':500,'duration':1000}])
        self.b.unified.merge_history('anixart',[{'id':'anixart:123','episode':'1','name':'Bleach','date':'2026-10-20T00:00:00+00:00','position':10,'duration':1000}])
        self.assertEqual(self.b.state['history'][0]['position'],500)
    def test_status_cannot_be_changed_to_invalid_api_value(self):
        with self.assertRaises(ValueError): self.b.call('setListStatus',[{'id':'anixart:123','name':'x'},-1])
    def test_yani_remote_status_uses_publisher_token_and_bearer(self):
        self.b.accounts.yani_app_token='publisher'
        self.b.accounts.sessions['yani']={'token':'user-token','user_id':2,'name':'Tester'}
        with patch.object(accounts,'service_json',return_value={'response':{'ok':True}}) as api:
            self.b.accounts.change_remote_status('yani','yani:123',2,0)
        self.assertEqual(api.call_args.args[:2],(accounts.YANI_BASE,'/anime/123/list'))
        self.assertEqual(api.call_args.kwargs['method'],'PUT')
        self.assertEqual(api.call_args.kwargs['data'],{'list':2})
        self.assertEqual(api.call_args.kwargs['headers']['Authorization'],'Bearer user-token')
    def test_anixart_remote_status_does_not_send_password(self):
        with patch.object(self.b.accounts,'_anixart_get',return_value={'code':0}) as api:
            self.b.accounts.change_remote_status('anixart','anixart:123',3,1)
        self.assertEqual(api.call_count,2)
        self.assertEqual(api.call_args_list[0].args[0],'/profile/list/add/3/123')
        self.assertEqual(api.call_args_list[1].args[0],'/profile/list/delete/1/123')

if __name__=='__main__':unittest.main()
