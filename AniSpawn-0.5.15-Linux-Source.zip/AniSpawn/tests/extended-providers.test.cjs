'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const {createProviders}=require('../src/core/providers.cjs');
const N=require('../src/core/normalize.cjs');
const mk=(body,code=200)=>({ok:code>=200&&code<300,status:code,json:async()=>body});

test('Jikan catalogue, search and details normalize scores and posters',async()=>{
 const calls=[];const provider=createProviders(async url=>{
  calls.push(String(url));
  if(String(url).includes('/full'))return mk({data:{mal_id:9,title:'Mock title',score:8.1}});
  return mk({data:[{mal_id:9,title:'Mock title',score:8.1,images:{jpg:{large_image_url:'https://img.example.test/a.jpg'}}}]});
 });
 assert.equal((await provider.catalog('jikan'))[0].rating,8.1);
 assert.equal((await provider.search('jikan','Тест'))[0].id,'jikan:9');
 assert.equal((await provider.details('jikan:9')).name,'Mock title');
 assert.ok(calls.some(x=>x.includes('q=%D0%A2%D0%B5%D1%81%D1%82')));
});

test('AniLiberty paged catalog does not repeat latest endpoint for page 2',async()=>{
 const calls=[];const provider=createProviders(async url=>{calls.push(String(url));return mk([{id:3,name:{main:'Next'}}])});
 assert.equal((await provider.catalog('libria',2))[0].id,'libria:3');
 assert.ok(calls[0].includes('/anime/catalog/releases?limit=30&page=2'));
});

test('Kodik requires own token and never returns a token to renderer',async()=>{
 let received='';const provider=createProviders(async url=>{
  received=String(url);
  return mk({results:[{id:'serial-10',title:'Series',link:'//kodik.info/serial/10/test/720p'}]});
 });
 await assert.rejects(provider.catalog('kodik'),/токен/);
 assert.deepEqual(provider.configureKodik('my-test-token'),{configured:true});
 const result=await provider.catalog('kodik');
 assert.equal(result[0].source,'kodik');
 assert.equal(result[0].playable,true);
 assert.equal(result[0].embed,'https://kodik.info/serial/10/test/720p');
 assert.equal((await provider.details('kodik:serial-10')).name,'Series');
 assert.match(received,/token=my-test-token/);
 assert.ok(!JSON.stringify(result).includes('my-test-token'));
 assert.ok(!JSON.stringify(provider.sources).includes('my-test-token'));
});

test('Kodik invalid embed origin or protocol is rejected',()=>{
 assert.equal(N.kodikLink('http://kodik.info/video/123'),'');
 assert.equal(N.kodikLink('https://kodik.info.evil.test/v'),'');
 assert.equal(N.kodikLink('javascript:alert(1)'),'');
 assert.equal(N.normKodik({id:'movie-55',link:'https://example.test/evil'}).playable,false);
});

test('Kodik bad cursor from API is never requested',async()=>{
 const urls=[];const p=createProviders(async url=>{urls.push(String(url));return mk({results:[{id:'movie-1',title:'One'}],next_page:'https://attacker.invalid/list?token=secret'})});
 p.configureKodik('secret');await p.catalog('kodik',1);
 assert.deepEqual(await p.catalog('kodik',2),[]);
 assert.equal(urls.length,1);
});
