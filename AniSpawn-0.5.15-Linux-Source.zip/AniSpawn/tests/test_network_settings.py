"""No internet required: validate DNS wireformat, routing, first-run choice, proxy and RPC."""
from pathlib import Path
import http.client
import json
import os
import socket
import struct
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch,Mock
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'desktop'))
import network_settings as net
import server

class NetworkingTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory()
  self.manager=net.NetworkManager(self.temp.name)
  net.set_active(self.manager)
 def tearDown(self):self.temp.cleanup();net.set_active(None)

 def test_proxy_input_validation(self):
  for good in ('http://localhost:7890','http://127.0.0.1:8080','socks5://[::1]:1080'):
   self.assertEqual(net.validate_proxy(good),good)
  for bad in ('ftp://server:123','http://a', 'http://user:password@a:8888','http://a:0', 'http://a:65536','http://a:4/?q=x','socks5h://localhost:1080','http://a:34\r\nX: bad','http://a/path:90'):
   with self.subTest(bad=bad),self.assertRaises(ValueError):net.validate_proxy(bad)

 def test_wireformat_response(self):
  qid=0x4321
  question=b'\x04test\x07example\x00\x00\x01\x00\x01'
  record=b'\xc0\x0c'+struct.pack('!HHIH',1,1,120,4)+socket.inet_aton('1.2.3.4')
  pkt=struct.pack('!HHHHHH',qid,0x8180,1,1,0,0)+question+record
  self.assertEqual(net._parse_dns_packet(pkt,qid),['1.2.3.4'])
  with self.assertRaises(ValueError):net._parse_dns_packet(pkt,qid+1)
  with self.assertRaises(ValueError):net._parse_dns_packet(pkt[:10],qid)

 def test_invalid_or_private_dns_answers(self):
  qid=123
  header=struct.pack('!HHHHHH',qid,0x8180,1,1,0,0)
  q=b'\x01a\x00\x00\x01\x00\x01'
  rec=b'\xc0\x0c'+struct.pack('!HHIH',1,1,120,4)+socket.inet_aton('127.0.0.1')
  with self.assertRaises(OSError):net._parse_dns_packet(header+q+rec,qid)

 def test_best_must_have_full_https_not_fastest_dns(self):
  outcomes={'system':(0,0,35),'cloudflare':(2,2,120),'google':(2,2,65),'adguard':(2,1,20)}
  def fake(provider):
   d,t,m=outcomes[provider]
   return dict(id=provider,name=provider,dnsOk=d,httpsOk=t,ms=m,ok=t==2,error='')
  with patch.object(self.manager,'_probe',side_effect=fake):
   result=self.manager.benchmark()
  self.assertEqual(result['selected'],'google')
  self.assertTrue(result['tested'])
  self.assertEqual(len(result['results']),4)
  self.assertEqual(net.NetworkManager(self.temp.name).status()['selected'],'google')

 def test_when_all_unavailable_keep_system_fallback(self):
  with patch.object(self.manager,'_probe',side_effect=lambda x:dict(id=x,ok=False,ms=20,httpsOk=0,dnsOk=0)):
   self.assertEqual(self.manager.benchmark()['selected'],'system')

 def test_user_explicit_dns_ignores_auto_selection(self):
  self.manager.configure({'mode':'cloudflare'})
  with patch.object(self.manager,'_probe',side_effect=lambda x:dict(id=x,ok=True,ms=20,httpsOk=2,dnsOk=2)):
   self.assertEqual(self.manager.benchmark()['effectiveDns'],'cloudflare')

 def test_first_start_test_nonblocking_runs_once(self):
  ran=[]
  def fake(p):
   ran.append(p);return dict(id=p,ok=True,ms=9,httpsOk=2,dnsOk=2)
  with patch.object(self.manager,'_probe',side_effect=fake):
   self.manager.start_first_run_test()
   for _ in range(70):
    if self.manager.status()['tested'] and not self.manager.testing:break
    time.sleep(.01)
  self.assertTrue(self.manager.status()['tested'])
  self.assertEqual(len(ran),4)
  self.manager.start_first_run_test()
  self.assertEqual(len(ran),4)

 def test_proxy_routing_and_flags(self):
  self.manager.configure({'mode':'google','proxy':'http://127.0.0.1:8888'})
  self.assertEqual(self.manager.status()['effectiveDns'],'proxy')
  self.assertEqual(self.manager.ffmpeg_proxy_flags(),['-http_proxy','http://127.0.0.1:8888'])
  self.assertIn('--proxy-server=http://127.0.0.1:8888',self.manager.browser_flags())
  self.manager.configure({'proxy':'socks5://127.0.0.1:1080'})
  self.assertEqual(self.manager.ffmpeg_proxy_flags(),[])
  self.assertIn('--proxy-server=socks5://127.0.0.1:1080',self.manager.browser_flags())
  self.manager.configure({'proxy':''})
  self.assertIn('--dns-over-https-templates=https://dns.google/dns-query',self.manager.browser_flags())

 def test_doh_opener_uses_selected_resolver(self):
  self.manager.configure({'mode':'cloudflare'})
  request=net.urllib.request.Request('https://api.anixsekai.com/release/2')
  class Dummy:
   def open(self,r,timeout):return 'ok'
  with patch.object(net.urllib.request,'build_opener',return_value=Dummy()) as build:
   self.assertEqual(self.manager.open(request,3),'ok')
   self.assertTrue(any(isinstance(x,net._RoutingHandler) and x.resolver for x in build.call_args.args))

 def test_socks5_remote_dns_handshake(self):
  listener=socket.socket();listener.bind(('127.0.0.1',0));listener.listen(1)
  port=listener.getsockname()[1];record=[]
  def worker():
   connection,_=listener.accept()
   try:
    self.assertEqual(net._read_exact(connection,3),b'\x05\x01\x00')
    connection.sendall(b'\x05\x00')
    head=net._read_exact(connection,5)
    dest=net._read_exact(connection,head[4]).decode()
    target_port=struct.unpack('!H',net._read_exact(connection,2))[0]
    record.append((dest,target_port))
    connection.sendall(b'\x05\x00\x00\x01'+socket.inet_aton('127.0.0.1')+struct.pack('!H',80))
   finally:connection.close();listener.close()
  th=threading.Thread(target=worker,daemon=True);th.start()
  connection=net._socks_connect('api.anixsekai.com',443,f'socks5://127.0.0.1:{port}',2)
  connection.close();th.join(3)
  self.assertEqual(record,[('api.anixsekai.com',443)])

 def test_server_rpc_updates_settings_without_changing_system(self):
  with patch.dict(os.environ,{'XDG_CACHE_HOME':self.temp.name}):
   backend=server.Backend(self.temp.name)
   local=server.Server(('127.0.0.1',0),backend)
   thread=threading.Thread(target=local.serve_forever,daemon=True);thread.start()
   try:
    connection=http.client.HTTPConnection('127.0.0.1',local.server_port,timeout=3)
    def rpc(method,args=[]):
     request=json.dumps(dict(method=method,args=args)).encode()
     connection.request('POST',local.prefix+'rpc',request,{'Origin':f'http://127.0.0.1:{local.server_port}','Content-Type':'application/json'})
     answer=connection.getresponse();result=json.loads(answer.read());return answer.status,result
    status,body=rpc('networkConfigure',[{'mode':'adguard','proxy':''}])
    self.assertEqual(status,200)
    self.assertEqual(body['result']['effectiveDns'],'adguard')
    status,body=rpc('networkStatus')
    self.assertEqual(body['result']['mode'],'adguard')
    status,body=rpc('networkConfigure',[{'proxy':'http://a:80?evil=x'}])
    self.assertEqual(status,400)
    connection.close()
   finally:local.shutdown();local.server_close()

if __name__=='__main__':unittest.main()
