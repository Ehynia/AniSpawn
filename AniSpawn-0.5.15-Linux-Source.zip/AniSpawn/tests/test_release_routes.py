import sys, unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'desktop'))
import server

class NativeReleaseRouterTests(unittest.TestCase):
 def test_url_to_id(self):
  self.assertEqual(server.parse_anixart_release_url('https://anixart-app.com/release/2563'), '2563')
  self.assertEqual(server.parse_anixart_release_url('https://mirror.anixart-app.com/release/2563?x=1'), '2563')
  self.assertEqual(server.parse_anixart_release_url('anixart:2563'), '2563')
 def test_rejects_unsafe_links(self):
  for value in ('https://anixart-app.com.evil/release/2563','http://anixart-app.com/release/2563','https://anixart-app.com:8000/release/2563','https://user:password@anixart-app.com/release/2563','https://anixart-app.com/release/2563/extra','https://anixart-app.com/release/0','file:///tmp/2563'):
   with self.subTest(value=value):self.assertIsNone(server.parse_anixart_release_url(value))
 def test_release_url_normalized_to_official_host(self):
  release=server.normalize({'id':2563,'title_ru':'О моём перерождении в слизь'},'anixart')
  self.assertEqual(release['url'],'https://anixart-app.com/release/2563')
 def test_cannot_launch_external_browser_for_anixart_release(self):
  import tempfile
  with tempfile.TemporaryDirectory() as td:
   backend=server.Backend(td)
   with patch.object(server.webbrowser,'open') as browser:
    with self.assertRaisesRegex(ValueError,'внутри AniSpawn'):
     backend.call('openExternal',['https://anixart-app.com/release/2563'])
    browser.assert_not_called()
