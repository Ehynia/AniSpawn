import json
import os
from pathlib import Path
import sys
import tempfile
import threading
import time
import unittest
from urllib.request import urlopen,Request
from urllib.error import HTTPError
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'desktop'))
import server

class BackendTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory()
  self.backend=server.Backend(self.tmp.name)
 def tearDown(self):self.tmp.cleanup()
 def test_state_defaults_and_updates(self):
  self.assertEqual(self.backend.state['source'],'all')
  value=self.backend.update({'theme':'light','source':'malicious','upscale':{'enabled':True,'scale':200,'mode':'anime','strength':4}})
  self.assertEqual(value['theme'],'light')
  self.assertEqual(value['source'],'all')
  self.assertEqual(value['upscale']['scale'],1.5)
  self.assertEqual(value['upscale']['strength'],1)
  self.assertEqual(server.Backend(self.tmp.name).state['theme'],'light')
 def test_bookmark_and_history(self):
  item={'id':'libria:33','name':'Пример','image':'','year':2026,'source':'libria'}
  self.assertTrue(self.backend.bookmark(item)['added'])
  self.assertFalse(self.backend.bookmark(item)['added'])
  self.assertEqual(self.backend.watched({'id':'libria:33','episode':'1','name':'Пример'})[0]['episode'],'1')
 def test_rejects_unknown_stream(self):
  with self.assertRaises(ValueError):self.backend.prepare('https://other.example/movie.m3u8')
 def test_normalize_libria_fixture(self):
  item={'id':8452,'name':{'main':'Блич'},'poster':{'src':'/poster.jpg'},'episodes':[{'ordinal':1,'hls_720':'https://media.example/a.m3u8'}]}
  self.assertEqual(server.normalize(item,'libria')['id'],'libria:8452')
  self.assertEqual(server.episodes_libria(item,'https://anilibria.top')[0]['quality']['720'],'https://media.example/a.m3u8')
 def test_kodik_token_not_saved(self):
  self.backend.call('configureKodik',['abc_123'])
  self.assertNotIn('abc_123',self.backend.state_file.read_text() if self.backend.state_file.exists() else '')
  with self.assertRaises(ValueError):self.backend.call('configureKodik',['abc&token=x'])

class HttpTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();cls.backend=server.Backend(cls.tmp.name)
  cls.server=server.Server(('127.0.0.1',0),cls.backend)
  cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
  cls.url=f'http://127.0.0.1:{cls.server.server_port}{cls.server.prefix}'
 @classmethod
 def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.tmp.cleanup()
 def rpc(self,method,args=None,origin=True):
  headers={'Content-Type':'application/json'}
  if origin:headers['Origin']=f'http://127.0.0.1:{self.server.server_port}'
  req=Request(self.url+'rpc',json.dumps({'method':method,'args':args or []}).encode(),headers,method='POST')
  with urlopen(req,timeout=3) as r:return json.load(r)['result']
 def test_static_html(self):
  with urlopen(self.url,timeout=3) as resp:
   self.assertEqual(resp.status,200)
   self.assertIn(b'desktop-bridge.js',resp.read())
 def test_static_js(self):
  with urlopen(self.url+'desktop-bridge.js',timeout=3) as r:self.assertIn(b'window.anispawn',r.read())
 def test_sources_rpc(self):self.assertTrue(any(x['id']=='libria' for x in self.rpc('sources')))
 def test_origin_check(self):
  with self.assertRaises(HTTPError) as err:self.rpc('getState',origin=False)
  self.assertEqual(err.exception.code,403)
 def test_random_prefix_needed(self):
  with self.assertRaises(HTTPError) as err:urlopen(f'http://127.0.0.1:{self.server.server_port}/')
  self.assertEqual(err.exception.code,404)
 def test_traversal_blocked(self):
  with self.assertRaises(HTTPError):urlopen(self.url+'..%2F..%2Fetc/passwd')

if __name__=='__main__':unittest.main()
