"""Offline integration tests for Anixart/Yani login and user library."""
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'desktop'))
import accounts
import server

class AccountTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory()
  self.ac=accounts.Accounts(self.tmp.name, app_token='')
 def tearDown(self):self.tmp.cleanup()
 def test_anixart_signin_form_and_session_does_not_touch_disk(self):
  with patch.object(accounts,'service_json',return_value={'code':0,'profile':{'id':42,'login':'TestAnime'},'profileToken':{'token':'super_secret'}}) as request:
   profile=self.ac.login('anixart','test','password')
  self.assertEqual(profile,{'id':42,'name':'TestAnime'})
  self.assertEqual(request.call_args.kwargs['data'],{'login':'test','password':'password'})
  self.assertTrue(request.call_args.kwargs['form'])
  self.assertFalse(list(Path(self.tmp.name).glob('*')))
  self.assertNotIn('super_secret',json.dumps(self.ac.providers()))
 def test_anixart_login_rejected_code_never_creates_session(self):
  with patch.object(accounts,'service_json',return_value={'code':3}):
   with self.assertRaises(ValueError):self.ac.login('anixart','test','bad')
  self.assertIsNone(self.ac.public('anixart'))
 def test_anixart_remote_library_all_five_lists(self):
  self.ac.sessions['anixart']={'token':'top-secret','user_id':42,'name':'Me'}
  with patch.object(accounts,'service_json',return_value={'code':0,'content':[{'id':123,'title_ru':'Наруто'}],'total_page_count':1}) as req:
   result=self.ac.library('anixart')
  self.assertEqual(len(result['items']),5)
  self.assertEqual(req.call_count,5)
  self.assertIn('[Смотрю] Наруто',self.ac.txt_file.read_text('utf8'))
  self.assertNotIn('top-secret',self.ac.cache_file.read_text('utf8'))
  again=accounts.Accounts(self.tmp.name,app_token='').library('anixart')
  self.assertTrue(again['stale']);self.assertEqual(len(again['items']),5)
 def test_yani_without_publisher_key_cannot_send_password(self):
  with patch.object(accounts,'service_json') as req:
   with self.assertRaisesRegex(ValueError,'не зарегистрирован'):
    self.ac.login('yani','user','password')
   req.assert_not_called()
  desc=[x for x in self.ac.providers() if x['id']=='yani'][0]
  self.assertFalse(desc['available'])
 def test_yani_with_publisher_key_uses_user_login_password_and_bearer(self):
  ac=accounts.Accounts(self.tmp.name, app_token='publisher-token')
  def request(base,endpoint,**kwargs):
   if endpoint=='/profile/login':
    self.assertEqual(kwargs['data'],{'login':'abc','password':'pw','need_json':True})
    self.assertEqual(kwargs['headers']['X-Application'],'publisher-token')
    return {'response':{'token':'personal-token'}}
   if endpoint=='/profile':
    self.assertEqual(kwargs['headers']['Authorization'],'Bearer personal-token')
    return {'response':{'id':77,'nickname':'AnimeUser'}}
   raise AssertionError(endpoint)
  with patch.object(accounts,'service_json',side_effect=request):
   self.assertEqual(ac.login('yani','abc','pw'),{'id':77,'name':'AnimeUser'})
  self.assertTrue([x for x in ac.providers() if x['id']=='yani'][0]['available'])
  self.assertEqual(list(Path(self.tmp.name).iterdir()),[])
 def test_yani_lists_normalize_nested_anime(self):
  self.ac.yani_app_token='publisher'
  self.ac.sessions['yani']={'token':'bearer-secret','user_id':77,'name':'User'}
  def request(base,endpoint,**kwargs):
   if endpoint.endswith('/lists'):
    return {'response':[{'id':0,'title':'Смотрю'}]}
   if endpoint.endswith('/lists/0'):
    self.assertEqual(kwargs['headers']['Authorization'],'Bearer bearer-secret')
    return {'response':[{'anime':{'anime_id':1,'title':'Блич','poster':{'big':'https://example.org/poster.jpg'}}}]}
   raise AssertionError(endpoint)
  with patch.object(accounts,'service_json',side_effect=request):
   self.assertEqual(self.ac.library('yani')['items'][0]['name'],'Блич')
 def test_logout_resets_token_but_preserves_offline_library(self):
  self.ac.sessions['anixart']={'token':'private','user_id':1,'name':'Me'}
  with patch.object(accounts,'service_json',return_value={'code':0,'content':[],'total_page_count':1}):self.ac.library('anixart')
  self.ac.logout('anixart')
  self.assertFalse(self.ac.library('anixart')['authenticated'])
  self.assertNotIn('private',self.ac.txt_file.read_text('utf8'))
 def test_backend_rpc_methods(self):
  b=server.Backend(self.tmp.name)
  self.assertIsInstance(b.call('accountProviders',[]),list)
  self.assertIn('account-libraries.txt',b.call('accountLibraryPath',[]))

if __name__=='__main__':unittest.main()
