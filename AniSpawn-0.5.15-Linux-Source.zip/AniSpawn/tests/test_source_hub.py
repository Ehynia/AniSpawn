"""Source federation and health state: deterministic; no external network required."""
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'desktop'))
import server
import source_hub as hub

A={'id':'anixart:2563','source':'anixart','name':'Слизь','year':2018}
L={'id':'libria:523','source':'libria','name':'Слизь','year':2018}
M={'id':'mikai:11','source':'mikai','name':'Другое аниме','year':2024}

class SourceHubTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.cache=tempfile.TemporaryDirectory()
  self.env=patch.dict(os.environ,{'XDG_CACHE_HOME':self.cache.name});self.env.start()
  self.backend=server.Backend(self.tmp.name)
 def tearDown(self):
  self.env.stop();self.tmp.cleanup();self.cache.cleanup()
 def test_first_install_uses_all(self):
  self.assertEqual(self.backend.state['source'],'all')
  self.assertIn('all',[x['id'] for x in self.backend.call('sources',[])])
 def test_combines_providers_and_preserves_real_ids(self):
  calls=[]
  def fake(source,page,query=''):
   calls.append((source,page,query))
   return {'anixart':[A],'libria':[L],'mikai':[M]}.get(source,[])
  with patch.object(self.backend,'catalog',side_effect=fake):
   result=self.backend.call('search',['all','Слизь',3])
  self.assertEqual(len(result['items']),2)
  first=result['items'][0]
  self.assertEqual(first['id'],A['id']);self.assertEqual(first['alternatives'][0]['id'],L['id'])
  self.assertEqual(result['items'][1]['id'],M['id'])
  self.assertIn(('anixart',3,'Слизь'),calls)
  self.assertIn(('mikai',3,'Слизь'),calls)
  self.assertNotIn('yani',[s for s,_,_ in calls]);self.assertNotIn('kodik',[s for s,_,_ in calls])
  self.assertEqual(result['providers']['yani'],'auth_required')
 def test_one_remote_outage_does_not_blank_others(self):
  def fake(source,page,query=''):
   if source=='anixart':raise RuntimeError('TLS down')
   return [L] if source=='libria' else []
  with patch.object(self.backend,'catalog',side_effect=fake):
   result=self.backend.call('list',['all',1])
  self.assertEqual([x['id'] for x in result['items']],[L['id']])
  self.assertTrue(result['stale']);self.assertIn('anixart',result['warning'])
  self.assertEqual(self.backend.call('sourceStatus',[])['sources']['anixart']['state'],'offline')
 def test_offline_catalog_falls_back_to_cache(self):
  with patch.object(self.backend,'catalog',side_effect=lambda src, page, query='':[M] if src=='mikai' else []):
   self.backend.call('list',['all',1])
  with patch.object(self.backend,'catalog',side_effect=RuntimeError('down')):
   result=self.backend.call('list',['all',1])
  self.assertIn(M['id'],[x['id'] for x in result['items']]);self.assertTrue(result['stale'])
  self.assertEqual(result['providers']['mikai'],'cached')
 def test_site_pages_in_main_catalog_without_network(self):
  self.backend.site_items['sites:'+'a'*32]={'id':'sites:'+'a'*32,'source':'sites','name':'Импорт','url':'https://sovetromantica.com/anime/1523-example','players':[]}
  with patch.object(self.backend,'catalog',return_value=[]):
   result=self.backend.call('list',['all',1])
  self.assertEqual(result['items'][0]['name'],'Импорт')
  health=self.backend.call('sourceStatus',[])['sources']
  self.assertEqual(health['site-sovetromantica']['state'],'saved')
  self.assertEqual(health['site-animevost']['state'],'not_imported')
 def test_server_status_distinguishes_auth_and_metadata(self):
  health=self.backend.call('sourceStatus',[])
  self.assertEqual(health['sources']['yani']['state'],'auth_required')
  self.assertEqual(health['sources']['kodik']['state'],'auth_required')
  self.assertEqual(health['sources']['jikan']['state'],'unknown')
  self.assertIn('summary',health)
 def test_background_refresh_returns_immediately_and_finishes(self):
  with patch.object(self.backend,'catalog',return_value=[M]), patch('source_hub.site_bridges.read_public_html') as http:
   first=self.backend.call('refreshSourceStatus',[])
   self.assertIn('sources',first)
   deadline=time.monotonic()+4
   while self.backend.call('sourceStatus',[])['testing'] and time.monotonic()<deadline:
    time.sleep(.025)
  result=self.backend.call('sourceStatus',[])
  self.assertFalse(result['testing'])
  self.assertEqual(result['sources']['anixart']['state'],'online')
  http.assert_not_called()  # No site check without an explicitly imported page
 def test_state_persists_independent_source_ids(self):
  self.backend.bookmark({'id':'anixart:2563','name':'Слизь','source':'anixart'})
  self.backend.bookmark({'id':'libria:523','name':'Слизь','source':'libria'})
  self.assertEqual(len(self.backend.state['bookmarks']),2)

if __name__=='__main__': unittest.main()

class SourceHubUiContractTests(unittest.TestCase):
 def test_ui_shows_source_status_and_all_selectors(self):
  root = Path(__file__).resolve().parents[1]
  html=(root/'renderer/index.html').read_text()
  script=(root/'renderer/app.js').read_text()
  bridge=(root/'renderer/desktop-bridge.js').read_text()
  self.assertGreaterEqual(html.count('value="all"'),2)
  for attr in ('sources-summary','sources-list','check-all'):
   self.assertIn(f'id="{attr}"', html)
  self.assertIn('sourceStateLabels',script)
  self.assertIn('updateSourceStatuses',script)
  self.assertIn("refreshSourceStatus:()=>call('refreshSourceStatus')",bridge)
 def test_all_mode_sources_omits_rutube_and_vk(self):
  self.assertNotIn('rutube',hub.CATALOG_SOURCES)
  self.assertNotIn('vk',hub.CATALOG_SOURCES)
