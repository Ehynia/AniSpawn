import pathlib
import shutil
import subprocess
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
PROFILE=ROOT/'packaging/apparmor.d/anispawn-chromium'
PACKER=ROOT/'scripts/package-standalone-linux.py'
SERVER=ROOT/'desktop/server.py'

class SandboxPackagingTests(unittest.TestCase):
 def test_profile_limited_to_bundled_chromium(self):
  data=PROFILE.read_text()
  self.assertIn('/opt/anispawn/runtime/chromium/chromium flags=(unconfined)',data)
  self.assertIn('userns,',data)
  self.assertNotIn('/**',data)
 def test_apparmor_4_parser_accepts_profile(self):
  parser=shutil.which('apparmor_parser')
  if not parser:self.skipTest('apparmor_parser unavailable')
  result=subprocess.run([parser,'-Q','-K',str(PROFILE)],capture_output=True,text=True)
  self.assertEqual(result.returncode,0,result.stderr)
 def test_maintainer_scripts(self):
  packaging=PACKER.read_text()
  self.assertIn('postinst',packaging)
  self.assertIn('prerm',packaging)
  self.assertIn('apparmor',packaging)
  self.assertIn('apparmor_parser -r -K', (ROOT/'packaging/debian/postinst').read_text())
  self.assertIn('apparmor_parser -R -K', (ROOT/'packaging/debian/prerm').read_text())
 def test_normal_launch_preserves_sandbox(self):
  code=SERVER.read_text()
  self.assertIn("'--app='+address",code)
  self.assertNotIn("command+=['--no-sandbox'",code)

if __name__=='__main__':unittest.main()
